package Freundesliste.Freundesliste;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import Freundesliste.Freundesliste.Tournament.Tournament;
import Freundesliste.Freundesliste.Tournament.TournamentRepository;
import Freundesliste.Freundesliste.Tournament.TournamentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

public class getMatchTest {

  @Mock
  private TournamentRepository tournamentRepository;

  @InjectMocks
  private TournamentService tournamentService;

  @BeforeEach
  public void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  public void test_getMatch() {
    Tournament tournament1 = new Tournament();
    tournament1.setClanName("ClanA");
    tournament1.setUsername1("User1");
    tournament1.setUsername2("User2");

    Tournament tournament2 = new Tournament();
    tournament2.setClanName("ClanA");
    tournament2.setUsername1("User3");
    tournament2.setUsername2("User4");

    List<Tournament> expected= Arrays.asList(tournament1, tournament2);

    when(tournamentRepository.findByClanName("ClanA")).thenReturn(expected);

    List<Tournament> actual = tournamentService.getMatch("ClanA");

    assertThat(actual).isEqualTo(expected);
  }
}
