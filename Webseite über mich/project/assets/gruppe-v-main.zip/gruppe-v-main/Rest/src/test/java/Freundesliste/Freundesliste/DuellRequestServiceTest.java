package Freundesliste.Freundesliste;

import Freundesliste.Freundesliste.Deck.model.Deck;
import Freundesliste.Freundesliste.Deck.model.DeckRepository;
import Freundesliste.Freundesliste.DuellRequests.DuellRequest;
import Freundesliste.Freundesliste.DuellRequests.DuellRequestRepository;
import Freundesliste.Freundesliste.DuellRequests.DuellRequestService;
import Freundesliste.Freundesliste.Spieler.Player;
import Freundesliste.Freundesliste.Spieler.PlayerService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DuellRequestServiceTest {
  private static DuellRequestRepository duellRequestRepository;
  private static PlayerService playerService;
  private static DeckRepository deckRepository;

  @BeforeAll
  public static void setUpTest() {
    duellRequestRepository = mock(DuellRequestRepository.class);
    playerService = mock(PlayerService.class);
    deckRepository = mock(DeckRepository.class);
  }

  @Test
  public void test_check1(){
    DuellRequest mockedDuellRequest = new DuellRequest();
    mockedDuellRequest.setReceiver("mockedReceiver");
    mockedDuellRequest.setSender("mockedSender");

    Deck mockedDeck = new Deck();
    mockedDeck.setName("mockedDeck");

    Player mockedReceiver = new Player();
    mockedReceiver.setStatus("online");
    mockedReceiver.setUsername("mockedReceiver");
    Player mockedSender = new Player();
    mockedSender.setStatus("online");
    mockedSender.setUsername("mockedSender");

    List<Deck> mockedReceiverDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    List<Deck> mockedSenderDecks = new ArrayList<>();

    when(playerService.findPlayerByUsername("mockedReceiver")).thenReturn(mockedReceiver);
    when(deckRepository.findByDeckuser("mockedReceiver")).thenReturn(mockedReceiverDecks);
    when(playerService.findPlayerByUsername("mockedSender")).thenReturn(mockedSender);
    when(deckRepository.findByDeckuser("mockedSender")).thenReturn(mockedSenderDecks);

    DuellRequestService duellRequestService = new DuellRequestService(duellRequestRepository, playerService, deckRepository);
    String check = duellRequestService.check(mockedDuellRequest);
    String expected = "sender no deck";

    assertEquals(expected, check);
  }

  @Test
  public void test_check2(){
    DuellRequest mockedDuellRequest = new DuellRequest();
    mockedDuellRequest.setReceiver("mockedReceiver");
    mockedDuellRequest.setSender("mockedSender");

    Deck mockedDeck = new Deck();
    mockedDeck.setName("mockedDeck");

    Player mockedReceiver = new Player();
    mockedReceiver.setStatus("online");
    mockedReceiver.setUsername("mockedReceiver");
    Player mockedSender = new Player();
    mockedSender.setStatus("online");
    mockedSender.setUsername("mockedSender");

    List<Deck> mockedReceiverDecks = new ArrayList<>();
    List<Deck> mockedSenderDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    when(playerService.findPlayerByUsername("mockedReceiver")).thenReturn(mockedReceiver);
    when(deckRepository.findByDeckuser("mockedReceiver")).thenReturn(mockedReceiverDecks);
    when(playerService.findPlayerByUsername("mockedSender")).thenReturn(mockedSender);
    when(deckRepository.findByDeckuser("mockedSender")).thenReturn(mockedSenderDecks);

    DuellRequestService duellRequestService = new DuellRequestService(duellRequestRepository, playerService, deckRepository);
    String check = duellRequestService.check(mockedDuellRequest);
    String expected = "receiver no deck";

    assertEquals(expected, check);
  }

  @Test
  public void test_check3(){
    DuellRequest mockedDuellRequest = new DuellRequest();
    mockedDuellRequest.setReceiver("mockedReceiver");
    mockedDuellRequest.setSender("mockedSender");

    Deck mockedDeck = new Deck();
    mockedDeck.setName("mockedDeck");

    Player mockedReceiver = new Player();
    mockedReceiver.setStatus("offline");
    mockedReceiver.setUsername("mockedReceiver");
    Player mockedSender = new Player();
    mockedSender.setStatus("online");
    mockedSender.setUsername("mockedSender");

    List<Deck> mockedReceiverDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    List<Deck> mockedSenderDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    when(playerService.findPlayerByUsername("mockedReceiver")).thenReturn(mockedReceiver);
    when(deckRepository.findByDeckuser("mockedReceiver")).thenReturn(mockedReceiverDecks);
    when(playerService.findPlayerByUsername("mockedSender")).thenReturn(mockedSender);
    when(deckRepository.findByDeckuser("mockedSender")).thenReturn(mockedSenderDecks);

    DuellRequestService duellRequestService = new DuellRequestService(duellRequestRepository, playerService, deckRepository);
    String check = duellRequestService.check(mockedDuellRequest);
    String expected = "receiver offline";

    assertEquals(expected, check);
  }

  @Test
  public void test_check4(){
    DuellRequest mockedDuellRequest = new DuellRequest();
    mockedDuellRequest.setReceiver("mockedReceiver");
    mockedDuellRequest.setSender("mockedSender");

    Deck mockedDeck = new Deck();
    mockedDeck.setName("mockedDeck");

    Player mockedReceiver = new Player();
    mockedReceiver.setStatus("ingame");
    mockedReceiver.setUsername("mockedReceiver");
    Player mockedSender = new Player();
    mockedSender.setStatus("online");
    mockedSender.setUsername("mockedSender");

    List<Deck> mockedReceiverDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    List<Deck> mockedSenderDecks = new ArrayList<>(){{
      this.add(mockedDeck);
    }};
    when(playerService.findPlayerByUsername("mockedReceiver")).thenReturn(mockedReceiver);
    when(deckRepository.findByDeckuser("mockedReceiver")).thenReturn(mockedReceiverDecks);
    when(playerService.findPlayerByUsername("mockedSender")).thenReturn(mockedSender);
    when(deckRepository.findByDeckuser("mockedSender")).thenReturn(mockedSenderDecks);

    DuellRequestService duellRequestService = new DuellRequestService(duellRequestRepository, playerService, deckRepository);
    String check = duellRequestService.check(mockedDuellRequest);
    String expected = "receiver ingame";

    assertEquals(expected, check);
  }
}
