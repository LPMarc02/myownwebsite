package Freundesliste.Freundesliste;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreundeslisteApplicationTests {

	@Test
	void contextLoads() {
	}

}
