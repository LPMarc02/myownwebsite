package Freundesliste.Freundesliste;

import Freundesliste.Freundesliste.ClanUser.ClanUserService;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class ClanUserServiceTest {
  ClanUserService clanUserService = mock(ClanUserService.class);

  @Test
  public void test_saveClanUser() {
    String mockedUsername = "mockedUsername";
    String mockedClanname = "mockedClanname";

    doNothing().when(clanUserService).saveClanUser(mockedUsername, mockedClanname);
    clanUserService.saveClanUser(mockedUsername, mockedClanname);
    verify(clanUserService).saveClanUser(mockedUsername, mockedClanname);
  }
}
