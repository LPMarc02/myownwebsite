package Freundesliste.Freundesliste;

import Freundesliste.Freundesliste.cards.Card;
import Freundesliste.Freundesliste.cards.CardService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class GetCardTest {
  private static CardService cardService;

  @BeforeAll
  public static void setUp() {
    cardService= mock(CardService.class);
  }

  @Test
  public void Test_getCard() {
    Long id= 59L;
    Card card= new Card();
    card.setId(59L);
    when(cardService.getCard(id)).thenReturn(card);
    if (card.getId()!=null) {
      assertEquals(id, cardService.getCard(id).getId());
    }
    else{
      assertEquals(id, 44); //Zur Überprüfung des if-Zweigs
    }
  }

}
