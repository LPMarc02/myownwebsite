package Freundesliste.Freundesliste;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import Freundesliste.Freundesliste.Game.Game;
import Freundesliste.Freundesliste.Game.GameRepository;
import Freundesliste.Freundesliste.Game.GameService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class GameTest {

  @Mock
  private GameRepository gameRepository;

  @InjectMocks
  private GameService gameService;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.openMocks(this);
  }

  @Test
  void testUpdateGameSession() {
    String sessionId = "session1";
    String username = "user1";
    Game existingGame = new Game(sessionId, username, "role1", 8L, 1);
    Game updatedGame = new Game(sessionId, "user2", "role2", 14L, 2);

    when(gameRepository.findBySessionIdAndUsername(sessionId, username)).thenReturn(Optional.of(existingGame));
    when(gameRepository.save(any(Game.class))).thenAnswer(invocation -> invocation.getArgument(0));

    Game result = gameService.updateGameSession(sessionId, username, updatedGame);

    assertNotNull(result);
    assertEquals(updatedGame.getUsername(), result.getUsername());
    assertEquals(updatedGame.getPlayerRole(), result.getPlayerRole());
    assertEquals(updatedGame.getDeckId(), result.getDeckId());
    assertEquals(updatedGame.getGameMode(), result.getGameMode());

    verify(gameRepository, times(1)).findBySessionIdAndUsername(sessionId, username);
    verify(gameRepository, times(1)).save(existingGame);
  }

  @Test
  void testUpdateGameSessionNotFound() {
    String sessionId = "session1";
    String username = "user1";
    Game updatedGame = new Game(sessionId, "user2", "role2", 8L, 2);

    when(gameRepository.findBySessionIdAndUsername(sessionId, username)).thenReturn(Optional.empty());

    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
      gameService.updateGameSession(sessionId, username, updatedGame);
    });

    assertEquals("Game session with sessionId session1 and username user1 not found", exception.getMessage());

    verify(gameRepository, times(1)).findBySessionIdAndUsername(sessionId, username);
    verify(gameRepository, never()).save(any(Game.class));
  }

  @Test
  void testDeleteGameSessionByUsername() {
    String username = "user1";
    Game game = new Game("session1", username, "role1", 14L, 1);

    when(gameRepository.findByUsername(username)).thenReturn(game);

    gameService.deleteGameSessionByUsername(username);

    verify(gameRepository, times(1)).findByUsername(username);
    verify(gameRepository, times(1)).delete(game);
  }

  @Test
  void testDeleteGameSessionByUsernameNotFound() {
    String username = "user1";

    when(gameRepository.findByUsername(username)).thenReturn(null);

    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
      gameService.deleteGameSessionByUsername(username);
    });

    assertEquals("Game session with username user1 not found", exception.getMessage());

    verify(gameRepository, times(1)).findByUsername(username);
    verify(gameRepository, never()).delete(any(Game.class));
  }
}
