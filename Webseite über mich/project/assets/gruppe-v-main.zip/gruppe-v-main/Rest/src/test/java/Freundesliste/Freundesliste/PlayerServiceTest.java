package Freundesliste.Freundesliste;



import Freundesliste.Freundesliste.Spieler.Player;
import Freundesliste.Freundesliste.Spieler.PlayerRepository;
import Freundesliste.Freundesliste.Spieler.PlayerService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class PlayerServiceTest {
  private static PlayerRepository playerRepository;
  private static PlayerService playerService;

  @BeforeAll
  public static void setUpTest() {
    playerRepository = mock(PlayerRepository.class);
    playerService = new PlayerService(playerRepository);
  }

  @Test
  public void testSetLeaderboard() {

    String username = "testUser";
    long points = 100;
    Player player = new Player();
    player.setUsername(username);
    player.setLeaderboard(200L);

    when(playerRepository.findByUsername(username)).thenReturn(player);


    playerService.setLeaderboard(username, points);


    assertEquals(300, player.getLeaderboard());
    verify(playerRepository, times(1)).findByUsername(username);
    verify(playerRepository, times(1)).save(player);
  }
}


