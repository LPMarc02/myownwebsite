package Freundesliste.Freundesliste.cards;
import jakarta.persistence.*;


@Entity
public class Card {

    @Id // ID
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

  @Column(name = "rarity")
  private String rarity;

  @Column(name = "attack_points")
  private int attackPoints;

  @Column(name = "defense_points")
  private int defensePoints;

  @Column(name = "description")
  private String description;

  @Column(name = "image_path")
  private String imagePath;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getRarity() {
    return rarity;
  }

  public void setRarity(String rarity) {
    this.rarity = rarity;
  }

  public int getAttackPoints() {
    return attackPoints;
  }

  public void setAttackPoints(int attackPoints) {
    this.attackPoints = attackPoints;
  }

  public int getDefensePoints() {
    return defensePoints;
  }

  public void setDefensePoints(int defensePoints) {
    this.defensePoints = defensePoints;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getImagePath() {
    return imagePath;
  }

  public void setImagePath(String imagePath) {
    this.imagePath = imagePath;
  }
}
