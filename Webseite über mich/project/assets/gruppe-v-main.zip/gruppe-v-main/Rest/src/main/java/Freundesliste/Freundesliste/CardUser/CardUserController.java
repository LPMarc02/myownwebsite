package Freundesliste.Freundesliste.CardUser;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/CardUser")
public class CardUserController {

  private final CardUserService cardUserService;

  public CardUserController(CardUserService cardUserService) {
    this.cardUserService = cardUserService;
  }

  @PostMapping("/addCardsToUser")
  public void addCardsToUser(@RequestBody CardUser cardUser) {
    cardUserService.addCardsToUser(cardUser);
  }

  @GetMapping("/getCardsFromUser")
  public List<CardUser> getCardsFromUser(@RequestParam String username) {
    return cardUserService.getCardsFromUser(username);
  }
}
