package Freundesliste.Freundesliste.Chat;

import java.util.LinkedList;
import java.util.List;

import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity(name = "chat_instance")
public class ChatInstance {
    

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "is_private")
    private boolean isPrivate = true;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "creator_id", referencedColumnName = "id")
    private User creator;


    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
        name = "chat_user_instance", 
        joinColumns = @JoinColumn(name = "chat_instance_id"), 
        inverseJoinColumns = @JoinColumn(name = "user_id"))
    private List<User> entiltedUsers;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "chat_instance_id")
    private List<ChatMessage> chatMessages = new LinkedList<>();

    public List<ChatMessage> getChatMessages() {
        return chatMessages;
    }

    public void setChatMessages(List<ChatMessage> chatMessages) {
        this.chatMessages = chatMessages;
    }

    public boolean isPrivate() {
        return isPrivate;
    }

    public void setPrivate(boolean isPrivate) {
        this.isPrivate = isPrivate;
    }

    public User getCreator() {
        return creator;
    }

    public void setCreator(User creator) {
        this.creator = creator;
    }

    public List<User> getEntiltedUsers() {
        return entiltedUsers;
    }

    public void setEntiltedUsers(List<User> entiltedUsers) {
        this.entiltedUsers = entiltedUsers;
    }
}
