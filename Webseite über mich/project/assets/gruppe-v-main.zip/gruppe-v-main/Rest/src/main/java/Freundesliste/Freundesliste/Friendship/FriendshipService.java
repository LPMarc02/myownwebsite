package Freundesliste.Freundesliste.Friendship;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendshipService {

  @Autowired
  private FriendshipRepository friendshipRepository;

  public List<Friendship> getUserFriendships(Long userId) {
    return friendshipRepository.findByUserId(userId);
  }

  public void deleteFriendship(Long userId, Long friendId) {
    friendshipRepository.deleteByUserIdAndFriendId(userId, friendId);
    friendshipRepository.deleteByUserIdAndFriendId(friendId, userId);
  }
  public List<Friendship> getAllFriendships() {
    return friendshipRepository.findAll();
  }


}

