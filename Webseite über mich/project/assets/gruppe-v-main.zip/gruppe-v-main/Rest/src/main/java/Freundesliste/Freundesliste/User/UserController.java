package Freundesliste.Freundesliste.User;
import Freundesliste.Freundesliste.Spieler.PlayerService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import Freundesliste.Freundesliste.Spieler.Player;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/users")
public class UserController {
  public final UserService userService;
  @Autowired
  private PlayerService playerService;

  @Autowired
  public UserController(UserService userService, EntityManager entityManager) {
    this.userService = userService;
    this.entityManager = entityManager;
  }
  @Autowired
  private EntityManager entityManager;

  @PostMapping("/useradd")
  public User addUser(User user) {
    return userService.addUser(user);
  }

  @GetMapping("/getUserById")
  public User findUserById(@RequestParam Long id) {
    return userService.findUserById(id);
  }

  @GetMapping("/getUserByUsername")
  public User findUserByUsername(@RequestParam String username) {
    return userService.FindUserByUsername(username);
 }

  @DeleteMapping("/removeUser")
  public User removeUser(@RequestParam Long id) {
    return userService.removePlayer(id);
}

  @GetMapping("/searchUserByFirstNameAndLastName")
  public List<User> findFirstNameAndLastName(@RequestParam String firstName, @RequestParam String lastName) {
      return userService.searchUserByFirstNameAndLastName(firstName, lastName);
  }

  @GetMapping("/showAllUsers") //beispiel getanfrage = http://localhost80/api/players/getIdPlayer?id=7
  public List<User> getAllUsers() {
    return userService.getAllUser();
  }

  @GetMapping("/checklogin")
  public boolean checklogin(String username, String password) {
    Query query = entityManager.createQuery("SELECT COUNT(u) FROM User u WHERE u.username = :username AND u.password = :password");
    query.setParameter("username", username);
    query.setParameter("password", password);
    Long count = (Long) query.getSingleResult();
    return count > 0;
  }

  @GetMapping("/getMail")
  public String getMail(@RequestParam String username) {
    Query query = entityManager.createQuery("SELECT email FROM User u WHERE u.username = :username");
    query.setParameter("username", username);
    return query.getSingleResult().toString();
  }

  @PutMapping("/{id}/updateProfilePicture")
  public ResponseEntity<Player> updateProfilePicture(@PathVariable Long id, @RequestBody String profilePicture) {
    userService.updateProfilePicture(id, profilePicture);
    return ResponseEntity.ok().build();
  }

  @GetMapping("/getPermission")
  public boolean checkPermission(@RequestParam String username) {
    Query query = entityManager.createQuery("SELECT permission FROM User u WHERE u.username = :username");
    query.setParameter("username", username);
    String permissionString = (String) query.getSingleResult();
    return permissionString.equals("true");
  }
  @GetMapping("/getid")
  public Long getIdFromUser(@RequestParam String username) {
    Query query = entityManager.createQuery("SELECT id FROM User u WHERE u.username = :username");
    query.setParameter("username", username);
    return (Long) query.getSingleResult();
  }
  @PutMapping("/changePassword")
  public ResponseEntity<User> changePassword(@RequestBody User user) {
    String email = user.getEmail();
    String password = user.getPassword();
    userService.changePassword(email, password);
    return ResponseEntity.ok().build();
  }
  @GetMapping("/search")
  public List<User> searchUsersByUsername(@RequestParam String username) {
    return userService.searchUsersByUsername(username);
  }

  @GetMapping("/searchByUsername")
  public ResponseEntity<List<User>> searchByUsername(@RequestParam String username) {
    List<User> users = userService.searchUsersByUsername(username);
    return new ResponseEntity<>(users, HttpStatus.OK);
  }
  @PutMapping("/updateStatus/{id}")
  public ResponseEntity<Void> updateStatus(@PathVariable Long id, @RequestBody String status) {
    userService.updateStatus(id, status);
    return ResponseEntity.ok().build();
  }

 @PutMapping("/statusSetOnline")
  public void setOnlineStatus(@RequestBody User user) {
    userService.setUserStatus(user.getUsername(), user.getStatus());
 }
  @PutMapping("/{userId}/privacy")
  public User updateFriendListPrivacy(@PathVariable Long userId, @RequestBody Boolean friendListPrivate) {
    return userService.updateFriendListPrivacy(userId, friendListPrivate);
  }


}


