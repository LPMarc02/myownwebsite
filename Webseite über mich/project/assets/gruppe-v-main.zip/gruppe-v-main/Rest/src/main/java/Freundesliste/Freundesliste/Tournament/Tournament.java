package Freundesliste.Freundesliste.Tournament;
import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class Tournament {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;
  private String clanName;
  private String username1;
  private String username2;
  private String Winner;


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getUsername1() {
    return username1;
  }

  public void setUsername1(String username1) {
    this.username1 = username1;
  }

  public String getUsername2() {
    return username2;
  }

  public void setUsername2(String username2) {
    this.username2 = username2;
  }

  public String getWinner() {
    return Winner;
  }

  public void setWinner(String winner) {
    Winner = winner;
  }

  public String getClanName() {
    return clanName;
  }

  public void setClanName(String clanName) {
    this.clanName = clanName;
  }
}
