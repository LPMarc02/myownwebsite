package Freundesliste.Freundesliste.Game;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/games")
public class GameController {

  @Autowired
  private GameService gameService;

  @PostMapping("/add")
  public ResponseEntity<Game> addGameSession(@RequestBody Game game) {
    Game savedGame = gameService.createGameSession(game);
    return ResponseEntity.ok(savedGame);
  }

  @PatchMapping("/update/{sessionId}/{username}")
  public ResponseEntity<Game> updateGameSession(@PathVariable String sessionId, @PathVariable String username, @RequestBody Game updatedGame) {
    Game updatedGameSession = gameService.updateGameSession(sessionId, username, updatedGame);
    return ResponseEntity.ok(updatedGameSession);
  }


  @GetMapping("/{id}")
  public ResponseEntity<Optional<Game>> getGameSession(@PathVariable Long id) {
    Optional<Game> game = gameService.getGameSession(id);
    return ResponseEntity.ok(game);
  }

  @GetMapping("/sessionId/{sessionId}")
  public ResponseEntity<Game> getGameBySessionId(@PathVariable String sessionId) {
    Game game = gameService.getGameBySessionId(sessionId);
    return ResponseEntity.ok(game);
  }

  @GetMapping("/username/{username}")
  public ResponseEntity<Game> getGameByUsername(@PathVariable String username) {
    Game game = gameService.getGameByUsername(username);
    return ResponseEntity.ok(game);
  }

  @DeleteMapping("/delete/{username}")
  public ResponseEntity<Void> deleteGameSession(@PathVariable String username) {
    gameService.deleteGameSessionByUsername(username);
    return ResponseEntity.noContent().build();
  }

  @GetMapping("/playerRole/{playerRole}")
  public ResponseEntity<Game> getGameByPlayerRole(@PathVariable String playerRole) {
    Game game = gameService.getGameByPlayerRole(playerRole);
    return ResponseEntity.ok(game);
  }

  @GetMapping("/deckId/{deckId}")
  public ResponseEntity<Game> getGameByDeckId(@PathVariable Long deckId) {
    Game game = gameService.getGameByDeckId(deckId);
    return ResponseEntity.ok(game);
  }

  @GetMapping("/gameMode/{gameMode}")
  public ResponseEntity<Game> getGameByGameMode(@PathVariable int gameMode) {
    Game game = gameService.getGameByGameMode(gameMode);
    return ResponseEntity.ok(game);
  }

  @DeleteMapping("/deleteSession/{session}")
  public void deleteSession(@PathVariable String session) {
    this.gameService.deleteSession(session);
  }
}
