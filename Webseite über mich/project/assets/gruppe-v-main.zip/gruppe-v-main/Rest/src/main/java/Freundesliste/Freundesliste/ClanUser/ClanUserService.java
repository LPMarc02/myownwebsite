package Freundesliste.Freundesliste.ClanUser;
import Freundesliste.Freundesliste.Clan.Clan;
import Freundesliste.Freundesliste.Clan.ClanRepository;
import Freundesliste.Freundesliste.Lootboxen.Lootboxen;
import Freundesliste.Freundesliste.Lootboxen.LootboxenService;
import Freundesliste.Freundesliste.Spieler.PlayerService;
import org.springframework.stereotype.Service;

@Service
public class ClanUserService {
  private final ClanUserRepository clanUserRepository;
  private final ClanRepository clanRepository;
  private final PlayerService playerService;
  private final LootboxenService lootboxenService;

  public ClanUserService(ClanUserRepository clanUserRepository, ClanRepository clanRepository, PlayerService playerService, LootboxenService lootboxenService) {
    this.clanUserRepository = clanUserRepository;
    this.clanRepository = clanRepository;
    this.playerService = playerService;
    this.lootboxenService = lootboxenService;
  }

//Nils Wenzel
  public Clan findClanByUsername(String username) {
    ClanUser clanUser = this.clanUserRepository.findByUsername(username);
    return this.clanRepository.findByClanname(clanUser.getClanname());
  }

  public ClanUser[] findClanByClanname(String clanname) {
    return this.clanUserRepository.findByClanname(clanname);
  }

  public ClanUser findUserClanByUsername(String username) {
    return this.clanUserRepository.findByUsername(username);
  }

  public void saveClanUser(String username, String clanname) {
    ClanUser clanUser;
    clanUser = new ClanUser();
    clanUser.setClanname(clanname);
    clanUser.setUsername(username);
    clanUser.setRequestAccepted(0);
    this.clanUserRepository.save(clanUser);
  }

  public void setBet(String user, String bet) {
    ClanUser clanUser = this.clanUserRepository.findByUsername(user);
    clanUser.setBet(bet);
    this.clanUserRepository.save(clanUser);
  }

  public void deleteByUsername(String username) {
    ClanUser clanUser = this.clanUserRepository.findByUsername(username);
    Clan clan = this.clanRepository.findByClanname(clanUser.getClanname());
    if(this.clanUserRepository.findByClanname(clan.getClanname()).length == 1 ){
      this.clanRepository.delete(clan);
    }
    this.clanUserRepository.delete(clanUser);
  }

  public void resolveBet(String winner) {
    ClanUser[] clanUser = this.clanUserRepository.findByBet(winner);
    for (ClanUser user : clanUser) {
      this.playerService.updateSEP(user.getUsername(), (long) -50);
      Lootboxen lootbox = new Lootboxen();
      lootbox.setUsername(user.getUsername());
      lootbox.setBox("goldBox");
      this.lootboxenService.save(lootbox);
    }
    deleteBets(winner);
  }

  public void deleteBets(String winner) {
    ClanUser clanUser = this.clanUserRepository.findByUsername(winner);
    ClanUser[] clanUsers = this.clanUserRepository.findByClanname(clanUser.getClanname());
    for (ClanUser user : clanUsers) {
      user.setBet(null);
      this.clanUserRepository.save(user);
    }
  }

//Marc Prüfer
  public void setRequestAccepted(String username){
    ClanUser clanUser = this.clanUserRepository.findByUsername(username);
    clanUser.setRequestAccepted(1);
    this.clanUserRepository.save(clanUser);
  }

  public void setRequestNull(String username){
    ClanUser clanUser = this.clanUserRepository.findByUsername(username);
    clanUser.setRequestAccepted(0);
    this.clanUserRepository.save(clanUser);
  }
}
