package Freundesliste.Freundesliste.DeckCards;

import Freundesliste.Freundesliste.Deck.model.Deck;
import Freundesliste.Freundesliste.cards.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DeckCardRepository extends JpaRepository<CardToDecks, Long> {
  CardToDecks findByDeckIdAndCardId(Long deckId, Long cardId);
  CardToDecks findByDeckId(long deckId);
  List<CardToDecks> findAllByDeckId(Long deckId); // Custom query to find all decks with specific ID
}
