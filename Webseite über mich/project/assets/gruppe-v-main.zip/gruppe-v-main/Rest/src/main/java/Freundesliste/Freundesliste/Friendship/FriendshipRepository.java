package Freundesliste.Freundesliste.Friendship;

import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface FriendshipRepository extends JpaRepository<Friendship, Long> {

  List<Friendship> findByUserId(Long userId);



  @Transactional
  @Modifying
  @Query("DELETE FROM Friendship f WHERE f.userId = :userId AND f.friendId = :friendId")
  void deleteByUserIdAndFriendId(Long userId, Long friendId);


}
