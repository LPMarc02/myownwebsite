package Freundesliste.Freundesliste.DuellRequests;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/duell-request")
public class DuellRequestController {

  private final DuellRequestService duellRequestService;

  @Autowired
  public DuellRequestController(DuellRequestService duellRequestService) {
    this.duellRequestService = duellRequestService;
  }

  @PostMapping("/checkRequest")
  public String checkRequest(@RequestBody DuellRequest duellRequest) {
    return duellRequestService.check(duellRequest);
  }

  @PostMapping("/addRequest")
  public void save(@RequestBody DuellRequest duellRequest) {
    duellRequestService.save(duellRequest);
  }

  @GetMapping("/getRequestAsReceiver")
  public DuellRequest getRequestAsReceiver(@RequestParam("receiver") String receiver) {
    return duellRequestService.findByReceiver(receiver);
  }

  @GetMapping("/getRequestAsSender")
  public DuellRequest getRequestAsSender(@RequestParam("sender") String sender) {
    return duellRequestService.findBySender(sender);
  }

  @DeleteMapping("/deleteRequest")
  public void delete(@RequestParam("sender") String sender) {
    duellRequestService.deleteBySender(sender);
  }

  @PutMapping("/updateRequest")
  public void update(@RequestParam("sender") String sender, @RequestBody String status) {
    duellRequestService.updateStatusBySender(sender, status);
  }


}
