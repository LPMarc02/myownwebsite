package Freundesliste.Freundesliste.Chat;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import Freundesliste.Freundesliste.User.User;
import Freundesliste.Freundesliste.User.UserService;

@Service
public class ChatService {
    

    private final ChatInstanceRepository chatRepository;
    private final ChatMessageRepository chatMessageRepository;

    private final UserService userService;


    
    public ChatService(ChatInstanceRepository chatRepository, UserService userService, ChatMessageRepository chatMessageRepository) {
        this.chatRepository = chatRepository;
        this.userService = userService;
        this.chatMessageRepository = chatMessageRepository;
    }


    List<ChatInstance> getChatInstancesWithAccessRights(String username) {

        List<ChatInstance> chatInstances = chatRepository.findAll();

        List<ChatInstance> alowed = chatInstances.stream().filter(instance -> {
            boolean isSelf = instance.getCreator().getUsername().equals(username);
            boolean isInEntitledUsers = instance
                .getEntiltedUsers()
                .stream()
                .map(User::getUsername)
                .anyMatch(enUsername -> enUsername.equals(username));

            return isInEntitledUsers || isSelf;
        }).collect(Collectors.toList());
        return alowed;
    }



    public void createNewChat(Object payload) {
        if(payload instanceof LinkedHashMap) {
            LinkedHashMap map = (LinkedHashMap) payload;
            String username = (String) map.get("creator");
            List<String> entUser = (List<String>) map.get("entitledUsers");


            List<User> allUser = userService.getAllUser();

            User creator = allUser.stream().filter(user -> user.getUsername().equals(username)).findFirst().orElseThrow();

             List<User> chattsWith = allUser.stream().filter(user ->  entUser.contains(user.getUsername())).collect(Collectors.toList());


            ChatInstance chatInstance = new ChatInstance();
            chatInstance.setCreator(creator);
            chatInstance.setPrivate(false);
            chatInstance.setEntiltedUsers(chattsWith);
            chatInstance.setChatMessages(List.of());
            chatRepository.save(chatInstance);


        } else {
            throw new RuntimeException("message is not like");
        }


    }


    public void saveMessage(Object payload) {
        if(payload instanceof LinkedHashMap) {
            LinkedHashMap map = (LinkedHashMap) payload;
            String username = (String) map.get("creator");
            String message = (String) map.get("message");
            Integer chatInstanceId = (Integer) map.get("chatInstanceId");



            List<User> allUser = userService.getAllUser();

            User creator = allUser.stream().filter(user -> user.getUsername().equals(username)).findFirst().orElseThrow();
            ChatInstance i = chatRepository.findById(new Long(chatInstanceId)).orElseThrow();


            ChatMessage chatMessage = new ChatMessage();
            chatMessage.setOwner(creator);
            chatMessage.setMessage(message);
            chatMessage.setTimestamp(Instant.now());
            chatMessage.setSeenByOthers(false);
            chatMessage.setChatInstanceId(i.getId());

            i.getChatMessages().add(chatMessage);
            chatRepository.save(i);


        } else {
            throw new RuntimeException("message is not like");
        }
    }


    public void markMessagesAsSeenByOthers(Object payload) {
        // TODO Auto-generated method stub
        if(payload instanceof List) {
            List<Long> map = ((List<Integer>) payload).stream().map(p -> new Long(p)).collect(Collectors.toList());
            List<ChatMessage> chats = chatMessageRepository.findAllById(map);
            chats.forEach(chat -> chat.setSeenByOthers(true));
            chatMessageRepository.saveAll(chats);

        } else {
            throw new RuntimeException("message is not like");
        }
    }


    public void deleteMessage(Object payload) {
        if(payload instanceof List) {
            List<Long> longIds = ((List<Integer>) payload).stream().map(p -> new Long(p)).collect(Collectors.toList());
            chatMessageRepository.deleteAllById(longIds);

        } else {
            throw new RuntimeException("message is not like");
        }
    }
    
}
