package Freundesliste.Freundesliste.Lootboxen;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/lootboxen")
public class LootboxenController {

  private final LootboxenService lootboxenService;

  public LootboxenController(LootboxenService lootboxenService) {
    this.lootboxenService = lootboxenService;
  }

  @PostMapping("/addBox")
  public Lootboxen save(@RequestBody Lootboxen lootboxen) {
    return lootboxenService.save(lootboxen);
  }
  @GetMapping("/getLootBoxen")
  public List<Lootboxen> getLootBoxen(@RequestParam String username) {
    return lootboxenService.getLootBoxen(username);
  }
  @DeleteMapping("/deleteBox")
  public void deleteLootBoxen(@RequestParam Long number) {
    lootboxenService.deleteLootBoxen(number);
  }

}
