package Freundesliste.Freundesliste.cards;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CardService {
    private final CardRepository cardRepository;

    @Autowired
    public CardService(CardRepository CardRepository) { this.cardRepository = CardRepository; }

    public List<Card> getAllCards() {
        return cardRepository.findAll();
    }

    public Card getCardById(Long id) {
        return cardRepository.findById(id).orElse(null);
    }

    public void deleteCard(Long id) {
    cardRepository.deleteById(id);
  }

    public Card addCard(Card card) {
      return cardRepository.save(card);
    }

    public Card getCard(Long id) {
      return cardRepository.findById(id).orElse(null);
    }


}
