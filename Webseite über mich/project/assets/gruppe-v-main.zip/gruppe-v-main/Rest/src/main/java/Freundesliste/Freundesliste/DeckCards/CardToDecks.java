package Freundesliste.Freundesliste.DeckCards;

import jakarta.persistence.*;

@Entity
@Table(name = "deck_cards")
public class CardToDecks {

  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  //@ManyToOne
  @JoinColumn(name = "deckId")
  private Long deckId;

  //@ManyToOne
  @JoinColumn(name = "cardId")
  private Long cardId;

  @Column(name = "quantity")
  private int quantity;

  public Long getcardId() {
    return cardId;
  }

  public void setcardId(Long cardId) {
    this.cardId = cardId;
  }

  public Long getdeckId() {
    return deckId;
  }

  public void setdeckId(Long deckId) {
    this.deckId = deckId;
  }

  public Long getId() {
    return id;
  }
  public void setId(long id) {
    this.id = id;
  }
/*
  public Deck getDeck() {
    return deck;
  }

  public void setDeck(Deck deck) {
    this.deck = deck;
  }

  public Card getCard() {
    return card;
  }

  public void setCard(Card card) {
    this.card = card;
  }
 */

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }
// Getters and setters
}
