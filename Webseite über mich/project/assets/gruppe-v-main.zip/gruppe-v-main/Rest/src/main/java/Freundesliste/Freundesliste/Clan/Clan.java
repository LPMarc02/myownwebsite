package Freundesliste.Freundesliste.Clan;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Clan {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String clanname;
  private String request;

  public Clan() {}

  public Long getId() {
    return id;
  }

  public String getClanname() {
    return clanname;
  }

  public void setClanname(String clanname) {
    this.clanname = clanname;
  }

  public String getRequest() {
    return request;
  }

  public void setRequest(String request) {
    this.request = request;
  }
}
