package Freundesliste.Freundesliste.Deck.model;

import Freundesliste.Freundesliste.firendModel.Friend;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DeckRepository extends JpaRepository<Deck, Long> {
  List<Deck> findByDeckuser(String deckuser);
}
