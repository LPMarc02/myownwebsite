package Freundesliste.Freundesliste.email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("api/users")
public class emailcontroller {

  @Autowired
  private emailservice emailservice;

  @PostMapping("/sendMail/")
  public ResponseEntity<Object> sendMail(@RequestBody email body) {
    return emailservice.sendMail(body);
  }


}
