package Freundesliste.Freundesliste.FriendRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/friend-request")
public class FriendRequestController {

  @Autowired
  private FriendRequestService friendRequestService;

  @GetMapping("/pending")
  public List<FriendRequest> getPendingFriendRequests(@RequestParam Long receiverId) {
    return friendRequestService.getPendingFriendRequests(receiverId);
  }
  @GetMapping("/sent")
  public List<FriendRequest> getSentFriendRequests(@RequestParam Long senderId) { // Anpassung hier
    return friendRequestService.getSentFriendRequests(senderId);
  }

  @PostMapping("/send")
  public ResponseEntity<String> sendFriendRequest(@RequestBody FriendRequest friendRequest) {
    friendRequestService.sendFriendRequest(friendRequest);
    return ResponseEntity.ok("");
  }

  @PutMapping("/accept/{requestId}")
  public void acceptFriendRequest(@PathVariable Long requestId) {
    friendRequestService.acceptFriendRequest(requestId);
  }

  @DeleteMapping("/reject/{requestId}")
  public void rejectFriendRequest(@PathVariable Long requestId) {
    friendRequestService.rejectFriendRequest(requestId);
  }
  @GetMapping("/receiver/{receiverId}")
  public List<FriendRequest> getFriendRequestsForUser(@PathVariable Long receiverId) {
    return friendRequestService.getFriendRequestsForUser(receiverId);
  }
}
