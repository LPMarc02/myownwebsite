package Freundesliste.Freundesliste.DeckCards;

import Freundesliste.Freundesliste.Deck.model.Deck;
import Freundesliste.Freundesliste.Deck.model.DeckRepository;
import Freundesliste.Freundesliste.cards.Card;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DeckService {
  @Autowired
  private DeckRepository deckRepository;

  @Autowired
  private DeckCardRepository cardToDecksRepository;

  public CardToDecks addCardToDeck(Deck deck, Card card) {
    //Deck deck = deckRepository.findById(deckId).orElseThrow(() -> new RuntimeException("Deck not found"));
    CardToDecks carddecks = cardToDecksRepository.findByDeckIdAndCardId(deck.getId(), card.getId());
    Deck testDeck = new Deck();
    testDeck.setDeckId(deck.getId());
    if (carddecks != null) {
      carddecks.setQuantity(carddecks.getQuantity() + 1);
    } else {
      carddecks = new CardToDecks();
      carddecks.setdeckId(deck.getId());
      carddecks.setcardId(card.getId());
      carddecks.setQuantity(1);
    }


    return cardToDecksRepository.save(carddecks);
  }

  public int getQuantity(Long deck_id) {
    List<CardToDecks> carddecks = cardToDecksRepository.findAllByDeckId(deck_id);
    int quantity = 0;
    for (CardToDecks carddeck : carddecks) {
      Long deckId = carddeck.getdeckId();
      boolean isEqual = deckId.equals(deck_id);
      if (isEqual) {
        quantity += carddeck.getQuantity();
      }
    }
    return quantity;
  }

  public Long[] getCardIds(Long deck_id) {
    List<CardToDecks> carddecks = cardToDecksRepository.findAllByDeckId(deck_id);
    List<Long> idList = new ArrayList<>();

    for (CardToDecks carddeck : carddecks) {
      Long deckId = carddeck.getdeckId();
      Long cardId = carddeck.getcardId();

      if (deckId != null && deckId.equals(deck_id) && cardId != null) {
        for (int i = 0; i < carddeck.getQuantity(); i++) {
          idList.add(cardId);
        }
      }
    }

    return idList.toArray(new Long[0]);
  }
}
