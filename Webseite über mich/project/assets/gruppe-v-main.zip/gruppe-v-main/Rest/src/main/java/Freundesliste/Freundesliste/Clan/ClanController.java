package Freundesliste.Freundesliste.Clan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/clan")
public class ClanController {
  private final ClanService clanService;

  @Autowired
  public ClanController(ClanService clanService) {
    this.clanService = clanService;
  }

//Nils Wenzel
  @GetMapping("/clans")
  public List<Clan> getAllClans() {
    return clanService.getAllClans();
  }

  @PostMapping("/createClan")
  public void createClan(@RequestBody String clanname) {
    clanService.createClan(clanname);
  }

//Marc Prüfer
  @PutMapping("/setRequest/{status}")
  public void setRequest(@RequestBody Clan clan, @PathVariable String status) {
    this.clanService.setRequest(status,clan);
  }

}
