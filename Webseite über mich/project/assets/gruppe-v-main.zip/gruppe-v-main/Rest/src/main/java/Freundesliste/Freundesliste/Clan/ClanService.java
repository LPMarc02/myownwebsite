package Freundesliste.Freundesliste.Clan;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClanService {
  private final ClanRepository clanRepository;

  public ClanService(ClanRepository clanRepository) {
    this.clanRepository = clanRepository;
  }

//Nils Wenzel
  public List<Clan> getAllClans() {
    return clanRepository.findAll();
  }

  public void createClan(String clanname) {
    Clan clan = new Clan();
    clan.setClanname(clanname);
    clanRepository.save(clan);
  }

//Marc Prüfer
  public void setRequest(String request, Clan clan) {
    clan.setRequest(request);
    clanRepository.save(clan);
  }

}
