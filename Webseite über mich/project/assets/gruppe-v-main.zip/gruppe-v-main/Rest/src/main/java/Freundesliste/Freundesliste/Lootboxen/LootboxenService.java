package Freundesliste.Freundesliste.Lootboxen;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LootboxenService {
  private final LootboxenRepository lootboxenRepository;

  public LootboxenService(LootboxenRepository lootboxenRepository) {
    this.lootboxenRepository = lootboxenRepository;
  }

  public Lootboxen save(Lootboxen lootboxen) {
    return lootboxenRepository.save(lootboxen);
  }
  public List<Lootboxen> getLootBoxen(String username) {
    return lootboxenRepository.findAllByUsername(username);
  }
  public void deleteLootBoxen(long number) {
    lootboxenRepository.deleteById(number);
  }

}
