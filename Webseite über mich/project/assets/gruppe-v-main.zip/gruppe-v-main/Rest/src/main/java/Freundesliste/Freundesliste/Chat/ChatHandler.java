package Freundesliste.Freundesliste.Chat;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import org.springframework.stereotype.Service;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ChatHandler extends TextWebSocketHandler {
 

    private final ChatService chatService;
    private final ObjectMapper objectMapper;
    // private final List<WebSocketSession> sessions = new CopyOnWriteArrayList<>();

    private final Map<String, WebSocketSession> usernameToSession = new HashMap<>();
    
    private final String INIT_CHATS = "INIT_CHATS";
    private final String CREATE_CHAT = "CREATE_CHAT";
    private final String MESSAGE = "MESSAGE";
    private final String MESSAGES_SEEN = "MESSAGES_SEEN";
    private final String DELETE_MESSAGE = "DELETE_MESSAGE";
    private final String CHANGE_MESSAGE = "CHANGE_MESSAGE";

    public ChatHandler(ChatService chatService,  ObjectMapper objectMapper) {
        this.chatService = chatService;
        this.objectMapper = objectMapper;
    }


    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {

    }


    private String loadChatsByUsername(String usernaname) throws JsonProcessingException {
        List<ChatInstance> chatInstancesByUsername = chatService.getChatInstancesWithAccessRights(usernaname);
        SimpleWebSocketMessage simpleWebSocketMessage = new SimpleWebSocketMessage();
        simpleWebSocketMessage.setMessageType( INIT_CHATS);
        simpleWebSocketMessage.setPayload( chatInstancesByUsername);

       String writeValueAsString = objectMapper.writeValueAsString(simpleWebSocketMessage);
        return writeValueAsString;
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        // TODO Auto-generated method stub

        System.out.println(message);

        SimpleWebSocketMessage recieved = objectMapper.readValue(message.getPayload(), SimpleWebSocketMessage.class);

        System.out.println(recieved);

        if(recieved.getMessageType().equals(CREATE_CHAT)) {
            chatService.createNewChat(recieved.getPayload());
        } else if(recieved.getMessageType().equals(MESSAGE)) {
            chatService.saveMessage(recieved.getPayload());
        } else if(recieved.getMessageType().equals(INIT_CHATS)) {
            String username = recieved.getUsername();
            usernameToSession.put(username, session);
        } else if(recieved.getMessageType().equals(MESSAGES_SEEN)) {
            chatService.markMessagesAsSeenByOthers(recieved.getPayload());
        } else if(recieved.getMessageType().equals(DELETE_MESSAGE)) {
            chatService.deleteMessage(recieved.getPayload());
        }   else if(recieved.getMessageType().equals(CHANGE_MESSAGE)) {

        }
            
        

        for (Map.Entry<String, WebSocketSession> entry : usernameToSession.entrySet()) {

            String allChats = loadChatsByUsername(entry.getKey());
            
            try {
                if( entry.getValue().isOpen() ) {
                    entry.getValue().sendMessage(new TextMessage(allChats));
                }
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }



    }

    @Override
    protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) {
        // TODO Auto-generated method stub
        super.handleBinaryMessage(session, message);
    }

    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
        // TODO Auto-generated method stub
        super.handleMessage(session, message);
    }

    @Override
    public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
        // TODO Auto-generated method stub
        super.handleTransportError(session, exception);
    }


}
