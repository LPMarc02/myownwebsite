package Freundesliste.Freundesliste.Friendship;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Friendship {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String friendName;
  private Long userId; // Benutzer-ID
  private Long friendId; // Freund-ID


  public Friendship() {

  }

  public Friendship(String friendName,Long userId, Long friendId ) {
    this.userId = userId;
    this.friendId = friendId;
    this.friendName = friendName;
  }

  public String getFriendName() {
    return friendName;
  }

  public void setFriendName(String friendName) {
    this.friendName = friendName;
  }


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public Long getUserId() {

    return userId;
  }

  public void setUserId(Long userId) {
    this.userId = userId;

  }

  public Long getFriendId() {
    return friendId;

  }

  public void setFriendId(Long friendId) {
    this.friendId = friendId;

  }


}

