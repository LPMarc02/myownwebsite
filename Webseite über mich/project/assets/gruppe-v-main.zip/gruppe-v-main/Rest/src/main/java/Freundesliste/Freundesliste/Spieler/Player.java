package Freundesliste.Freundesliste.Spieler;

import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.Entity;


@Entity
public class Player extends User {

  private Long sepCoins;
  private Long leaderboard;

  public Long getLeaderboard() {
    return leaderboard;
  }

  public void setLeaderboard(Long leaderboard) {
    this.leaderboard = leaderboard;
  }

  public Player() {
    super();
  }

//  public Player(Long sepCoins, Long leaderboard) {
//    super();
//    this.sepCoins = sepCoins;
//    this.leaderboard = leaderboard;
//
//  }


  //   Getter und Setter für 'sepCoins'
  public Long getSepCoins() {
    return sepCoins;
  }

  public void setSepCoins(Long sepCoins) {
    this.sepCoins = sepCoins;
  }
}


