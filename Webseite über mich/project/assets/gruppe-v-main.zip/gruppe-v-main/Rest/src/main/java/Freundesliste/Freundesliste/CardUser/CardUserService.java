package Freundesliste.Freundesliste.CardUser;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CardUserService {

  private final CardUserRepository cardUserRepository;

  public CardUserService(CardUserRepository cardUserRepository) {
    this.cardUserRepository = cardUserRepository;
  }

  public void addCardsToUser(CardUser cardUser) {
    cardUserRepository.save(cardUser);
  }

  public List<CardUser> getCardsFromUser(String username) {
    return cardUserRepository.findAllByUsername(username);
  }
}
