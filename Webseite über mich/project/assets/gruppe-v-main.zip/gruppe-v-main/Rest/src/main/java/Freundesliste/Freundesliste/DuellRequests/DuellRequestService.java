package Freundesliste.Freundesliste.DuellRequests;

import Freundesliste.Freundesliste.Deck.model.Deck;
import Freundesliste.Freundesliste.Deck.model.DeckRepository;
import Freundesliste.Freundesliste.Spieler.Player;
import Freundesliste.Freundesliste.Spieler.PlayerService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DuellRequestService {

  private final DuellRequestRepository duellRequestRepository;
  private final PlayerService playerService;
  private final DeckRepository deckRepository;

  public DuellRequestService(DuellRequestRepository duellRequestRepository, PlayerService playerService, DeckRepository deckRepository) {
    this.duellRequestRepository = duellRequestRepository;
    this.playerService = playerService;
    this.deckRepository = deckRepository;
  }

  public String check(DuellRequest duellRequest) {
    Player receiver = playerService.findPlayerByUsername(duellRequest.getReceiver());
    List<Deck> receiverDeck = deckRepository.findByDeckuser(receiver.getUsername());
    Player sender = playerService.findPlayerByUsername(duellRequest.getSender());
    List<Deck> senderDeck = deckRepository.findByDeckuser(sender.getUsername());
    String answer;

    if(receiver.getStatus().equals("online")) {
      if(!receiverDeck.isEmpty()){
        if(!senderDeck.isEmpty()){
          answer = "true";
        }else{
          answer = "sender no deck";
        }
      }else{
        answer = "receiver no deck";
      }
    }else if(receiver.getStatus().equals("ingame")){
      answer = "receiver ingame";
    }else{
      answer = "receiver offline";
    }
    return answer;
  }

  public void save(DuellRequest duellRequest) {
    duellRequestRepository.save(duellRequest);
  }

  public DuellRequest findByReceiver(String receiver){
    return duellRequestRepository.findByReceiver(receiver);
  }

  public DuellRequest findBySender(String sender){
    return duellRequestRepository.findBySender(sender);
  }

  public void deleteBySender(String sender) {
    duellRequestRepository.deleteBySender(sender);
  }

  public void updateStatusBySender(String sender, String status) {
    duellRequestRepository.updateStatusBySender(sender, status);
  }
}
