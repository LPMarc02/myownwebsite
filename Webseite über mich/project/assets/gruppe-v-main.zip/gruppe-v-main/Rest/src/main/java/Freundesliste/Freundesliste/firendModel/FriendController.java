package Freundesliste.Freundesliste.firendModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/friends")
public class FriendController {

  private final FriendService friendService;

  @Autowired
  public FriendController(FriendService friendService) {
    this.friendService = friendService;
  }

  @PostMapping("/add")
  public void addFriend(@RequestParam Long userId, @RequestParam Long friendId) {
    friendService.addFriend(userId, friendId);
  }

  @DeleteMapping("/remove")
  public void removeFriend(@RequestParam Long userId, @RequestParam Long friendId) {
    friendService.removeFriend(userId, friendId);
  }

  @GetMapping("/{userId}")
  public List<Friend> getFriends(@PathVariable Long userId) {
    return friendService.getFriends(userId);
  }
}
