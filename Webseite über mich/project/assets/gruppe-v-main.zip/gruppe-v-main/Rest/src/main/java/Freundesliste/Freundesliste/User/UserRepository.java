package Freundesliste.Freundesliste.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserRepository extends JpaRepository<User, Long> {
  User findByUsername(String username);
  User findByEmail(String email);
  List <User> findByFirstNameAndLastName(String firstName, String lastName);
  List<User> findByUsernameContaining(String username);
  List<User> findByUsernameContainingIgnoreCase(String username);

}
