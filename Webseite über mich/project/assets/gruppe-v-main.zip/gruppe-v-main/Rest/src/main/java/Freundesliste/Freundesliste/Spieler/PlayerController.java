package Freundesliste.Freundesliste.Spieler;

import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/players")
@CrossOrigin(origins = "http://localhost:4200")
public class PlayerController {

  public final PlayerService playerService;

  @Autowired
  public PlayerController(PlayerService playerService, EntityManager entityManager) {
    this.playerService = playerService;
    this.entityManager = entityManager;
  }
  @Autowired
  private EntityManager entityManager;

  @PostMapping("/addd")
  public Player addPlayer(@RequestBody Player player) {
    return playerService.addPlayer(player);
  }

  @GetMapping("/getPlayerById")
  public Player getPlayerById(@RequestParam Long id) {
    return playerService.getPlayer(id);
  }

  @GetMapping("/getPlayerByUsername")
  public Player findPlayerByUsername(@RequestParam String username) { return playerService.findPlayerByUsername(username); }

  @DeleteMapping("/deletePlayer")
  public Player removePlayer(@RequestParam Long id) {
    return playerService.removePlayer(id);
  }

  @GetMapping("/showAllPlayers") //beispiel getanfrage = http://localhost80/api/players/getIdPlayer?id=7
  public List<Player> getAllPlayers() {
    return playerService.getAllPlayers();
  }

  @PutMapping("/{id}/updateProfilePicture")
  public ResponseEntity<Player> updateProfilePicture(@PathVariable Long id, @RequestBody String profilePicture) {
    playerService.updateProfilePicture(id, profilePicture);
    return ResponseEntity.ok().build();
  }

  @GetMapping("/getSepCoins")
  public Long getSepCoins(@RequestParam String username) {
    Query query = entityManager.createQuery("SELECT sepCoins FROM Player u WHERE u.username = :username");
    query.setParameter("username", username);
    return (Long) query.getSingleResult();
  }

  @GetMapping("/getLeaderboard")
  public Long getLeaderboard(@RequestParam String username) {
    Query query = entityManager.createQuery("SELECT leaderboard FROM Player u WHERE u.username = :username");
    query.setParameter("username", username);
    return (Long) query.getSingleResult();
  }

  public static class LeaderboardUpdateRequest {
    private String username;
    private Long points;

    public String getUsername() {
      return username;
    }

    public void setUsername(String username) {
      this.username = username;
    }

    public Long getPoints() {
      return points;
    }

    public void setPoints(Long points) {
      this.points = points;
    }
  }

  @PatchMapping("/setLeaderboard")
  public ResponseEntity<Void> setLeaderboard(@RequestBody LeaderboardUpdateRequest request) {
    playerService.setLeaderboard(request.username, request.points);
    return ResponseEntity.ok().build();
  }



  @PutMapping("/{price}/updateSEP")
  public void updateSEP(@RequestBody String username, @PathVariable Long price) {
    playerService.updateSEP(username,price);
  }
  @GetMapping("/leaderboard")
  public List<Player> getAllPlayer() {
    return playerService.getAllPlayer();
  }
  @GetMapping("/search")
  public List<Player> searchUsersByUsername(@RequestParam String username) {
    return playerService.searchUsersByUsername(username);
  }

  @GetMapping("/getUserByUsername")
  public User findUserByUsername(@RequestParam String username) {
    return playerService.FindUserByUsername(username);
  }








}

