package Freundesliste.Freundesliste.DeckCards;

import Freundesliste.Freundesliste.Deck.model.Deck;
import Freundesliste.Freundesliste.Deck.model.DeckRepository;
import Freundesliste.Freundesliste.cards.Card;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:4200")
public class DeckCardsController {

  @Autowired
  private DeckService deckService;

  @Autowired
  private DeckCardRepository deckCardsRepository;

  @Autowired
  private final DeckRepository deckRepository;

  public DeckCardsController(DeckRepository deckRepository) {this.deckRepository = deckRepository;}

  @PostMapping("/deck_cards")
  public CardToDecks addCardToDeck(@RequestBody DeckCardRequest request) {
    Long deck = request.getDeckId();
    Long card = request.getCardId();
      //deckRepository.findById(deckId).orElseThrow(() -> new RuntimeException("Deck not found"));
    CardToDecks carddecks = deckCardsRepository.findByDeckIdAndCardId(request.getDeckId(), request.getCardId());
    if (carddecks != null) {
      carddecks.setQuantity(carddecks.getQuantity() + 1);
    } else {
      carddecks = new CardToDecks();
      carddecks.setdeckId(deck);
      carddecks.setcardId(card);
      carddecks.setQuantity(1);
    }
    return deckCardsRepository.save(carddecks);
  }
  @GetMapping("/getQuantity")
  public int getQuantity(Long deck_id) {
    return deckService.getQuantity(deck_id);
  }

  @GetMapping("/getCardIds")
  public Long[] getCardIds(Long deck_id) {
    return deckService.getCardIds(deck_id);
  }

  @DeleteMapping("/deleteCard/{deckId}/{cardId}")
  public ResponseEntity<String> deleteCard(@PathVariable Long deckId, @PathVariable Long cardId) {
    // Find the entry in deckCards
    CardToDecks cardDeck = deckCardsRepository.findByDeckIdAndCardId(deckId, cardId);

    // If an entry is found
    if (cardDeck != null) {
      // If quantity is greater than 1, decrement it
      if (cardDeck.getQuantity() > 1) {
        cardDeck.setQuantity(cardDeck.getQuantity() - 1);
        deckCardsRepository.save(cardDeck);
        return ResponseEntity.ok().build();
      } else {
        // If quantity is 1, delete the entry
        deckCardsRepository.delete(cardDeck);
        return ResponseEntity.ok().build();
      }
    }
    return ResponseEntity.notFound().build();
  }


    public static class DeckCardRequest {
      private Long deckId;
      private Long cardId;

      public DeckCardRequest(Long deckId, Long cardId) {
        this.deckId = deckId;
        this.cardId = cardId;
      }

      public Long getDeckId() {
        return deckId;
      }

      public void setDeckId(Long deckId) {
        this.deckId = deckId;
      }

      public Long getCardId() {
        return cardId;
      }

      public void setCardId(Long cardId) {
        this.cardId = cardId;
      }
// Getters and setters for deckId and cardId
    }

}
