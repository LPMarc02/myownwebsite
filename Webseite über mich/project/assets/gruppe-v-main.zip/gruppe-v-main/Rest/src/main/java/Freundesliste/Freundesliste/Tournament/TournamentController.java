package Freundesliste.Freundesliste.Tournament;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/tournament")
public class TournamentController {

  private final TournamentService tournamentService;


  public TournamentController(TournamentService tournamentService) {
    this.tournamentService = tournamentService;
  }

  @PostMapping("/setMatch")
  public void setMatch(@RequestBody Tournament tournament) {
    this.tournamentService.setMatch(tournament);
  }
  @GetMapping("/getMatch/{clanName}")
  public List<Tournament> getMatch(@PathVariable String clanName) {
    return this.tournamentService.getMatch(clanName);
  }

  @PutMapping("/setWinner")
  public void setWinner(@RequestBody String winner) {
    this.tournamentService.setWinner(winner);
  }

  @DeleteMapping("/deleteAll/{clanName}")
  public void deleteAll(@PathVariable String clanName) {
    this.tournamentService.deleteAll(clanName);
  }



}
