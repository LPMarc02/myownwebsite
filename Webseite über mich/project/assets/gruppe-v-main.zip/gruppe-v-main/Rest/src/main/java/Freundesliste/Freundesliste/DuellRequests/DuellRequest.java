package Freundesliste.Freundesliste.DuellRequests;

import jakarta.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public class DuellRequest {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int id;
  private String sender;
  private String receiver;
  private String status;

  public int getId() {
    return id;
  }

  public String getSender() {
    return sender;
  }

  public void setSender(String sender) {
    this.sender = sender;
  }

  public String getReceiver() {
    return receiver;
  }

  public void setReceiver(String receiver) {
    this.receiver = receiver;
  }

  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }
}
