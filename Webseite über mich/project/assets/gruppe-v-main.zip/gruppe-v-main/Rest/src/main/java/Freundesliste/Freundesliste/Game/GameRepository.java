package Freundesliste.Freundesliste.Game;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GameRepository extends JpaRepository<Game, Long> {
  Game findBySessionId(String sessionId);
  List<Game> findAllBySessionId(String session);

  Game findByUsername(String username);
  Game findByPlayerRole(String playerRole);
  Game findByDeckId(Long deckId);
  Game findByGameMode(int gameMode);
  Optional<Game> findBySessionIdAndUsername(String sessionId, String username);
  Optional<Game> findBySessionIdAndPlayerRole(String sessionId, String playerRole);
  void delete(Game game);
}
