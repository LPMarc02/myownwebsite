package Freundesliste.Freundesliste;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreundeslisteApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreundeslisteApplication.class, args);
	}

}
