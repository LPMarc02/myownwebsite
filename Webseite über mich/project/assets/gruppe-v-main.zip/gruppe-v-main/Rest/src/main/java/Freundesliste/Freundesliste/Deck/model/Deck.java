package Freundesliste.Freundesliste.Deck.model;

import Freundesliste.Freundesliste.cards.Card;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "decks")

public class Deck {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private long deckId;

  @Column(name = "name")
  private String name;

  @Column(name = "count")
  private String count;

  @Column(name = "deckuser")
  private String deckuser;

  public void setDeckuser(String deckuser) {
    this.deckuser = deckuser;
  }

  public String getDeckuser() {
    return deckuser;
  }

  public void setDeckId(long deckId) {
    this.deckId = deckId;
  }

  public String getName() {
    return name;
  }

  public void setCount(String count) {
    this.count = count;
  }

  public String getCount() {
    return count;
  }
/*
  @ManyToMany
  @JoinTable(
    name = "deck_cards",
    joinColumns = @JoinColumn(name = "deckId"),
    inverseJoinColumns = @JoinColumn(name = "cardId")
  )


  private List<Card> cards = new ArrayList<>();
*/
  public void setName(String deckName) {
    this.name = deckName;
  }

  public void setCards(List<Card> cards) {
    //this.cards = cards;
  }

  public long getId() {
    return deckId;
  }
}
