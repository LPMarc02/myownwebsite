package Freundesliste.Freundesliste.Lootboxen;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LootboxenRepository extends JpaRepository<Lootboxen, Long> {
  List<Lootboxen> findAllByUsername(String username);
}
