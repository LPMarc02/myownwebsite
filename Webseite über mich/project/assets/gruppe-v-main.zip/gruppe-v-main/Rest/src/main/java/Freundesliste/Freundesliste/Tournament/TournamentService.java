package Freundesliste.Freundesliste.Tournament;
import Freundesliste.Freundesliste.ClanUser.ClanUser;
import Freundesliste.Freundesliste.ClanUser.ClanUserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class TournamentService {

  private final TournamentRepository tournamentRepository;
  private final ClanUserRepository clanUserRepository;

  public TournamentService(TournamentRepository tournamentRepository, ClanUserRepository clanUserRepository) {

    this.tournamentRepository = tournamentRepository;
    this.clanUserRepository = clanUserRepository;
  }

  public void setMatch(Tournament tournament) {
    tournamentRepository.save(tournament);
  }

  public List<Tournament> getMatch(String clanName) {
    return tournamentRepository.findByClanName(clanName);
  }

  public void setWinner(String winner) {
    List<Tournament> tournament = this.tournamentRepository.findByUsername1(winner);
    List<Tournament> tournament2 = this.tournamentRepository.findByUsername2(winner);
    System.out.println(tournament2);
    System.out.println(tournament);
    for (Tournament t : tournament2) {
      if(t.getWinner()==null){
        t.setWinner(winner);
        this.tournamentRepository.save(t);
        ClanUser clanUser =clanUserRepository.findByUsername(t.getUsername1());
        clanUser.setRequestAccepted(0);
        clanUserRepository.save(clanUser);
      }
    }
    for (Tournament t : tournament) {
      if(t.getWinner()==null){
        t.setWinner(winner);
        this.tournamentRepository.save(t);
        ClanUser clanUser =clanUserRepository.findByUsername(t.getUsername2());
        clanUser.setRequestAccepted(0);
        clanUserRepository.save(clanUser);
      }
    }
  }

  public void deleteAll(String clanName){
    List<Tournament> tournament = this.tournamentRepository.findByClanName(clanName);
    this.tournamentRepository.deleteAll(tournament);
  }
}
