package Freundesliste.Freundesliste.ClanUser;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ClanUserRepository extends JpaRepository<ClanUser, Long> {
  ClanUser findByUsername(String username);

  ClanUser[] findByClanname(String clanname);

  ClanUser[] findByBet(String winner);
}
