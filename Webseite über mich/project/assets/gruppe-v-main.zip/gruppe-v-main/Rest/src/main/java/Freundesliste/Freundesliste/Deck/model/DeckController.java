package Freundesliste.Freundesliste.Deck.model;

import Freundesliste.Freundesliste.cards.Card;
import Freundesliste.Freundesliste.DeckCards.DeckService;
import Freundesliste.Freundesliste.firendModel.Friend;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:4200")
public class DeckController {

  // standard constructors
  @Autowired
  private DeckService deckService;

  @Autowired
  private final DeckRepository deckRepository;

  public DeckController(DeckRepository deckRepository) {
    this.deckRepository = deckRepository;
  }

  @GetMapping("/decks")
  public List<Deck> getDecks(@RequestParam("deckuser") String deckuser) {

    return deckRepository.findByDeckuser(deckuser);
  }

  @DeleteMapping("/decks/{id}")
  public ResponseEntity<String> deleteDeck(@PathVariable("id") Long id) {
    Optional<Deck> deckOptional = deckRepository.findById(id);
    if (deckOptional.isPresent()) {
      deckRepository.deleteById(id);
      return ResponseEntity.ok("");
    } else {
      return ResponseEntity.notFound().build();
    }
  }

  @PostMapping("/decks")
  public Deck addDeck(@RequestBody Deck deck) {
    // Save the deck to the database
    return deckRepository.save(deck);
  }

  @PatchMapping("/decks/{deck_id}")
  public ResponseEntity<String> changeDeck(@PathVariable("deck_id") Long deck_id, @RequestBody String newName) {
    Optional<Deck> deckOptional = deckRepository.findById(deck_id);
    if (deckOptional.isPresent()) {
      Deck deck = deckOptional.get();
      deck.setName(newName);
      deckRepository.save(deck);
      return ResponseEntity.ok("");
    } else {
      return ResponseEntity.notFound().build();
    }
  }
/*
  @PostMapping("/decks")
  void addUser(@RequestBody Deck user) {
    deckRepository.save(user);
  }

 */
}
