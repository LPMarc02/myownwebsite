package Freundesliste.Freundesliste.Game;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Game {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  private String sessionId;
  private String username;
  private String playerRole;
  private Long deckId;
  private int gameMode;

  // Constructors
  public Game() {
  }

  public Game(String sessionId, String username, String playerRole, Long deckId, int gameMode) {
    this.sessionId = sessionId;
    this.username = username;
    this.playerRole = playerRole;
    this.deckId = deckId;
    this.gameMode = gameMode;
  }

  // Getters and Setters
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getSessionId() {
    return sessionId;
  }

  public void setSessionId(String sessionId) {
    this.sessionId = sessionId;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getPlayerRole() {
    return playerRole;
  }

  public void setPlayerRole(String playerRole) {
    this.playerRole = playerRole;
  }

  public Long getDeckId() {
    return deckId;
  }

  public void setDeckId(Long deckId) {
    this.deckId = deckId;
  }

  public int getGameMode() {
    return gameMode;
  }

  public void setGameMode(int gameMode) {
    this.gameMode = gameMode;
  }
}
