package Freundesliste.Freundesliste.Admin;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping("/api/Admins")
public class AdminController  {

  public final AdminService adminService;

  @Autowired
  public AdminController(AdminService adminService) {
    this.adminService = adminService;

  }
  @GetMapping("/isAdmin/{username}")
  public boolean isAdmin(@PathVariable String username) {
    return adminService.isAdmin(username);
  }

  @PostMapping("/ad")
  public Admin addAdmin(@RequestBody Admin admin) {
    return adminService.addAdmin(admin);
  }

  @GetMapping("/getIdAdmin")
  public Admin getAdminById(@RequestParam Long id) {
    return adminService.getAdmin(id);
  }

}

