package Freundesliste.Freundesliste.Admin;



import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.Entity;

@Entity
public class Admin extends User {




  public Admin() {
    super();
  }












}
