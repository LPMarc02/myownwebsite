package Freundesliste.Freundesliste.FriendRequest;

import Freundesliste.Freundesliste.Friendship.Friendship;
import Freundesliste.Freundesliste.Friendship.FriendshipRepository;

import Freundesliste.Freundesliste.User.User;
import Freundesliste.Freundesliste.User.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendRequestService {
  @Autowired
  private FriendRequestRepository friendRequestRepository;

  @Autowired
  private FriendshipRepository friendshipRepository;

  @Autowired
  private UserRepository userRepository;

  public List<FriendRequest> getPendingFriendRequests(Long receiverId) {
    return friendRequestRepository.findByReceiverIdAndStatus(receiverId, "offen");
  }

  public List<FriendRequest> getSentFriendRequests(Long senderId) {
    return friendRequestRepository.findBySenderIdAndStatus(senderId, "offen");
  }
  public void sendFriendRequest(FriendRequest friendRequest) {

    friendRequestRepository.save(friendRequest);
  }

  public void acceptFriendRequest(Long id) { //freundgespeichert zum benutzer
    // Find the friend request by id
    FriendRequest friendRequest = friendRequestRepository.findById(id).orElse(null);

    if (friendRequest != null) {
      // Fetch the sender and receiver users
      User sender = userRepository.findById(friendRequest.getSenderId()).orElse(null);
      User receiver = userRepository.findById(friendRequest.getReceiverId()).orElse(null);

      if (sender != null && receiver != null) {
        // Create friendships for both users
        // speichern der freundenname
        Friendship friendship1 = new Friendship(receiver.getUsername(), friendRequest.getSenderId(), friendRequest.getReceiverId());
        friendshipRepository.save(friendship1);

        Friendship friendship2 = new Friendship(sender.getUsername(), friendRequest.getReceiverId(), friendRequest.getSenderId());
        friendshipRepository.save(friendship2);

        // lösche anfrag.
        friendRequestRepository.delete(friendRequest);
      }
    }
  }
  public void rejectFriendRequest(Long requestId){
    friendRequestRepository.deleteById(requestId);
  }

  // Methode zum Abrufen der Friend Requests nach Empfänger-ID
  public List<FriendRequest> getFriendRequestsForUser(Long receiverId) {
    return friendRequestRepository.findByReceiverId(receiverId);
  }

}
