package Freundesliste.Freundesliste.ClanUser;


import Freundesliste.Freundesliste.Clan.Clan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/clan")
public class ClanUserController {
  private final ClanUserService clanUserService;

  @Autowired
  public ClanUserController(ClanUserService clanUserService){
    this.clanUserService = clanUserService;
  }

//Nils Wenzel
  @GetMapping("/clans/{username}")
  public Clan findClanByUsername(@PathVariable String username){
    return this.clanUserService.findClanByUsername(username);
  }

  @GetMapping("/clanUsers/{clanname}")
  public ClanUser[] findClanByClanname(@PathVariable String clanname){
    return this.clanUserService.findClanByClanname(clanname);
  }

  @GetMapping("/getUserClanByUsername/{username}")
  public ClanUser findUserClanByUsername(@PathVariable String username){
    return this.clanUserService.findUserClanByUsername(username);
  }

  @PostMapping("/joinClan/{clanname}")
  public void joinClan(@PathVariable String clanname, @RequestBody String username){
    this.clanUserService.saveClanUser(username, clanname);
  }

  @PutMapping("/setBet/{user}")
  public void setBet(@PathVariable String user, @RequestBody String bet){
    this.clanUserService.setBet(user, bet);
  }

  @DeleteMapping("/leaveClan/{username}")
  public void leaveClan(@PathVariable String username){
    this.clanUserService.deleteByUsername(username);
  }

  @DeleteMapping("/resolveBet/{winner}")
  public void resolveBet(@PathVariable String winner){
    this.clanUserService.resolveBet(winner);
  }

//Marc Prüfer
  @PutMapping("/setRequestAccepted")
  public void setRequestAccepted(@RequestBody String username){
    this.clanUserService.setRequestAccepted(username);
  }

  @PutMapping("/setRequestNull")
  public void setRequestNull(@RequestBody String username){
    this.clanUserService.setRequestNull(username);
  }
}
