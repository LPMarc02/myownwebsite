package Freundesliste.Freundesliste.firendModel;

import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Friend {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @ManyToOne
  private User user;

  @ManyToOne
  private User friend;

  public Friend() {
    // Standardkonstruktor
  }

  public Friend(User user, User friend) {
    this.user = user;
    this.friend = friend;
  }

  // Getter und Setter für 'id'
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  // Getter und Setter für 'user'
  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  // Getter und Setter für 'friend'
  public User getFriend() {
    return friend;
  }

  public void setFriend(User friend) {
    this.friend = friend;
  }
}
