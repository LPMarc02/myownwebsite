package Freundesliste.Freundesliste.Tournament;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TournamentRepository extends JpaRepository<Tournament,Long> {
  List<Tournament> findByClanName(String clanName);
  List<Tournament> findByUsername1(String userName);
  List<Tournament> findByUsername2(String userName);
}
