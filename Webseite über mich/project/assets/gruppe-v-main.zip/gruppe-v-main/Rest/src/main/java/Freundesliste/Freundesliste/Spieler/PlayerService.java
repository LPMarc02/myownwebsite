package Freundesliste.Freundesliste.Spieler;

import Freundesliste.Freundesliste.User.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlayerService {
  private final PlayerRepository playerRepository;

  @Autowired
  public PlayerService(PlayerRepository playerRepository) {
    this.playerRepository = playerRepository;
  }

  public Player findPlayerByUsername(String username) { return playerRepository.findByUsername(username); }
  public Player addPlayer(Player player) {
    return playerRepository.save(player);
  }
  public Player getPlayer(Long id) {
      return playerRepository.findById(id).orElse(null);
  }
  public List<Player> getAllPlayers() {
    return playerRepository.findAll();
  }
  public Player removePlayer(Long id) {
    return playerRepository.findById(id).orElse(null);
  }
  public void updateProfilePicture(Long id, String profilePicture) {
    Player player = playerRepository.findById(id).orElseThrow();
    player.setProfilePicture(profilePicture);
    playerRepository.save(player);
  }
  public void updateSEP(String username, Long sep) {
    Player player = playerRepository.findByUsername(username);
    player.setSepCoins(player.getSepCoins() - sep);
    playerRepository.save(player);
  }
  public List<Player> getAllPlayer() {
    return playerRepository.findAll();
  }
  public List<Player> searchUsersByUsername(String username) {
    return playerRepository.findByUsernameContainingIgnoreCase(username);
  }

  public void setLeaderboard(String username, long points){
    Player player = playerRepository.findByUsername(username);
    player.setLeaderboard(player.getLeaderboard() + points);
    playerRepository.save(player);
  }

  public User FindUserByUsername(String username){
    return playerRepository.findByUsername(username);
  }

}
