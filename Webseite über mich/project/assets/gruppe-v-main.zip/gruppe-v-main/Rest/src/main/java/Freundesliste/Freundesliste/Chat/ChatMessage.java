package Freundesliste.Freundesliste.Chat;

import java.time.Instant;

import org.hibernate.annotations.Collate;

import Freundesliste.Freundesliste.User.User;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;

@Entity(name = "chat_message")
public class ChatMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "message")
    private String message;

    @Column(name = "is_seen_by_others")
    private boolean isSeenByOthers;

    @OneToOne()
    @JoinColumn(name = "owner", referencedColumnName = "id")
    private User owner;

    @Column(name = "timestmap")
    private Instant timestamp;

    @Column(name = "chat_instance_id")
    private long chatInstanceId;

    // @ManyToOne
    // private ChatInstance chatInstance;

    // public ChatInstance getChatInstance() {
    //     return chatInstance;
    // }

    // public void setChatInstance(ChatInstance chatInstance) {
    //     this.chatInstance = chatInstance;
    // }

    public long getChatInstanceId() {
        return chatInstanceId;
    }

    public void setChatInstanceId(long chatInstanceId) {
        this.chatInstanceId = chatInstanceId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isSeenByOthers() {
        return isSeenByOthers;
    }

    public void setSeenByOthers(boolean isSeenByOthers) {
        this.isSeenByOthers = isSeenByOthers;
    }

    public User getOwner() {
        return owner;
    }

    public void setOwner(User owner) {
        this.owner = owner;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Instant timestamp) {
        this.timestamp = timestamp;
    }

}
