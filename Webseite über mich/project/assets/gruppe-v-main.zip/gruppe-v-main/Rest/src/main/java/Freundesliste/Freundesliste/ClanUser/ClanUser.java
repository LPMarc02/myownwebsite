package Freundesliste.Freundesliste.ClanUser;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ClanUser {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id;
  private String username;
  private String clanname;
  private String bet;
  private int requestAccepted;

  public int getId() {
    return id;
  }

  public String getUsername() {
    return username;
  }

  public void setUsername(String username) {
    this.username = username;
  }

  public String getClanname() {
    return clanname;
  }

  public void setClanname(String clanname) {
    this.clanname = clanname;
  }

  public String getBet() {
    return bet;
  }

  public void setBet(String bet) {
    this.bet = bet;
  }

  public int getRequestAccepted() {
    return requestAccepted;
  }

  public void setRequestAccepted(int requestAccepted) {
    this.requestAccepted = requestAccepted;
  }
}
