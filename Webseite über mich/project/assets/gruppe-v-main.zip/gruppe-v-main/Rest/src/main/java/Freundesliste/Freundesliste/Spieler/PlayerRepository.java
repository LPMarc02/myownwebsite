package Freundesliste.Freundesliste.Spieler;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PlayerRepository extends JpaRepository<Player, Long> {
  Player findByUsername(String username);
  List<Player> findByUsernameContainingIgnoreCase(String username);
}

