package Freundesliste.Freundesliste.Friendship;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/friendship")
public class FriendshipController {

  @Autowired
  private FriendshipService friendshipService;

  @GetMapping("/user/{userId}")
  public List<Friendship> getUserFriendships(@PathVariable Long userId) {
    return friendshipService.getUserFriendships(userId);
  }

  @DeleteMapping("/delete/Friendship")
  public void deleteFriendship(@RequestParam Long userId, @RequestParam Long friendId) {
    friendshipService.deleteFriendship(userId, friendId);
  }

  @GetMapping("/show/AllFriendships")
  public List<Friendship> getAllFriendships() {
    return friendshipService.getAllFriendships();
  }
}

