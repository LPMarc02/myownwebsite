package Freundesliste.Freundesliste.User;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;
import java.util.Optional;

@Service
public class UserService {
  private final UserRepository userRepository;

  @Autowired
  public UserService(UserRepository userRepository) {
    this.userRepository = userRepository;

  }

  public User addUser(User user) {
    return userRepository.save(user);
  }

  public User findUserById(Long id){
    return userRepository.findById(id).orElse(null);
  }

  public User FindUserByUsername(String username){
    return userRepository.findByUsername(username);
}

  public User removePlayer(Long id) {
    return userRepository.findById(id).orElse(null);
  }

  public List<User> searchUserByFirstNameAndLastName( String firstName, String lastName){
      return userRepository.findByFirstNameAndLastName(firstName,lastName);
  }

  public List<User> searchByUsername(String username) {
    return userRepository.findByUsernameContaining(username);
  }


  public List<User> getAllUser() {
    return userRepository.findAll();
  }

  public void updateProfilePicture(Long id, String profilePicture) {
    User user = userRepository.findById(id).orElseThrow();
    user.setProfilePicture(profilePicture);
    userRepository.save(user);
  }
  public void changePassword(String email, String newPassword) {
    User user =userRepository.findByEmail(email);
    user.setPassword(newPassword);
    userRepository.save(user);
  }


  public List<User> searchUsersByUsername(String username) {
    return userRepository.findByUsernameContainingIgnoreCase(username);
  }
  public void updateStatus(Long id, String status) {
    User user = userRepository.findById(id).orElseThrow();
    user.setStatus(status);
    userRepository.save(user);
  }

  public void setUserStatus(String username, String status) {
    User user = userRepository.findByUsername(username);
    user.setStatus(status);
    userRepository.save(user);
  }
  public User updateFriendListPrivacy(Long userId, Boolean friendListPrivate) {
    Optional<User> optionalUser = userRepository.findById(userId);
    if (optionalUser.isPresent()) {
      User user = optionalUser.get();
      user.setFriendListPrivate(friendListPrivate);
      userRepository.save(user); // Speichern der aktualisierten Privacy-Einstellungen
      return user;
    }
    return null; // Optional: Falls der Benutzer nicht gefunden wurde, könntest du eine entsprechende Behandlung hier einfügen
  }
}
