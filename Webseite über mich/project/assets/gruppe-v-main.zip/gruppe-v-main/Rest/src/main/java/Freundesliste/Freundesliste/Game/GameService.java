package Freundesliste.Freundesliste.Game;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GameService {

  @Autowired
  private GameRepository gameRepository;

  public Game createGameSession(Game game) {
    return gameRepository.save(game);
  }

  public Game updateGameSession(String sessionId, String username, Game updatedGame) {
    Optional<Game> existingGameOptional = gameRepository.findBySessionIdAndUsername(sessionId, username);

    if (existingGameOptional.isPresent()) {
      Game existingGame = existingGameOptional.get();
      // Update fields from updatedGame if they are not null
      if (updatedGame.getUsername() != null) {
        existingGame.setUsername(updatedGame.getUsername());
      }
      if (updatedGame.getPlayerRole() != null) {
        existingGame.setPlayerRole(updatedGame.getPlayerRole());
      }
      if (updatedGame.getDeckId() != null) {
        existingGame.setDeckId(updatedGame.getDeckId());
      }
      if (updatedGame.getGameMode() != 0) { // Assuming 0 is a default value and not valid for update
        existingGame.setGameMode(updatedGame.getGameMode());
      }
      return gameRepository.save(existingGame);
    } else {
      throw new IllegalArgumentException("Game session with sessionId " + sessionId + " and username " + username + " not found");
    }
  }

  public Optional<Game> getGameSession(Long id) {
    return gameRepository.findById(id);
  }

  public void deleteGameSessionByUsername(String username) {
    Optional<Game> gameOptional = Optional.ofNullable(gameRepository.findByUsername(username));
    if (gameOptional.isPresent()) {
      Game game = gameOptional.get();
      gameRepository.delete(game);
    } else {
      throw new IllegalArgumentException("Game session with username " + username + " not found");
    }
  }

  public Game getGameBySessionId(String sessionId) {
    return gameRepository.findBySessionId(sessionId);
  }

  public Game getGameByUsername(String username) {
    return gameRepository.findByUsername(username);
  }

  public Game getGameByPlayerRole(String playerRole) {
    return gameRepository.findByPlayerRole(playerRole);
  }

  public Game getGameByDeckId(Long deckId) {
    return gameRepository.findByDeckId(deckId);
  }

  public Game getGameByGameMode(int gameMode) {
    return gameRepository.findByGameMode(gameMode);
  }

  public void deleteSession(String session){
    List<Game> games = gameRepository.findAllBySessionId(session);
    this.gameRepository.deleteAll(games);
  }
}
