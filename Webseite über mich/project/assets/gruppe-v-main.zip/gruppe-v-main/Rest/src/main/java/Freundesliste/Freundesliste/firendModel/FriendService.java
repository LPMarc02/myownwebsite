package Freundesliste.Freundesliste.firendModel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendService {

  private final FriendRepository friendRepository;

  @Autowired
  public FriendService(FriendRepository friendRepository) {
    this.friendRepository = friendRepository;
  }

  // Methode zum Hinzufügen eines Freundes
  public void addFriend(Long userId, Long friendId) {
    // Implementiere hier die Logik zum Hinzufügen eines Freundes
  }

  // Methode zum Entfernen eines Freundes
  public void removeFriend(Long userId, Long friendId) {
    // Implementiere hier die Logik zum Entfernen eines Freundes
  }

  // Methode zum Abrufen der Freundesliste eines Benutzers
  public List<Friend> getFriends(Long userId) {
    // Implementiere hier die Logik zum Abrufen der Freundesliste eines Benutzers
    return friendRepository.findByUserId(userId);
  }
}
