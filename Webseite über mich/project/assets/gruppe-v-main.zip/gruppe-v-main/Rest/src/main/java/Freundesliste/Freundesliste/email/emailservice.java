package Freundesliste.Freundesliste.email;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


@Service
public class emailservice {
  @Autowired
  private JavaMailSender mailSender;

  public ResponseEntity<Object> sendMail(email body) {
    String email = body.getEmail();
    int randomNumber = body.getRandomNumber();
    String text= body.getText();
    String subject = body.getSubject();
    SimpleMailMessage message=new SimpleMailMessage();
    message.setFrom("cardclashsep@gmail.com");
    message.setTo(email);
    message.setSubject(subject);
    if(randomNumber<10000){
      message.setText(text+randomNumber);
    }
    else{
      message.setText(text);
    }
    this.mailSender.send(message);
    return ResponseEntity.ok().build();
  }
}
