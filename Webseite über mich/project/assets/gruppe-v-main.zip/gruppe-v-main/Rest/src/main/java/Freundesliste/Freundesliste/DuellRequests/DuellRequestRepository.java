package Freundesliste.Freundesliste.DuellRequests;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface DuellRequestRepository extends JpaRepository<DuellRequest, Long> {
  DuellRequest findByReceiver(String receiver);
  DuellRequest findBySender(String sender);

  @Modifying
  @Transactional
  void deleteBySender(String sender);

  @Modifying
  @Transactional
  @Query("UPDATE DuellRequest d SET d.status = :status WHERE ( d.sender = :sender)")
  void updateStatusBySender(String sender, String status);
}
