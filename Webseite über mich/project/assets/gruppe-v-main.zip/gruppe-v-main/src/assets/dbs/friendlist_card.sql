-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: friendlist
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `card`
--

DROP TABLE IF EXISTS `card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `card` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `rarity` varchar(255) DEFAULT NULL,
  `attack_points` int DEFAULT NULL,
  `defense_points` int DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `card`
--

LOCK TABLES `card` WRITE;
/*!40000 ALTER TABLE `card` DISABLE KEYS */;
INSERT INTO `card` VALUES (51,'O Deus Klaus','Legendär',1000,0,'Klaus, der Gott der Ordnung und des Gleichgewichts, wacht über die Welt der Karten. Seine Anwesenheit allein genügt, um das Blatt zu wenden, und seine Macht ist unübertroffen.','img1\r'),(52,'Sirene des Meeres','Selten',5,2,'Mit ihrer betörenden Stimme kann die Sirene des Meeres die mächtigsten Seefahrer in die Tiefen locken.','img2\r'),(53,'Frosthexe Glacella','Legendär',8,4,'Glacella kann mit einem Fingerschnippen ganze Armeen in Eisstatuen verwandeln.','img6\r'),(54,'Drachenkönig Elduris','Legendär',8,8,'Elduris, der unsterbliche Drachenkönig, beherrscht die Elemente des Feuers und der Erde. Sein mächtiger Flammenatem kann ganze Armeen verschlingen.','img3\r'),(55,'Blitzender Zyklop','Selten',4,3,'Ein einziger Blick seines leuchtenden Auges kann Gegner in Schrecken versetzen.','img5\r'),(56,'Pyromagier Ignatius','Selten',4,2,'Ignatius entfesselt Feuerstürme, die alles auf ihrem Weg verbrennen.','img7\r'),(58,'Schattenritter Dusk','Selten',2,5,'Aus den Schatten heraus führt Dusk tödliche Angriffe mit präziser und tödlicher Effizienz.','img9\r'),(59,'Golem der Steine','Normal',1,5,'Unerschütterlich steht der Golem im Kampf, seine steinerne Haut widersteht den härtesten Schlägen.','img8\r'),(61,'Wächter des Waldes','Selten',5,1,'Dieser uralte Beschützer des Waldes schlägt jeden Eindringling mit seinen mächtigen Wurzeln zurück.','img4\r'),(62,'Lichtfee Aurora','Selten',1,6,'Auroras leuchtende Aura heilt Verbündete und blendet ihre Feinde.','img10\r'),(65,'Bernd','Normal',50,1,'Bernd mag auf den ersten Blick unscheinbar wirken, aber unterschätze niemals die Kraft der Unauffälligkeit. Er kann überraschend aus dem Nichts zuschlagen.','img12'),(66,'Card-i B','Normal',25,1,'Card-i B ist bekannt für ihre langen, scharfen Fingernägel, mit denen sie ihre Gegner in Schach hält. Ihre Angriffe sind schnell und präzise, was sie zu einer wertvollen Karte im Kampf macht.','img11\r');
/*!40000 ALTER TABLE `card` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-18 14:37:54
