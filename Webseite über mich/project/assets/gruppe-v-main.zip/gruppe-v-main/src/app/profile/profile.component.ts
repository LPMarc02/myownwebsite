import {Component, OnInit} from '@angular/core';
import {FriendlistComponent} from "../friendlist/friendlist.component";
import {NgForOf, NgIf, NgStyle} from "@angular/common";
import {ActivatedRoute, Router, RouterLink} from "@angular/router";
import {FooterComponent} from "../footer/footer.component";
import {PlayerService} from "../Services/services/player.service";
import {UserService} from "../Services/services/user.service";
import {User} from "../Models/User.model";
import {DuellRequestService} from "../Services/services/duell-request.service";
import {EMPTY, switchMap} from "rxjs";
import {catchError} from "rxjs/operators";
import {ClanService} from "../Services/services/clan.service";

interface ProfilePicture{
  src: string;
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    FriendlistComponent,
    NgForOf,
    RouterLink,
    FooterComponent,
    NgStyle,
    NgIf,
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})

export class ProfileComponent implements OnInit{
  constructor(private playerService: PlayerService, private userService: UserService, private router: Router, private route: ActivatedRoute, private duellRequestService: DuellRequestService, private clanService: ClanService) {
    this.route.params.subscribe( params => {
      const displayedUser = params['username'];
      console.log(displayedUser);
      this.username = displayedUser;
    });
  }

  username: string | undefined;
  sessionUser: string | undefined;
  permission: boolean = false;
  same: boolean = false;
  availableProfilePictures : ProfilePicture[] = [
    { src: 'img1' },
    { src: 'img2' },
    { src: 'img3' },
    { src: 'img4' },
    { src: 'img5' },
    { src: 'img6' },
    { src: 'img7' },
    { src: 'img8' },
    { src: 'img9' },
    { src: 'img10' },
    { src: 'img11' },
    { src: 'img12' },
    { src: 'img13' },
    { src: 'img14' },
    { src: 'img15' },
    { src: 'img16' },
    { src: 'img17' },
    { src: 'img18' },
    { src: 'img19' },
    { src: 'img20' },
  ]
  selected: boolean = false;
  selectedUser: User ={
    birthDate: "", email: "", firstName: "unknown", lastName: "user", password: "", profilePicture: "img0", username: "unknown_user",friendListPrivate: false
  };
  sepCoins: number | undefined;
  leaderboard: number | undefined;
  clan: string | undefined;
  text: String = "*Inhaltsnachweis: Bilder mit KI erstellt."

  ngOnInit(){
    this.getData();
  }

  getData(){
    this.sessionUser = this.userService.getPlayerData()
    this.userService.getUserByUsername(this.username)
      .subscribe(
        user => this.selectedUser = user
      )
    this.userService.getPermission(this.username)
      .subscribe(
      permission => this.getPoints(permission)
    )
    this.clanService.getClanByUsername(this.username)
      .subscribe(
        clan => {
          this.clan = clan.clanname
          console.log(this.clan)
        }
      )
    this.same = this.username === this.sessionUser;
  }

  getPoints(permission: boolean){
    this.permission = permission
    if(!permission){
      this.playerService.getSepCoins(this.username).subscribe(coins => this.sepCoins = coins);
      this.playerService.getLeaderboard(this.username).subscribe(lead => this.leaderboard = lead);
    }
  }

  openMenu(){
    this.selected = !this.selected;
  }

  closeMenu(): void {
    this.selected = false;
  }

  emptySession(){
    if(this.username){
      this.userService.setUserOnline(this.username,"offline").subscribe();
      this.duellRequestService.deleteRequest(this.username).subscribe(() => {
        this.userService.emptySession();
        this.router.navigate(["/"]).then(() => this.reloadPage())
        }
      );
    }
  }

  deleteUser(){

  }

  duellRequest(){
    this.duellRequestService.sendRequest(this.selectedUser.username);
  }

  selectProfilePicture(ProfilePicture: ProfilePicture) {
    this.selectedUser.profilePicture = ProfilePicture.src;
    if (this.selectedUser.id != null){
      this.userService.updateProfilePicture(this.selectedUser.id,ProfilePicture.src).subscribe(() => this.reloadPage());
    }
    this.closeMenu();
  }

  //Diese Methode stammt aus der Backend-Lösung auf Moodle
  private reloadPage() {
    window.location.reload();
  }

  toggleFriendListPrivacy(): void {
    const newPrivacy = !this.selectedUser.friendListPrivate;

    this.userService.updateFriendListPrivacy(this.selectedUser.id, newPrivacy).pipe(
      switchMap(updatedUser => {
        this.selectedUser = updatedUser; // Aktualisieren des lokalen selectedUser
        return EMPTY; // Rückgabe eines leeren Observables, da wir kein weiteres Ergebnis benötigen
      }),
      catchError(error => {
        console.error('Error updating privacy setting:', error);
        return EMPTY; // Rückgabe eines leeren Observables im Fehlerfall
      })
    ).subscribe();
  }
}
