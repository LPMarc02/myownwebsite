import {Component, Input, OnInit} from '@angular/core';
import { UserService } from "../Services/services/user.service";
import { FriendRequestService } from "../Services/friend-request.service";
import { FriendshipService } from "../Services/friendship.service";
import { catchError, tap } from "rxjs/operators";
import { User } from "../Models/User.model";
import { FriendRequest } from "../Models/FriendRequestModel";
import { Friendship } from "../Models/Friendship.model";
import {EMPTY} from 'rxjs';
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import {Router, RouterLink} from "@angular/router";

@Component({
  selector: 'app-friendlist',
  templateUrl: './friendlist.component.html',
  imports: [
    FormsModule,
    CommonModule,
    RouterLink
  ],
  standalone: true,
  styleUrl: './friendlist.component.scss'
})
export class FriendlistComponent implements OnInit {
  newFriendRequest: FriendRequest = {username: "", senderId: 0, receiverId: 0, status: '' };  // Stelle sicher, dass newFriendRequest deklariert ist

  friendRequests: FriendRequest[] = [];
   friendships: Friendship[] = [];
 // loggedInUser: User | null = null;
  searchTerm: string = '';
 // searchResults: User[] = [];
  usernameSelectedUser: string | undefined;
  usernameLoggedInUser: string | undefined;
  selectedUser: User = {
    id: 0,
    birthDate: "", email: "", firstName: "unknown", lastName: "user", password: "", profilePicture: "img0", username: "unknown_user",friendListPrivate:false
  };
  loggedInUser: User = {
    id: 0,
    birthDate: "", email: "", firstName: "unknown", lastName: "user", password: "", profilePicture: "img0", username: "unknown_user",friendListPrivate:false
  };
  selectedFriend: Friendship= {id:0, friendName: "as", userId: 0, friendId: 0};

  searchQuery: string = '';
  searchResults: any[] = [];
  user: User | undefined;
  friendsFriendships: { [key: number]: Friendship[] } = {}
  friendsFriendshipsString: string = '';
  @Input() same: boolean = false;

  friends: Friendship[] = [];
  yuser: User | undefined;
  isAdmin: boolean = false;

  @Input() visitedUser: User | undefined;
  @Input() permission: boolean = false;


  constructor(
    public userService: UserService,
    private friendRequestService: FriendRequestService,
    private friendshipService: FriendshipService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getData();
    if(this.visitedUser){
      this.loadFriends(this.visitedUser.id);
    }
  }

  loadFriends(userId: number | undefined): void {
    this.friendshipService.getUserFriendships(userId).subscribe(friends => {
      this.friends = friends;
    });
  }

  loadUserProfile(username: string | undefined): void {
    this.userService.getUserByUsername(username).subscribe(user => {
      this.user = user;
      this.loadFriends(user.id);
    });
  }

  getData() {
    this.usernameLoggedInUser = this.userService.getPlayerData();
    this.userService.getUserByUsername(this.usernameLoggedInUser).subscribe(
      user => {
        this.loggedInUser = user;
        this.loadFriendRequests();
        this.loadFriendships();
        console.log(this.selectedUser.id);
        console.log(this.loggedInUser.id);
      }
    );

  }

  loadFriendRequests(): void {
    if (this.loggedInUser && this.loggedInUser.id) {
      this.friendRequestService.getFriendRequestsForUser(this.loggedInUser.id).pipe(
        tap(friendRequests => this.friendRequests = friendRequests),
        catchError(error => {
          console.error('Fehler beim Laden der Freundesanfragen:', error);
          return EMPTY;
        })
      ).subscribe();
    }
  }


  loadFriendships(): void {
    if (this.loggedInUser && this.loggedInUser.id) {
      this.friendshipService.getUserFriendships(this.loggedInUser.id).pipe(
        tap(data => this.friendships = data),
        catchError(error => {
          console.error('Fehler beim Laden der Freundesliste:', error);
          return EMPTY;
        })
      ).subscribe();
    }
  }

  searchUsers(): void {
    if (this.searchTerm.trim()) {
      if (this.loggedInUser && this.searchTerm.trim() === this.loggedInUser.username) {
        this.searchResults = [];
      } else {
        this.userService.getUsersByUsername(this.searchTerm).subscribe(
          users => {
            this.searchResults = users.filter(user => user.username !== this.loggedInUser?.username);
          },
          error => {
            console.error('Fehler bei der Benutzersuche:', error);
          }
        );
      }
    } else {
      this.userService.getAllUsers().subscribe(
        users => {
          this.searchResults = users.filter(user => user.username !== this.loggedInUser?.username);
        },
        error => {
          console.error('Fehler beim Laden aller Benutzer:', error);
        }
      );
    }
  }

  sendFriendRequest(user: User): void {
    console.log('sendFriendRequest wurde aufgerufen.');
    console.log('Übergebener Benutzer:', user);
    console.log('eingeloggter benuterid:', this.loggedInUser.id);
    if (this.loggedInUser.id && user.id) {
      const newFriendRequest: FriendRequest = {
        username: this.loggedInUser.username,
        senderId: this.loggedInUser.id,
        receiverId: user.id, // Verwenden Sie user.id als receiverId
        status: 'offen'
      };
      console.log('Neue Freundesanfrage:', newFriendRequest);

      this.friendRequestService.sendFriendRequest(newFriendRequest).pipe(
        tap(() => {
          this.loadFriendRequests();
          this.clearSearch();

          this.userService.sendEmailToUser(user.email, 100000, "Freundesanfrage von:" + this.usernameLoggedInUser, "Neue Freundschaftsanfrage").subscribe({
            next: (emailResponse: any) => {
              console.log("Wurde gesendet");
            },
            error: (emailError: any) => {
              alert("Email Error");
            }
          });
        }),
        catchError(error => {
          console.error('Fehler beim Senden der Freundschaftsanfrage:', error);
          return EMPTY;
        })
      ).subscribe();
    } else {
      console.error('Ungültige Benutzerdaten');
    }
  }

  selectUser(user: User): void {
    this.selectedUser = user;
    console.log(this.selectedUser);
  }

  acceptRequest(requestId: number | undefined): void {
    if (requestId !== undefined) {
      this.friendRequestService.acceptFriendRequest(requestId).pipe(
        tap(() => {
          this.loadFriendRequests();
          this.loadFriendships(); // Lade die Freundesliste neu
        }),
        catchError(error => {
          console.error('Fehler beim Akzeptieren der Anfrage:', error);
          return EMPTY;
        })
      ).subscribe();
    } else {
      console.error('Ungültige Anfrage-ID');
    }
  }


  clearSearch(): void {
     this.searchTerm = '';
     this.searchResults = [];
     this.selectedUser = {
       id: 0,
       birthDate: "",
       email: "",
       firstName: "unknown",
       lastName: "user",
       password: "",
       profilePicture: "img0",
       username: "unknown_user",
       friendListPrivate:false
     };
   }

   rejectRequest(requestId: number | undefined): void {
     if (requestId !== undefined) {
       this.friendRequestService.rejectFriendRequest(requestId).pipe(
         tap(() => this.loadFriendRequests()),
         catchError(error => {
           console.error('Fehler beim Ablehnen der Anfrage:', error);
           return EMPTY;
         })
       ).subscribe();
     } else {
       console.error('Ungültige Anfrage-ID');
     }
   }

  deleteFriendship(userId: number | undefined, friendId: number | undefined): void {
    this.friendshipService.deleteFriendship(userId, friendId).pipe(
      tap(() => this.loadFriendships()), // Reload friendships after deletion
      catchError(error => {
        console.error('Error deleting friendship:', error);
        return EMPTY;
      })
    ).subscribe();
  }

  isFriend(userId: number | undefined): boolean {
    return this.friends.some(friendship => friendship.friendId === userId);
  }

  isRequestSent(userId: number | undefined): boolean {
   return this.friendRequests.some(request => request.receiverId === userId);
  }

  routing(username: string | undefined){
    this.router.navigate(['Profile', username]).then(() => this.reloadPage());
  }

  canViewFriendList(): boolean {
    return this.same || !this.visitedUser?.friendListPrivate || this.isAdmin ;
  }

  //Methode stammt aus der Backend-Lösung von Moodle
  private reloadPage() {
    window.location.reload();
  }

}
