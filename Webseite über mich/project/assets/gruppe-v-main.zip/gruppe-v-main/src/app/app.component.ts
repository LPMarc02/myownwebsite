import {Component, HostListener} from '@angular/core';
import { RouterOutlet } from '@angular/router';
import {HeaderComponent} from "./header/header.component";
import {ProfileComponent} from "./profile/profile.component";
import {AdminControllerComponent} from "./admin-controller/admin-controller.component";
import {UserService} from "./Services/services/user.service";
import { ChatComponent } from './chat/chat.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, ProfileComponent, AdminControllerComponent, ChatComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent{
  title = 'CardClash';
  buttonClicked(){
    alert('Hallo wie geht es dir?')
  }
  username:string| undefined;
  constructor(private userService: UserService) {
    this.username=this.userService.getPlayerData();
  }
  /*@HostListener('window:beforeunload', ['$event'])
  unloadNotification($event:any){
    if(this.username){
      this.userService.setUserOnline(this.username,'offline').subscribe();
    }
  }*/
}
