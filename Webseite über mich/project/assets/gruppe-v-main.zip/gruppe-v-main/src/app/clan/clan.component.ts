import {Component, OnInit} from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {ClanService} from "../Services/services/clan.service";
import {Clan} from "../Models/Clan.model";
import {UserService} from "../Services/services/user.service";
import {TurnierComponent} from "../turnier/turnier.component";
import {ClanUser} from "../Models/ClanUser.model";

@Component({
  selector: 'app-clan',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
    ReactiveFormsModule,
    FormsModule,
    TurnierComponent
  ],
  templateUrl: './clan.component.html',
  styleUrl: './clan.component.scss'
})
export class ClanComponent implements OnInit {
  constructor(private clanService: ClanService, private userService: UserService) {
    this.signedUser = this.userService.getPlayerData();
  }

  //Nils Wenzel
  signedUser?: string;
  allClans?: Clan[];
  userClan?: Clan;
  clanname?: string;

  //Marc Prüfer
  status:boolean = false;
  count:number=0;
  allClanUser: ClanUser[]=[];
  length: number=0;

  ngOnInit() {

    //load all clans
    this.clanService.getClans()
      .subscribe(clans => {
        this.allClans = clans;
      })

    //search user clan
    if (this.signedUser)
    this.clanService.getClanByUsername(this.signedUser)
      .subscribe(clan => {
        this.userClan = clan
        if(clan.request){
          this.status=true;
        }
        //load all players
        this.loadPlayers();

      });
  }


  //Nils Wenzel
  createClan(){
    if (this.clanname) {
      this.clanService.createClan(this.clanname)
        .subscribe(() => {
          if(this.clanname) this.joinClan(this.clanname)
        });
    }else{
      alert("Gib dem Clan einen Namen!");
    }
  }

  joinClan(clanname: string){
    if(this.signedUser) this.clanService.joinClan(clanname, this.signedUser)
      .subscribe(() => window.location.reload());
  }

  leaveClan(){
    if(this.signedUser) this.clanService.leaveClan(this.signedUser)
      .subscribe(() => window.location.reload());
  }

  //Marc Prüfer
  startTournament(){
    if(this.userClan?.request!="open"){
      this.status=true;
      console.log(this.userClan?.request);
      if(this.userClan){
        this.userClan.request="open";
      }
      this.clanService.setRequest("open",this.userClan!).
      subscribe(() => window.location.reload());
    }
  }

  vote(){
    let number = this.allClanUser?.findIndex(clan => clan.username === this.signedUser);
    if(this.allClanUser[number].requestAccepted==0){
      this.count+=1;
      this.clanService.setRequestAccepted(this.signedUser!).subscribe(() => {
        this.allClanUser[number].requestAccepted=1;
        if(this.count==this.allClanUser.length&&this.allClanUser.length>=2){
          this.clanService.setRequest("started",this.userClan!).subscribe( ()=> window.location.reload());
        }
        else{
          this.count=0;
          this.loadPlayers();
        }
      })
    }
  }

  loadPlayers(){
    if(this.userClan) this.clanService.getClansByClanname(this.userClan.clanname)
      .subscribe(clanUsers => {
        this.allClanUser = clanUsers;
        this.length=this.allClanUser.length;
        for(let clanUsers of this.allClanUser){
          if(clanUsers.requestAccepted==1){
            this.count+=1;
          }
        }
        if(this.count==this.allClanUser.length&&this.userClan?.request=='open'&&this.allClanUser.length>=2){
          this.clanService.setRequest("started",this.userClan!).subscribe( ()=> window.location.reload());
        }
      })
  }


}
