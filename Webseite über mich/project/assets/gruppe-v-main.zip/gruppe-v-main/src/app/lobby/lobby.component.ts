import { Component } from '@angular/core';
import { v4 as uuidv4 } from 'uuid';
import {Router} from "@angular/router";


@Component({
  selector: 'app-lobby',
  standalone: true,
  imports: [],
  templateUrl: './lobby.component.html',
  styleUrl: './lobby.component.scss'
})
export class LobbyComponent {
  constructor(private router: Router) {}

  createGameSession(): void {
    const sessionId = uuidv4();
    this.router.navigate([`/app-card-game/${sessionId}`]);
  }
}
