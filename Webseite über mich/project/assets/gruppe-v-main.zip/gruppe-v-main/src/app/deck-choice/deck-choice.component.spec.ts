import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeckChoiceComponent } from './deck-choice.component';

describe('DeckChoiceComponent', () => {
  let component: DeckChoiceComponent;
  let fixture: ComponentFixture<DeckChoiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeckChoiceComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DeckChoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
