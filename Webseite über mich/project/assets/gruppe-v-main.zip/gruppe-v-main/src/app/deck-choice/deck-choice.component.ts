import { Component, OnInit } from '@angular/core';
import { NgForOf, NgIf } from '@angular/common';
import { DeckServiceService } from '../Services/services/deck-service.service';
import { CardServiceService } from '../Services/services/card.service.service';
import { DeckCardsService } from '../Services/services/deck-cards.service';
import { UserService } from '../Services/services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import {Observer, Subject} from 'rxjs';
import { WebSocketMessage } from '../Models/WebSocketMessage.model';
import {WebsocketService} from "../Services/services/websocket.service";
import {navigationStateModel} from "../Models/NavigationState.model";
import {GameService} from "../Services/services/game.service";
import {Game} from "../Models/Game.model";

interface Deck {
  id: number;
  name: string;
  cards: Card[];
  count: number;
  deckuser: string | undefined;
}


interface Card {
  id: number;
  name: string;
  rarity: string;
  attackPoints: number;
  defensePoints: number;
  description: string;
  imagePath: string;
}

@Component({
  selector: 'app-deck-choice',
  standalone: true,
  imports: [
    NgForOf,
    NgIf
  ],
  templateUrl: './deck-choice.component.html',
  styleUrls: ['./deck-choice.component.scss']
})
export class DeckChoiceComponent implements OnInit {

  availableDecks: Deck[] = [];
  availableCards: Card[] = [];
  myDeckData: any;
  myCardData: any;
  selectedDeck: Deck | null = null;

  username: string = this.userService.getPlayerData();

  private socket$: Subject<WebSocketMessage> | null = null;

  sessionId: string | null = null;
  playerRoles: any | null;
  private gameMode: number = 0; // 0 = normales Spiel, 1 = Turnier, 2 = Bot-Spiel
  test:number = 0;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private deckService: DeckServiceService,
    private cardService: CardServiceService,
    private deckCardsService: DeckCardsService,
    private userService: UserService,
    private ws: WebsocketService,
    private gs: GameService
  ) {
  }

  ngOnInit(): void {
    // Retrieve the sessionId from the router state
    this.route.paramMap.subscribe(params => {
      const state = this.router.getCurrentNavigation()?.extras.state as { sessionId: string, playerRole: string };
      this.sessionId = state?.sessionId ?? null;
      this.playerRoles = history.state.playerRole;
      this.gameMode = history?.state.gameMode;
    });

    this.socket$ = this.ws.connect('ws://localhost:8081');

    const observer: Observer<WebSocketMessage> = {
      next: (message: WebSocketMessage) => {
        this.onReceived(message);
      },
      error: (error) => console.error('WebSocket error:', error),
      complete: () => console.warn('WebSocket connection closed'),
    }

    if (this.socket$) this.socket$.subscribe(observer);

    this.deckService.getDecks(this.username).subscribe((data) => {
      this.myDeckData = data;
      for (let deck of this.myDeckData) {
        this.availableDecks.push(deck);
      }
    });

    this.cardService.getCards().subscribe((data) => {
      this.myCardData = data;
      for (let card of this.myCardData) {
        this.availableCards.push(card);
      }
    });
  }

  sendMessage(type: string, msg: any): void {
    if (this.socket$) {
      const message: WebSocketMessage = {type: type, data: msg};
      this.socket$.next(message);
    }
  }

  // sessionId: string, playerRole: string, deckChoice: Deck, gameMode: number

  makeNavigationState(){
    const navigationState:navigationStateModel = {
      sessionId: this.sessionId!,
      playerRole: this.playerRoles,
      deckChoice: this.selectedDeck!,
      gameMode: this.gameMode
    };
    const updatedGame: Partial<Game> = {
      deckId: this.selectedDeck?.id,
      gameMode: this.gameMode
    };
    console.log("TWICE?!");
    this.gs.updateGameSession(this.sessionId!, this.username!, updatedGame).subscribe((gameState) => {
      console.log(gameState);
    })

    return navigationState;
  }

  onReceived(message: WebSocketMessage): void {
    switch (message.type) {
      case 'navigateToDeckChoice': {
        this.sessionId = message.data.sessionId;
        //this.playerRoles = message.data.playerRoles;
        console.log(this.playerRoles, this.sessionId + "navigateToDeckChoice", this.gameMode);
        this.test++;
        console.log(this.test);
        if(this.gameMode == 2 && this.test === 1){
          console.log(this.test, "Hi");
          this.playerRoles = "Player 1"
          const updatedGame: Game = {
            sessionId: this.sessionId!,
            username: this.username,
            playerRole: this.playerRoles,
            deckId: this.selectedDeck!.id,
            gameMode: 2
          };
          console.log(updatedGame);
          this.gs.addGameSession(updatedGame).subscribe((gameState) => {
            console.log(gameState);
            this.router.navigate([`/app-card-game/${this.sessionId}`]);
          })

        }
        break;
      }
    }
  }

  selectDeck(deck: Deck): void {
    this.selectedDeck = deck;
    this.deckCardsService.getQuantity(this.selectedDeck.id).subscribe({
      next: (response: any) => {
        if (response != null && this.selectedDeck) {
          this.selectedDeck.count = response;
        }
      },
      error: (error) => {
        console.error('Error:', error);
        // Handle error appropriately
      }
    });

    this.deckCardsService.getCardIds(this.selectedDeck.id).subscribe({
      next: (response: any) => {
        if (this.selectedDeck) {
          this.selectedDeck.cards = [];
        }
        for (let card of response) {
          const matchingCard = this.availableCards.find(availableCard => availableCard.id === card);
          if (matchingCard) {
            this.selectedDeck?.cards.push(matchingCard);
          }
        }
      },
      error: (error) => {
        console.error('Error:', error);
        // Handle error appropriately
      }
    });
  }

  confirm(): void {
    if (this.gameMode === 2) {
      this.sendMessage('acceptDuel', null);
      console.log(this.gameMode);
      return;
    }
    const real = this.makeNavigationState();
    console.log(real)
    const updatedGame: Partial<Game> = {
      deckId: this.selectedDeck?.id,
      gameMode: this.gameMode
    };
    this.gs.updateGameSession(this.sessionId!, this.username!, updatedGame).subscribe((gameState) => {
      console.log(gameState);

      this.router.navigate([`/app-card-game/${this.sessionId}`]);
    })
    //this.router.navigate([`/app-card-game/${this.sessionId}`], {
    //  state: {
    //    real
    //  }
    //});
  }
}
