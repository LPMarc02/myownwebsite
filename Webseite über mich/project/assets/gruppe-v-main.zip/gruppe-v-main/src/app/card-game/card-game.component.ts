import {
  Component,
  ElementRef,
  NgZone,
  OnDestroy,
  OnInit,
  QueryList,
  ViewChildren
} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Deck} from '../Models/Deck.model';
import {WebsocketService} from '../Services/services/websocket.service';
import {Observer, Subject} from 'rxjs';
import {WebSocketMessage} from '../Models/WebSocketMessage.model';
import {Card} from "../Models/Card.model";
import {CommonModule, NgForOf} from "@angular/common";
import {PlayerService} from "../Services/services/player.service";
import {UserService} from "../Services/services/user.service";
import {TournamentService} from "../Services/services/tournament.service";
import {ClanService} from "../Services/services/clan.service";
import {Tournament} from "../Models/Tournament.model";
import {GameService} from "../Services/services/game.service";
import {DeckCardsService} from "../Services/services/deck-cards.service";
import {CardServiceService} from "../Services/services/card.service.service";
import {log} from "console";

interface GameStateMessage {
  type: 'gameStateUpdate';
  occupiedFieldsPlayer1: Card[];
  occupiedFieldsPlayer2: Card[];
  player1LifePoints: number;
  player2LifePoints: number;
  targetIndex: number | null;
  playerRole: string | null
}

export interface ExtendedCard extends Card {
  isFirstTurn: boolean;
  hasAttacked: boolean;
}

@Component({
  selector: 'app-card-game',
  standalone: true,
  imports: [
    NgForOf,
    CommonModule
  ],
  templateUrl: './card-game.component.html',
  styleUrls: ['./card-game.component.scss']
})

export class CardGameComponent implements OnInit, OnDestroy {
  private socket$: Subject<WebSocketMessage> | null = null;
  messages: string[] = [];
  receivedData: any;

  deckChoice: Deck = history?.state.deck;

  gameMode:number = 0;

  player1Deck: Deck = {
    id: 0,
    name: "",
    cards: [],
    count:0
  }
  //player2Deck: Deck | null = null;
  player2Deck: Deck = {
    id: 0,
    name: "",
    cards: [],
    count:0
  }
  player1Hand: Card[] = []; // Array to hold the drawn cards for Player 1
  player2Hand: Card[] = []; // Array to hold the drawn cards for Player 2
  timer: any;

  seconds: number = 120;
  timerDisplay: string = '120:00';
  selectedFieldIndex: number | null = null;
  selectedFieldLevel: 'upper' | 'lower' | null = null;
  showAttackButtonForUpper: boolean = false;
  selectedUpperFieldIndex: number | null = null;

  playerRole: string | null = null; // Player role: 'Player 1' or 'Player 2'
  sessionId: string | null = null; // Game session ID

  pendingMessages: WebSocketMessage[] = []; // Queue for pending messages

  temp: Card = {
    name: "null",
    rarity: '',
    attackPoints: 0,
    defensePoints: 0,
    description: '',
    imagePath: ''
  }


  //-- Hand von Player 1 und Player 2
  occupiedFieldsPlayer1: Card[] = [this.temp, this.temp, this.temp, this.temp, this.temp]; // Track occupied fields for Player 1
  occupiedFieldsPlayer2: Card[] = [this.temp, this.temp, this.temp, this.temp, this.temp]; // Track occupied fields for Player 2
  //-- Platzierte Karten von Player 1 und Player 2
  occupiedAttackPlayer1: Card[] = [this.temp, this.temp, this.temp, this.temp, this.temp]; // Track occupied fields for Player 1
  occupiedAttackPlayer2: Card[] = [this.temp, this.temp, this.temp, this.temp, this.temp]; // Track occupied fields for Player 2

  //-- Boolean Arrays
  hasAttacked: boolean[] = [false, false, false, false, false];
  isFirstTurn: boolean[] = [false, false, false, false, false];

  currentTurn: 'Player 1' | 'Player 2' = 'Player 1'; // Track the current turn

  player1LifePoints: number = 50; // Lebenspunkte für Spieler 1
  player2LifePoints: number = 50; // Lebenspunkte für Spieler 2

  hasDrawn: boolean = false;
  hasPlacedCard: boolean = false;
  hasSacrificed: boolean = false;

  sacrificeCounter: number = 0;

  selectedCardIndex: number | null = null;
  selectedTargetIndex: number | null = null;
  isSelectingAttackTarget: boolean = false;

  @ViewChildren('hand1') hand1Divs!: QueryList<ElementRef>;
  @ViewChildren('hand2') hand2Divs!: QueryList<ElementRef>;
  @ViewChildren('card1') card1Divs!: QueryList<ElementRef>;
  @ViewChildren('card2') card2Divs!: QueryList<ElementRef>;


  constructor(private route: ActivatedRoute, private router: Router, private ws: WebsocketService, private ngZone: NgZone, private playerService: PlayerService, private userService: UserService, private tournamentService: TournamentService, private clanService: ClanService, private gs: GameService, private deckCardsService: DeckCardsService, private cardService: CardServiceService) {
  }
  state:any;
  ngOnInit(): void {

    this.gs.getGameByUsername(this.userService.getPlayerData()).subscribe(gameData => {
      console.log(gameData);
      this.playerRole = gameData.playerRole;
      this.sessionId = gameData.sessionId;
      this.gameMode = gameData.gameMode;
      if(this.tournamentService.getGameMode()==1){
        this.gameMode=this.tournamentService.getGameMode();
      }

      console.log("GameMode: ", this.gameMode);
      console.log(gameData.deckId);
      let cardIds = [];
      if(gameData.playerRole == "Player 1"){
        this.deckCardsService.getCardIds(gameData.deckId).subscribe(
        (cards) => {
          cardIds = cards;
          console.log(cardIds);
          for (let cardId of cardIds) {
            console.log(gameData.deckId, cardId);
            this.cardService.getCard(cardId).subscribe((card) => {
              this.player1Deck.cards.push(card);
              if (this.gameMode === 2) {
                this.player2Deck.cards.push(card);
              }
            });
          }

        }
        )
      }
      else {
        this.deckCardsService.getCardIds(gameData.deckId).subscribe(
          (cards) => {
            cardIds = cards;
            console.log(cardIds);
            for (let cardId of cardIds){
              console.log(gameData.deckId, cardId)
              this.cardService.getCard(cardId).subscribe((card) =>
                (this.player2Deck.cards.push(card)
                ))}
          }
        )
      }
    })
    // Connect to WebSocket with sessionId
    this.socket$ = this.ws.connect(`ws://localhost:8081?sessionId=${this.sessionId}`);

    if (!this.playerRole) {
      this.sendMessage('requestPlayerRole', null); // Request player role assignment
    }


    const observer: Observer<WebSocketMessage> = {
      next: (message) => {
        this.onReceived(message);
      },
      error: (error) => console.error('WebSocket error:', error),
      complete: () => console.warn('WebSocket connection closed')
    };
    this.startTimer();

    if (this.socket$) this.socket$.subscribe(observer);

    if (history.state.deck) {
      this.sendMessage('deckChoice', history.state.deck);
    }
  }


  sendMessage(type: string, msg: any): void {
    if (this.socket$) {
      const message: WebSocketMessage = {type: type, data: msg};
      this.socket$.next(message);
    }
  }

  async onReceived(message: WebSocketMessage): Promise<void> {
    switch (message.type) {
      case 'assignPlayer': {
        if (!this.playerRole) { // Check if playerRole is already assigned
          //this.playerRole = "" + message.data;

          this.processPendingMessages(); // Process any pending messages after assigning player role
        }
        break;
      }
      case 'deckChoice': {
        if (!this.playerRole) {
          this.pendingMessages.push(message);
        } else {
          this.initializeDecks(message.data);
        }
        break;
      }
      case 'initGame': {

        break;
      }
      case 'timer': {
        this.seconds = parseInt(message.data.toString());
        this.updateTimerDisplay();
        break;
      }
      case 'turnChange': {
        this.currentTurn = message.data as 'Player 1' | 'Player 2';
        //if(this.currentTurn == 'Player 2') this.botBrain();
        this.resetRound();
        this.seconds = 120;
        break;
      }
      case 'cardPlaced': {
        const data = message.data;
        const playerRole = data.playerRole;
        const index = data.index;
        const attackFields = data.attackFields as Card[];
        if(this.gameMode!=2){
          if (playerRole === 'Player 1' && !this.isCurrentPlayerTurn()) {
            this.occupiedAttackPlayer1 = attackFields;
            this.updateCardDivs(this.card1Divs, attackFields);
          } else if (playerRole === 'Player 2' && !this.isCurrentPlayerTurn()) {
            this.occupiedAttackPlayer2 = attackFields;
            this.updateCardDivs(this.card2Divs, attackFields);
          }
        }
        break;
      }
      case 'gameStateUpdate': {
        this.updateGameState(message.data);
        break;
      }
      case 'gameOver': {

        if (typeof message.data === 'object' && 'player' in message.data) {

          const data = message.data as { player: string };
          const losingPlayer = data.player;
          const winningPlayer = losingPlayer === 'Player 1' ? 'Player 2' : 'Player 1';
          alert(`Game over! ${losingPlayer} has lost. ${winningPlayer} wins!`);

          if (message.data.player !== this.playerRole) {
            try {
              if(this.gameMode!=1){
                await this.updateLeaderboard(winningPlayer, losingPlayer);
                await this.updateSEP(winningPlayer);
              }
              else{
                this.setWinner(winningPlayer);
              }
              this.leaveGames();
            } catch (error) {
              console.error('Error updating leaderboard:', error);
            }
          }
        } else {
          console.error('Unexpected message format for gameOver:', message);

        }
        break;
      }
    }
  }

  botBrain(): void {
    let rand = Math.random(); // Generate a random number between 0 and 1
    this.drawCard();

    // Ensure lookForPlacableCard() is called only once
    let indexToPlace = -1;
    if (rand < 0.5) {
      console.log("Placing a card...");
      indexToPlace = this.lookForPlacableCard();
    }

    console.log("Random number: ", rand);

    switch (true) {
      case rand < 0.5: // 50% chance for placing a card
        if (indexToPlace !== -1) {
          console.log(indexToPlace);
          console.log("PLACING CARD...");
          this.newCard = this.occupiedFieldsPlayer2[indexToPlace];
          this.placeCard(indexToPlace); // Ensure placeCard() is only affecting Player 2
        } else {
          console.log("No card found...");
        }
        break;
      case rand < 0.8: // 30% chance for attacking
        let botFieldIndex = this.lookForValidCard(this.occupiedAttackPlayer2);
        let playerFieldIndex = this.lookForValidCard(this.occupiedAttackPlayer1);
        console.log(playerFieldIndex);
        if((botFieldIndex >= 0 && botFieldIndex <= 4) && (playerFieldIndex >= 0 && playerFieldIndex <= 4)) {
          console.log(`${botFieldIndex} (${this.occupiedAttackPlayer2[botFieldIndex].name}) with (${this.occupiedAttackPlayer2[botFieldIndex].attackPoints} | ${this.occupiedAttackPlayer2[botFieldIndex].defensePoints}) Attacking ${playerFieldIndex} (${this.occupiedAttackPlayer1[playerFieldIndex].name}) with (${this.occupiedAttackPlayer1[playerFieldIndex].attackPoints} | ${this.occupiedAttackPlayer1[playerFieldIndex].defensePoints})`);

          this.performAttack(botFieldIndex, playerFieldIndex);
        } else if((botFieldIndex >= 0 && botFieldIndex <= 4) && playerFieldIndex === -1){
          this.player1LifePoints = this.player1LifePoints - this.occupiedAttackPlayer2[botFieldIndex].attackPoints;
          if(this.player1LifePoints<=0&&this.gameMode==2){
            alert("Du hast leider verloren");
            this.gs.deleteGameSession(this.userService.getPlayerData());
            this.leaveGames();
          }
        } else {
          console.log("No valid card found...");
        }
        break;
      case rand < 0.9: // 10% chance for sacrificing
        console.log("Sacrificing...");
        // Loop through hand to see if theres a card above rarity normal.
        let rareCard = this.lookForSacrificableCard();
        if(rareCard === -1){
          console.log("No rare card found for sacrifice...");
          break;
        }
        let cardsNeededForSacrifice = (this.occupiedFieldsPlayer2[rareCard].rarity == "Selten") ? 2 : 3;
        // Then loop through AttackField and check if
        // you have either 2 cards for a Selten rarity or 3 for a Legendär rarity.
        let cardsToSacrifice = this.lookForCardsToSacrifice(cardsNeededForSacrifice);
        // For every card that is in attackField, add 1 to sacrificeCounter and mark the spot as clicked in this.clicked
        this.sacrificeCounter = cardsToSacrifice.length;
        for (let i = 0; i < cardsToSacrifice.length; i++) {
          this.clicked[i] = true;
        }
        console.log(rareCard);
        console.log(cardsToSacrifice);
        console.log(this.sacrificeCounter, this.clicked);
        this.newCard = this.occupiedFieldsPlayer2[rareCard];
        console.log(this.newCard);
        if(rareCard < 5 && rareCard > -1) this.placeCard(rareCard);
        break;
      default: // 10% chance for ending the turn
        console.log("Ending turn... RNG");
        break;
    }

    console.log("Ending turn.");
    this.endTurn();
  }

  lookForPlacableCard(){
    let index:number = -1;

    for (let i = 0; i < this.occupiedFieldsPlayer2.length; i++) {
      console.log("lookForPlacableCard()", (this.occupiedFieldsPlayer2[i].name !== 'null' && this.occupiedFieldsPlayer2[i].rarity == "Normal"), i)
      console.log(this.occupiedFieldsPlayer2[i].name, this.occupiedFieldsPlayer2[i].rarity);
      if(this.occupiedFieldsPlayer2[i].name !== 'null' && this.occupiedFieldsPlayer2[i].rarity == "Normal"){
        return i;
      }
    }
    return -1;
  }

  lookForValidCard(attackField:Card[]){
    let index:number = -1;

    for (let i = 0; i < attackField.length; i++) {
      if(attackField[i].name !== 'null'){
        index = i;
        break;
      }
    }
    return index;
  }

  lookForSacrificableCard(){
    // Check if Card exists where rarity either Selten or Legendär
    let hand = this.occupiedFieldsPlayer2;
    for (let i= 0; i < hand.length; i++) {
      if((hand[i].rarity == "Selten" || hand[i].rarity == "Legendär") && hand[i]){
        return i;
      }
    }
    return -1;
  }

  lookForCardsToSacrifice(cardsNeededForSacrifice:number){
    let index:number[] = [];
    let attackField = this.occupiedAttackPlayer2;

    for (let i = 0; i < attackField.length; i++) {
      if(attackField[i].name !== 'null' && index.length < cardsNeededForSacrifice){
        index.push(i);
      }
    }
    return index;
  }


  async updateLeaderboard(winner: string, loser: string): Promise<void> {
    try {

      const winnerPoints = await this.getLeaderboardPoints(winner);
      const loserPoints = await this.getLeaderboardPoints(loser);


      const pointsDifference = loserPoints - winnerPoints;
      const winnerPointsIncrease = Math.max(50, pointsDifference);
      const loserPointsDecrease = Math.max(50, pointsDifference / 2);


      this.setLeaderboardPoints(winner, winnerPoints + winnerPointsIncrease);
      this.setLeaderboardPoints(loser, loserPoints - loserPointsDecrease);


      const winnerPoints2 = await this.getLeaderboardPoints(winner);
      const loserPoints2 = await this.getLeaderboardPoints(loser);

    } catch (error) {
      console.error('Error updating leaderboard:', error);
    }
  }


  async updateSEP(winner: string): Promise<void> {
    try {
      const winnerSEP = await this.getSEP(winner);
      this.setSEP(winner, -100);
    } catch (error) {
      console.error('Error updating SEP:', error);
    }
  }

  getLeaderboardPoints(player: string): Promise<number> {

    return new Promise((resolve, reject) => {
      if (!player) {
        resolve(-1);
        return;
      }


      this.playerService.getLeaderboard(this.userService.getPlayerData()).subscribe({
        next: (response: any) => {
          const points = response as number;

          resolve(points);
        },
        error: (error: any) => {
          console.warn(error);
          reject(error);
        }
      });
    });
  }

  updateGameState(gameState: GameStateMessage): void {
    this.occupiedAttackPlayer1 = gameState.occupiedFieldsPlayer1;
    this.occupiedAttackPlayer2 = gameState.occupiedFieldsPlayer2;
    this.player1LifePoints = gameState.player1LifePoints;
    this.player2LifePoints = gameState.player2LifePoints;
    let role = gameState.playerRole;


    if (role === "Player 1") {

      if (gameState.targetIndex !== null) {
        this.card2Divs.forEach((cardDiv, index2) => {
          if (gameState.targetIndex == index2) {
            cardDiv.nativeElement.textContent = "Defeated";
          }
        });
      }
    } else if (role === "Player 2") {

      if (gameState.targetIndex !== null) {
        this.card1Divs.forEach((cardDiv, index2) => {
          if (gameState.targetIndex == index2) {
            cardDiv.nativeElement.textContent = "Defeated";
          }
        });
      }
    }
  }


  setLeaderboardPoints(player: string, points: number): void {
    if (!player || !points) {
      console.error("no player given.");
      return;
    }

    // Fetch the current leaderboard points for the player
    this.playerService.setLeaderboard(this.userService.getPlayerData(), points).subscribe({
      next: (response: any) => {
        const points = response as number;

      },
      error: (error: any) => {
        console.warn(error);
      }
    });
  }

  getSEP(player: string): Promise<number> {
    return new Promise((resolve, reject) => {
      if (!player) {
        resolve(-1);
        return;
      }

      // Fetch the current leaderboard points for the player
      this.playerService.getSepCoins(this.userService.getPlayerData()).subscribe({
        next: (response: any) => {
          const points = response as number;

          resolve(points);
        },
        error: (error: any) => {
          console.warn(error);
          reject(error);
        }
      });
    });
  }

  setSEP(player: string, sep: number): void {

    if (!player) {
      console.error("no player given.");
      return;
    }

    // Fetch the current leaderboard points for the player
    this.playerService.updateSEP(this.userService.getPlayerData(), sep).subscribe({
      next: (response: any) => {
        const points = response as number;

      },
      error: (error: any) => {
        console.warn(error);
      }
    });
  }

  leaveGames(): void {
    //Status auf online setzen
    this.userService.setUserOnline(this.userService.getPlayerData(), 'online').subscribe();

    // Schließe die WebSocket-Verbindung
    if (this.socket$) {
      this.socket$.complete();
      this.socket$ = null;
    }

    // Stoppe den Timer
    this.stopTimer();

    // Zeige eine Nachricht an oder logge den Vorgang

    if(this.sessionId){
      this.deleteSession(this.sessionId);
    }
    // Navigiere den Benutzer zu einer anderen Seite, z.B. zur Startseite
    this.router.navigate(['']);
  }

  updateCardDivs(cardDivs: QueryList<ElementRef>, attackFields: Card[]): void {
    cardDivs.forEach((cardDiv, index) => {
      (attackFields[index].name === "null") ? cardDiv.nativeElement.textContent = "Field " + (index + 1) : cardDiv.nativeElement.textContent = attackFields[index].name;
    });
  }


  isGameOverMessage(data: any): data is { message: string } {
    return (data as { message: string }).message !== undefined;
  }

  processPendingMessages(): void {
    this.pendingMessages.forEach(message => {
      if (message.type === 'deckChoice') {
        this.initializeDecks(message.data);
      }
    });
    this.pendingMessages = [];
  }

  resetRound() {
    this.hasDrawn = false;
    this.hasAttacked = [false, false, false, false, false];
    this.isFirstTurn = [false, false, false, false, false];
    this.hasSacrificed = false;
    this.hasPlacedCard = false;

    this.updateCardDivs(this.card2Divs, this.occupiedAttackPlayer2);
    this.updateCardDivs(this.card1Divs, this.occupiedAttackPlayer1);
  }

  initializeDecks(data: any): void {

    if (this.playerRole === 'Player 1') {
      this.player1Deck = data;
    } else if (this.playerRole === 'Player 2') {
      this.player2Deck = data;
    }
    if (this.player1Deck && this.player2Deck) {
      this.sendMessage('initGame', {player1Deck: this.player1Deck, player2Deck: this.player2Deck});
    }
  }

  ngOnDestroy(): void {
    this.stopTimer();
  }

  startTimer(): void {
    if (this.timerDisplay) {
      this.stopTimer();
      this.seconds = 120;
      this.timerDisplay = '120:00';
    }

    this.timer = setInterval(() => {
      if (this.seconds === 0) {
        clearInterval(this.timer);

        this.handleTimerEnd();
      } else {
        this.seconds--;
        this.sendMessage('timer', this.seconds);

        if (this.seconds === 20) {

          alert('Only 20 seconds left!');
        }
      }
      this.updateTimerDisplay();
    }, 1000);

    this.updateTimerDisplay();
  }

  stopTimer(): void {
    if (this.timer) {
      clearInterval(this.timer);
    }
  }

  handleTimerEnd(): void {
    if (this.currentTurn === 'Player 1') {
      this.player1LifePoints = -1;
      this.ngZone.run(() => {
      });
      setTimeout(() => {
        this.sendMessage('gameOver', {player: 'Player 1'});

      }, 10000);
    } else if (this.currentTurn === 'Player 2') {
      this.player2LifePoints = -1;
      this.ngZone.run(() => {
      });
      setTimeout(() => {
        this.sendMessage('gameOver', {player: 'Player 2'});

      }, 10000);
    }


  }

  updateTimerDisplay(): void {
    const minutes = Math.floor(this.seconds / 60);
    const seconds = this.seconds % 60;
    this.timerDisplay = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
  }

  selectCard(index: number): void {
    if (this.isCurrentPlayerTurn() || (this.gameMode === 2 && this.currentTurn === 'Player 2')) {
      this.selectedCardIndex = index;
      this.isSelectingAttackTarget = true;
      this.selectedTargetIndex = null; // Reset target selection

    } else {
      alert('Not your turn!');
    }
  }

  selectTarget(index: number): void {
    if (this.isSelectingAttackTarget) {
      this.selectedTargetIndex = index;
      this.isSelectingAttackTarget = false;


      this.performAttack(this.selectedCardIndex, this.selectedTargetIndex);

      this.selectedCardIndex = null; // Reset selection}
    }
  }

  performAttack(index: number | null, targetIndex: number): void {
    const isCurrentPlayerTurn = this.isCurrentPlayerTurn();
    const isPlayer2AndGameMode2 = this.currentTurn == "Player 2" && this.gameMode === 2;
    const hasNotAttacked = !this.hasAttacked[index!];
    const isNotFirstTurn = !this.isFirstTurn[index!];

    const condition1 = isCurrentPlayerTurn || isPlayer2AndGameMode2;
    const finalCondition = condition1 && hasNotAttacked && isNotFirstTurn;
    //console.log("isCurrentPlayerTurn || (currentTurn == 'Player 2' && gameMode === 2):", condition1);
    //console.log("isCurrentPlayerTurn:", isCurrentPlayerTurn);
    //console.log("currentTurn == 'Player 2' && gameMode === 2:", isPlayer2AndGameMode2);
    //console.log("!hasAttacked[index!]:", hasNotAttacked);
    //console.log("!isFirstTurn[index!]:", isNotFirstTurn);
    //console.log("Final Condition:", finalCondition);
    if ((this.isCurrentPlayerTurn() || (this.currentTurn == "Player 2" && this.gameMode === 2)) && !this.hasAttacked[index!] && !this.isFirstTurn[index!]) {
      this.hasAttacked[index!] = true;
      let gameStateMessage: GameStateMessage = {
        type: 'gameStateUpdate',
        occupiedFieldsPlayer1: this.occupiedAttackPlayer1,
        occupiedFieldsPlayer2: this.occupiedAttackPlayer2,
        player1LifePoints: this.player1LifePoints,
        player2LifePoints: this.player2LifePoints,
        targetIndex: (this.occupiedAttackPlayer1[targetIndex].defensePoints <= 0) ? targetIndex : null,
        playerRole: this.playerRole
      };
      if (this.playerRole === 'Player 1') {
        let empty = true;
        for (let i = 0; i < this.occupiedAttackPlayer2.length; i++) {
          if (this.occupiedAttackPlayer2[i].name != "null") {
            empty = false;
            break;
          }
        }

        if (empty) {

          this.player2LifePoints -= this.occupiedAttackPlayer1[index!].attackPoints;
          this.hasAttacked[index!] = true;


        } else if (!empty && this.occupiedAttackPlayer2[targetIndex]) {

          this.occupiedAttackPlayer2[targetIndex].defensePoints -= this.occupiedAttackPlayer1[index!].attackPoints;

          if (this.occupiedAttackPlayer2[targetIndex].defensePoints <= 0) {
            this.occupiedAttackPlayer2[targetIndex] = this.temp;
            this.card2Divs.forEach((cardDiv, index2) => {
              let cardDefeated = false;
              if (!cardDefeated && targetIndex == index2) {
                cardDiv.nativeElement.textContent = "Defeated";
                cardDefeated = true;
              }
            });
          } else {
            this.occupiedAttackPlayer1[index!].defensePoints -= this.occupiedAttackPlayer2[targetIndex].attackPoints;
            if (this.occupiedAttackPlayer1[index!].defensePoints <= 0) {
              this.occupiedAttackPlayer1[index!] = this.temp;
              this.card1Divs.forEach((cardDiv, index2) => {
                let cardDefeated = false;
                if (!cardDefeated && index! == index2) {
                  cardDiv.nativeElement.textContent = "Defeated";
                  cardDefeated = true;
                }
              });
            }
          }

        }
        gameStateMessage = {
          type: 'gameStateUpdate',
          occupiedFieldsPlayer1: this.occupiedAttackPlayer1,
          occupiedFieldsPlayer2: this.occupiedAttackPlayer2,
          player1LifePoints: this.player1LifePoints,
          player2LifePoints: this.player2LifePoints,
          targetIndex: (this.occupiedAttackPlayer2[targetIndex].defensePoints <= 0) ? targetIndex : null,
          playerRole: this.playerRole
        };
        if (this.player2LifePoints <= 0) {

          this.sendMessage('gameOver', {player: 'Player 2'});
          return;
        }
      } else if (this.playerRole === 'Player 2') {
        let empty = true;
        for (let i = 0; i < this.occupiedAttackPlayer1.length; i++) {
          if (this.occupiedAttackPlayer1[i].name != "null") {
            empty = false;
            break;
          }
        }

        if (empty) {

          this.player1LifePoints -= this.occupiedAttackPlayer2[index!].attackPoints;
        } else if (!empty && this.occupiedAttackPlayer1[targetIndex]) {

          this.occupiedAttackPlayer1[targetIndex].defensePoints -= this.occupiedAttackPlayer2[index!].attackPoints;

          if (this.occupiedAttackPlayer1[targetIndex].defensePoints <= 0) {
            this.occupiedAttackPlayer1[targetIndex] = this.temp;
            this.card1Divs.forEach((cardDiv, index2) => {
              let cardDefeated = false;
              if (!cardDefeated && targetIndex == index2) {
                cardDiv.nativeElement.textContent = "Defeated";
                cardDefeated = true;
              }
            });
          } else {
            this.occupiedAttackPlayer2[index!].defensePoints -= this.occupiedAttackPlayer1[targetIndex].attackPoints;
            if (this.occupiedAttackPlayer1[index!].defensePoints <= 0) {
              this.occupiedAttackPlayer2[index!] = this.temp;
              this.card2Divs.forEach((cardDiv, index2) => {
                let cardDefeated = false;
                if (!cardDefeated && index! == index2) {
                  cardDiv.nativeElement.textContent = "Defeated";
                  cardDefeated = true;
                }
              });
            }
          }
        }

        gameStateMessage = {
          type: 'gameStateUpdate',
          occupiedFieldsPlayer1: this.occupiedAttackPlayer1,
          occupiedFieldsPlayer2: this.occupiedAttackPlayer2,
          player1LifePoints: this.player1LifePoints,
          player2LifePoints: this.player2LifePoints,
          targetIndex: (this.occupiedAttackPlayer1[targetIndex].defensePoints <= 0) ? targetIndex : null,
          playerRole: this.playerRole
        };
        if (this.player1LifePoints <= 0) {
          this.sendMessage('gameOver', {player: 'Player 1'});
          return;
        }


      }
      // Prepare the message with updated state

      // Send the message via WebSocket

      this.sendMessage(gameStateMessage.type, gameStateMessage);
    } else {
      alert('Not your turn!');
    }
  }


  drawCard(): void {
    if (this.hasDrawn) {
      return;
    }
    if (this.playerRole === 'Player 1' && this.isCurrentPlayerTurn()) {
      this.drawCardForPlayer(this.player1Deck!, this.player1Hand, this.occupiedFieldsPlayer1, this.hand1Divs);
    } else if (this.playerRole === 'Player 2' && this.isCurrentPlayerTurn() || (this.gameMode === 2 && this.currentTurn === 'Player 2')) {
      console.log("drawing");
      this.drawCardForPlayer(this.player2Deck!, this.player2Hand, this.occupiedFieldsPlayer2, this.hand2Divs);
    } else {

      alert('It is not your turn or you do not have a valid deck!');
    }
  }

  drawCardForPlayer(deck: Deck, hand: Card[], occupiedFields: Card[], handDivs: QueryList<ElementRef>): void {
    let found = false;
      for (let i = 0; i < occupiedFields.length; i++) {
        if (occupiedFields[i].name == "null" && !found){
          console.log("Card to place: ", i, occupiedFields[i]);
          found = true;
          break;
        }
      }

    if(!found) {
      return;
    }

    const randomIndex = Math.floor(Math.random() * deck.cards.length);
    const drawnCard = deck.cards.splice(randomIndex, 1)[0]; // Remove the drawn card from the deck
    //if(drawnCard == null) return;
    let cardPlaced = false;
    const index = occupiedFields.findIndex(field => !cardPlaced && field.name === "null" && drawnCard);

    if (index !== -1) {
      console.log("Draw at: ", index, occupiedFields[index]);
      handDivs.get(index)!.nativeElement.textContent = drawnCard.name;
      occupiedFields[index] = drawnCard; // Mark the field as occupied
      cardPlaced = true; // Mark that the card has been placed
    }
    this.hasDrawn = true;
  }

  placeCard(index: number) {
    //console.log(this.currentTurn, this.isCurrentPlayerTurn(), this.playerRole);
    if (this.playerRole === 'Player 1' && this.isCurrentPlayerTurn()) {
      this.placeCardForPlayer(index, this.player1Hand, this.occupiedAttackPlayer1, this.occupiedFieldsPlayer1, this.card1Divs, this.hand1Divs);
    } else if ((this.playerRole === 'Player 2' && this.isCurrentPlayerTurn()) || (this.gameMode === 2 && this.currentTurn === 'Player 2')) {
      this.placeCardForPlayer(index, this.player2Hand, this.occupiedAttackPlayer2, this.occupiedFieldsPlayer2, this.card2Divs, this.hand2Divs);
    } else {
      alert('It is not your turn or you do not have a valid deck!');
    }
  }


 newCard:Card = this.temp;
  placeCardForPlayer(index1: number, hand: Card[], attackFields: Card[], occupiedFields: Card[], cardDivs: QueryList<ElementRef>, handDivs: QueryList<ElementRef>): void {
    let found = false;
      for (let i = 0; i < attackFields.length; i++) {
        if (attackFields[i].name == "null" && !found){
          found = true;
          break;
        }
      }
    console.log("Place to place: ", found);

    let index = index1;

    // Get the card from the player's hand at the specified index
    const cardToPlace = occupiedFields[index1];
    if (this.hasPlacedCard || (!found && !((cardToPlace.rarity == "Selten" && this.sacrificeCounter >= 2) || (cardToPlace.rarity == "Legendär" && this.sacrificeCounter >= 3)))) {
      console.log("PLACING = NO");
      console.log(cardToPlace.rarity == "Selten" && this.sacrificeCounter >= 2);
      console.log(cardToPlace.rarity == "Legendär" && this.sacrificeCounter >= 3);
      return;
    }
    if((cardToPlace.rarity == "Selten"  || (cardToPlace.rarity == "Legendär"))){
      console.log("HALLOOOOOO");
      // Iterate through the isClicked array to remove the sacrificed cards
      for (let i = 0; i < attackFields.length; i++) {
        if (this.clicked[i]) {
          attackFields[i].name = "null"; // Mark the field as empty

          // Update the UI for the attack field
          const cardDiv = cardDivs.get(i);
          if (cardDiv) {
            cardDiv.nativeElement.textContent = ""; // Clear the UI element
          }
        }
      }
    }

    console.log(index1);
    console.log(cardToPlace);
    console.log(attackFields);
    console.log(occupiedFields);
    //console.log(this.occupiedAttackPlayer1);
    if ((cardToPlace.rarity == "Selten" && this.sacrificeCounter >= 2) ||
      (cardToPlace.rarity == "Legendär" && this.sacrificeCounter >= 3 ||
        (cardToPlace.rarity == "Normal"))) {
      // Ensure index is within valid range
      if (index1 < 0 || index1 >= attackFields.length) {

        return;
      }
      console.log("Hallo");
      // Find the next available slot in attackFields
      for (let i = 0; i < attackFields.length; i++) {
        if (attackFields[i].name == "null") {

          index = i;
          break;
        }
      }
      console.log("Hallo");
      if (!cardToPlace) {

        return;
      }
        console.log("Hallo");
        // Place the card in the attack field
        attackFields[index] = cardToPlace;

        // Clear the occupied field (remove the card from hand)
        console.log("Card to null: ", index, occupiedFields[index].name);
        occupiedFields[index1] = this.temp;
        // Update UI
        cardDivs.forEach((cardDiv, idx) => {
          if (idx === index) {
            console.log(idx);
            cardDiv.nativeElement.textContent = cardToPlace.name;
          }
        });
      handDivs.forEach((handDiv, index2) => {
        if (index1 === index2) {

          handDiv.nativeElement.textContent = "Hand " + (index1+1);
        }
      })
      console.log("isFirstTurn: ", index);
      this.isFirstTurn[index] = true;

      //console.log("Before send: ");
      //console.log(this.occupiedAttackPlayer1, "Player 1's attack field.");
      //console.log(this.occupiedAttackPlayer2, "Player 2's attack field.");

      this.sendCardPlacement(index, attackFields);

      this.hasPlacedCard = true;
    }
  }


  sendCardPlacement(index: number, attackFields: (Card | null)[]): void {
    const message: WebSocketMessage = {
      type: 'cardPlaced',
      data: {
        playerRole: this.playerRole,
        index: index,
        attackFields: attackFields
      }
    };

    this.sendMessage('cardPlaced', message.data);
  }


  isCurrentPlayerTurn(): boolean {
    return this.playerRole === this.currentTurn;
  }

  endTurn(): void {
    if (this.isCurrentPlayerTurn() || (this.gameMode === 2 && this.currentTurn === 'Player 2')) {
      // Example: Perform end turn actions like resetting selected fields, updating turn state, etc.
      this.currentTurn = this.currentTurn === 'Player 1' ? 'Player 2' : 'Player 1';

      this.sendMessage('turnChange', this.currentTurn);
      this.resetRound();

      // Reset selected fields and UI state
      this.selectedFieldIndex = null;
      this.selectedFieldLevel = null;
      this.showAttackButtonForUpper = false;
      this.selectedUpperFieldIndex = null;
      this.clicked = [false, false, false, false, false];
      this.sacrificeCounter = 0;

      // Start timer for the new turn
      this.startTimer();
      // Check if the next turn is the bot's turn
      if (this.gameMode === 2 && this.currentTurn !== 'Player 1') {
        this.botBrain();
      }
    } else {
      alert('Not your turn!');
    }
  }


  clicked: boolean[] = [false, false, false, false, false];

  onRightClick(event: MouseEvent, index: number) {
    event.preventDefault();
    if (this.clicked[index]) {
      this.clicked[index] = false;
      this.sacrificeCounter--;
    } else {
      this.clicked[index] = true;
      this.sacrificeCounter++;
    }
  }

  setWinner(player:string){
    if (!player) {
      console.error("no player given.");
      return;
    }
    console.log(this.userService.getPlayerData());
    if(this.playerRole==player){
      this.tournamentService.setWinner(this.userService.getPlayerData()).subscribe();
    }
  }

  deleteSession(session: string){
    this.gs.deleteSession(session).subscribe();
  }
}
