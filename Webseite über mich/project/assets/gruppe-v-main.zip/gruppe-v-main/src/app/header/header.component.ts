import { Component, OnInit } from '@angular/core';
import {NavigationEnd, Router, RouterLink} from "@angular/router";
import {JsonPipe, NgIf, NgOptimizedImage} from "@angular/common";
import {UserService} from "../Services/services/user.service";
import {User} from "../Models/User.model";
import {PlayerService} from "../Services/services/player.service";
import {DuellRequestComponent} from "../duell-request/duell-request.component";
import {GameService} from "../Services/services/game.service";


@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    RouterLink,
    NgOptimizedImage,
    NgIf,
    JsonPipe,
    DuellRequestComponent
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})

export class HeaderComponent implements OnInit{
  constructor(private userService: UserService, private router: Router, private playerService:PlayerService, private gameService: GameService) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // Check if the current route is the LootboxenComponent
        this.showButton = this.router.url.includes('/lootboxen');
      }
    });

    this.username = this.userService.getPlayerData();
    if (this.username != undefined) {
      this.userService.getUserByUsername(this.username)
        .subscribe(user => this.selectedUser = user)
      console.log('Angemeldet! (Wahrscheinlich)')
    }else{
      console.log('Nicht angemeldet!')
    }
    this.signedIn = this.username != undefined;

  }

  selectedUser: User = {
    birthDate: "", email: "", firstName: "unknown", lastName: "user", password: "", profilePicture: "img0", username: "unknown_user",friendListPrivate:false
  };
  username: string | undefined;
  signedIn: boolean;
  sepCoins: number|undefined;
  showButton: boolean = false;
  permission: boolean = true;


  ngOnInit(){
    this.setSepCoins();
  }

  routing(username: string | undefined){
    this.router.navigate(['Profile', username]).then(() => this.reloadPage());
  }

  routingHome(){
    this.userService.setUserOnline(this.selectedUser.username,"online").subscribe();
    this.gameService.deleteGameSession(this.username!).subscribe(() => {
      console.log("Entries deleted");
    })
    this.router.navigate(['']).then(() => this.reloadPage());
  }

  setSepCoins(){
    if(this.signedIn){
      this.userService.getPermission(this.username).subscribe({
        next: (permission: boolean) => {
          this.permission=permission;
          if(this.username&&!this.permission){
            this.playerService.getSepCoins(this.username).subscribe(coins => this.sepCoins = coins);
          }
        },
      });
    }
  }

  //Diese Methode stammt aus der Backend-Lösung auf Moodle
  private reloadPage() {
    window.location.reload();
  }
}
