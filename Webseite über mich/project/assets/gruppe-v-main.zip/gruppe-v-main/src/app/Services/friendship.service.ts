import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Friendship} from "../Models/Friendship.model";

@Injectable({
  providedIn: 'root'
})


export class FriendshipService {

  constructor(private http: HttpClient) { }

  getUserFriendships(userId: number | undefined) {
    return this.http.get<any[]>(`http://localhost:8080/api/friendship/user/${userId}`);
  }

  deleteFriendship(userId: number |undefined , friendId: number |undefined) {
    return this.http.delete(`http://localhost:8080/api/friendship/delete/Friendship?userId=${userId}&friendId=${friendId}`);
  }


  getAllFriendships( ): Observable<Friendship[]> {
   return this.http.get<Friendship[]>(' http://localhost:8080/api/friendship/show/AllFriendships');
  }


}
