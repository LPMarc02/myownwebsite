import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Card} from "../../Models/Card.model";

@Injectable({
  providedIn: 'root',
})
export class CardServiceService {

  constructor(private http: HttpClient) { }

  getCards() {
    return this.http.get("http://localhost:8080/api/cards/getCards");
  }
  getCard(id:number) {
    return this.http.get<Card>(`http://localhost:8080/api/cards/getCard/${id}`);
  }


  deleteCard(cardId: number | undefined) {
    return this.http.delete(`http://localhost:8080/api/cards/deleteCards/${cardId}`);
  }

  addCard(card: Card) {
    return this.http.post('http://localhost:8080/api/cards/addCards', card);
  }

  updateCard(cardId: number, newData: any) {
    return this.http.put(`http://localhost:8080/api/cards/updateCards/${cardId}`, newData);
  }

  patchCard(cardId: number, newData: any) {
    return this.http.patch(`http://localhost:8080/api/cards/patchCards/${cardId}`, newData);
  }
}
