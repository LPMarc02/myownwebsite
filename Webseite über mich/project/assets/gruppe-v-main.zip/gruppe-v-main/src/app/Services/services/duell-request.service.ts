import {Injectable} from '@angular/core';
import {UserService} from "./user.service";
import {HttpClient} from "@angular/common/http";
import {DuellRequest} from "../../Models/DuellRequest.model";
import {Subject} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class DuellRequestService {
  private apiUrl = "http://localhost:8080/api/duell-request";
  private eventSubject: Subject<void> = new Subject();
  event$ = this.eventSubject.asObservable();
  username?: string;
  duellRequest: DuellRequest | undefined;

  constructor(private http: HttpClient, private userService: UserService) {
    this.username=this.userService.getPlayerData()
  }

  sendRequest(receiver: string){
    if(receiver != this.username && this.username){

      const request: DuellRequest = {
        receiver: receiver,
        sender: this.username ? this.username : '',
        status: "open"
      }
      this.checkResults(request);
    }else{
      alert("Du kannst dir selbst keine Duell-Herausforderung senden!")
    }
  }

  checkResults(request: DuellRequest){
    this.checkRequest(request).subscribe(response => {
      switch(response){
        case 'true':{
          console.log('Erfolgreiche request')
          this.duellRequest = request;
          this.eventSubject.next();
          break;
        }
        case 'sender no deck': {
          alert("Du musst erst ein Deck erstellen, bevor du eine Duell-Herausforderung senden kannst!");
          break;
        }
        case 'receiver no deck': {
          alert("Der Spieler besitz noch kein Deck und kann deshalb nicht zu einem Spiel eingeladen werden!")
          break;
        }
        case 'receiver offline': {
          alert("Der Spieler ist offline und kann deshalb nicht eingeladen werden!")
          break;
        }
        case 'receiver ingame': {
          alert("Der Spieler ist schon in einem Spiel. Versuche es später erneut!")
          break;
        }
      }
    })
  }

  getRequest(){
    return this.duellRequest;
  }

  checkRequest(request: DuellRequest){
    const url = `${this.apiUrl}/checkRequest`;
    return this.http.post(url, request, { responseType: 'text' });
  }

  deleteRequest(sender: string) {
    const url = `${this.apiUrl}/deleteRequest?sender=${sender}`;
    return this.http.delete(url);
  }

  sendRequest2(receiver: string){
    if(receiver != this.username && this.username){

      const request: DuellRequest = {
        receiver: receiver,
        sender: this.username ? this.username : '',
        status: "open",
        gameMode: 1
      }
      this.checkResults(request);
    }else{
      alert("Du kannst dir selbst keine Duell-Herausforderung senden!")
    }
  }
}
