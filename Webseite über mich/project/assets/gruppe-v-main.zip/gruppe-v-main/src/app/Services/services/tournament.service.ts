import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Tournament} from "../../Models/Tournament.model";

@Injectable({
  providedIn: 'root'
})
export class TournamentService {

  private apiUrl = 'http://localhost:8080/api/tournament';

  constructor(private http: HttpClient) { }

  GameMode: number=0;

  setMatch(clanName:string, username1:string, username2: string){
    const url = `${this.apiUrl}/setMatch`;
    const body={
      clanName:clanName,
      username1:username1,
      username2:username2
    }
    return this.http.post(url, body);
  }
  getMatch(clanName:string){
    const url = `${this.apiUrl}/getMatch/${clanName}`;
    return this.http.get<Tournament[]>(url);
  }

  setWinner(username: string){
    const url = `${this.apiUrl}/setWinner`;
    return this.http.put(url,username);
  }

  setGameMode(GameMode: number| undefined){
    if(GameMode){
      this.GameMode=GameMode;
    }
  }

  getGameMode():number{
    return this.GameMode;
  }

  deleteAll(clanName:string){
    const url = `${this.apiUrl}/deleteAll/${clanName}`;
    return this.http.delete(url);
  }
}
