// src/app/Services/services/websocket.service.ts

import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { WebSocketMessage } from '../../Models/WebSocketMessage.model'; // Correct import path

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private socket: WebSocket | null = null;
  private subject: Subject<WebSocketMessage> | null = null;

  public connect(url: string): Subject<WebSocketMessage> {
    if (!this.subject) {
      this.subject = this.create(url);
    }
    return this.subject;
  }

  private create(url: string): Subject<WebSocketMessage> {
    this.socket = new WebSocket(url);

    const observable = new Observable<WebSocketMessage>((observer) => {
      this.socket!.onmessage = (event) => {
        const message: WebSocketMessage = JSON.parse(event.data);
        observer.next(message);
      };
      this.socket!.onerror = observer.error.bind(observer);
      this.socket!.onclose = observer.complete.bind(observer);
      return () => this.socket!.close();
    });

    const observer = {
      next: (data: WebSocketMessage) => {
        if (this.socket && this.socket.readyState === WebSocket.OPEN) {
          if (!data.id) {
            data.id = uuidv4();
            this.socket.send(JSON.stringify(data));
          }
        }
      }
    };

    const subject = new Subject<WebSocketMessage>();
    subject.subscribe(observer as any);
    observable.subscribe(subject);

    return subject;
  }
}

