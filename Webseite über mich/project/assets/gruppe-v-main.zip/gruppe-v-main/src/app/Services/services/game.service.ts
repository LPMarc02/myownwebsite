import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Game} from "../../Models/Game.model";


@Injectable({
  providedIn: 'root'
})
export class GameService {

  private apiUrl = 'http://localhost:8080/api/games'; // Base URL for your backend API

  constructor(private http: HttpClient) { }

  addGameSession(game: Game): Observable<Game> {
    console.log(game);
    return this.http.post<Game>(`${this.apiUrl}/add`, game);
  }

  updateGameSession(sessionId: string, username: string, game: Partial<Game>): Observable<Game> {
    console.log(game);
    return this.http.patch<Game>(`${this.apiUrl}/update/${sessionId}/${username}`, game);
  }

  deleteGameSession(username: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/delete/${username}`);
  }

  deleteSession(session: string){
    return this.http.delete(`${this.apiUrl}/deleteSession/${session}`);
  }

  getGameSession(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  getGameBySessionId(sessionId: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/sessionId/${sessionId}`);
  }

  getGameByUsername(username: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/username/${username}`);
  }

  getGameByPlayerRole(playerRole: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/playerRole/${playerRole}`);
  }

  getGameByDeckId(deckId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/deckId/${deckId}`);
  }

  getGameByGameMode(gameMode: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/gameMode/${gameMode}`);
  }

  // Setters
  setSessionId(id: number, sessionId: string): Observable<any> {
    const payload = { sessionId: sessionId };
    return this.http.put<any>(`${this.apiUrl}/${id}/sessionId`, payload);
  }

  setUsername(id: number, username: string): Observable<any> {
    const payload = { username: username };
    return this.http.put<any>(`${this.apiUrl}/${id}/username`, payload);
  }

  setPlayerRole(id: number, playerRole: string): Observable<any> {
    const payload = { playerRole: playerRole };
    return this.http.put<any>(`${this.apiUrl}/${id}/playerRole`, payload);
  }

  setDeckId(id: number, deckId: number): Observable<any> {
    const payload = { deckId: deckId };
    return this.http.put<any>(`${this.apiUrl}/${id}/deckId`, payload);
  }

  setGameMode(id: number, gameMode: number): Observable<any> {
    const payload = { gameMode: gameMode };
    return this.http.put<any>(`${this.apiUrl}/${id}/gameMode`, payload);
  }
}
