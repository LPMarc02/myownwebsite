import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Clan} from "../../Models/Clan.model";
import {ClanUser} from "../../Models/ClanUser.model";

@Injectable({
  providedIn: 'root'
})
export class ClanService {
  private apiUrl = "http://localhost:8080/api/clan";

  constructor(private http: HttpClient) { }

//Nils Wenzel
  getClans(){
    const url = `${this.apiUrl}/clans`;
    return this.http.get<Clan[]>(url);
  }

  getClanByUsername(username: string | undefined){
    const url = `${this.apiUrl}/clans/${username}`;
    return this.http.get<Clan>(url);
  }

  getClansByClanname(clanname: string | undefined){
    const url = `${this.apiUrl}/clanUsers/${clanname}`;
    return this.http.get<ClanUser[]>(url);
  }

  joinClan(clanname: string, username: string){
    const url = `${this.apiUrl}/joinClan/${clanname}`;
    return this.http.post(url, username);
  }

  leaveClan(username: string){
    const url = `${this.apiUrl}/leaveClan/${username}`;
    return this.http.delete(url);
  }

  createClan(clanname: string | undefined) {
    const url = `${this.apiUrl}/createClan`;
    return this.http.post(url, clanname);
  }

  getUserClanByUsername(signedUser: string | undefined) {
    const url = `${this.apiUrl}/getUserClanByUsername/${signedUser}`;
    return this.http.get<ClanUser>(url);
  }

  setBet(user: String, bet: string) {
    const url = `${this.apiUrl}/setBet/${user}`;
    return this.http.put(url, bet);
  }

  resolveBet(winner: string) {
    const url = `${this.apiUrl}/resolveBet/${winner}`;
    return this.http.delete(url);
  }

//Marc Prüfer
  setRequest(status:string, clan:Clan){
    const url = `${this.apiUrl}/setRequest/${status}`;
    return this.http.put(url,clan);
  }

  setRequestAccepted(username:string){
    const url = `${this.apiUrl}/setRequestAccepted`;
    return this.http.put(url,username);
  }

  setRequestNull(username:string){
    const url = `${this.apiUrl}/setRequestNull`;
    return this.http.put(url,username);
  }
}
