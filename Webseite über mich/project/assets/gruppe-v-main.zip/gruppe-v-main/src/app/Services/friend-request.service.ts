import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import {FriendRequest} from "../Models/FriendRequestModel";

@Injectable({
  providedIn: 'root'
})
export class FriendRequestService {

  private apiUrl = 'http://localhost:8080/api/friend-request';



  constructor(private http: HttpClient) { }

  getPendingFriendRequests(receiverId: number | undefined) {
    return this.http.get<any[]>(`http://localhost:8080/api/friend-request/pending?receiverId=${receiverId}`);
  }

  sendFriendRequest(friendRequest: any) {
    return this.http.post(`http://localhost:8080/api/friend-request/send`, friendRequest);
  }

  getSentFriendRequests(senderId: number): Observable<FriendRequest[]> {
    return this.http.get<FriendRequest[]>(`${this.apiUrl}/sent?senderId=${senderId}`);
  }


  acceptFriendRequest(requestId: number) {
    return this.http.put(`http://localhost:8080/api/friend-request/accept/${requestId}`, {});
  }

  rejectFriendRequest(requestId: number) {
    return this.http.delete(`http://localhost:8080/api/friend-request/reject/${requestId}`);
  }
  getFriendRequestsForUser(userId: number | undefined): Observable<FriendRequest[]> {
    return this.http.get<FriendRequest[]>(`http://localhost:8080/api/friend-request/receiver/${userId}`);
  }
}
