import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Card} from "../../Models/Card.model";
import {Deck} from "../../Models/Deck.model";

@Injectable({
  providedIn: 'root',
})
export class DeckCardsService {

  constructor(private http: HttpClient) {
  }

  addCardToDeck(deck: number, cardData: number) {
    console.log(deck, cardData); //Test
    return this.http.post("http://localhost:8080/api/v1/deck_cards", {deckId: deck, cardId: cardData});
  }

  getQuantity(deckId: number) {
    const url = `http://localhost:8080/api/v1/getQuantity?deck_id=${deckId}`;
    return this.http.get<number>(url); // Specify the expected response type as number
  }

  getCardIds(deckId: number) {
    const url = `http://localhost:8080/api/v1/getCardIds?deck_id=${deckId}`;
    return this.http.get<number[]>(url); // Specify the expected response type as number
  }

  deleteCard(deckId: number, cardId: number) {
    return this.http.delete(`http://localhost:8080/api/v1/deleteCard/${deckId}/${cardId}`);
  }
}
