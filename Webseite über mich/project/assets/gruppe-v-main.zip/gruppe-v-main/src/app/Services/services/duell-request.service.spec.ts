import { TestBed } from '@angular/core/testing';

import { DuellRequestService } from './duell-request.service';

describe('DuellRequestService', () => {
  let service: DuellRequestService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DuellRequestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
