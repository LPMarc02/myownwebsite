import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Player} from "../../Models/Player.model";

@Injectable({
  providedIn: 'root'
})
export class PlayerService {
  private apiUrl = 'http://localhost:8080/api/players';

  constructor(private http: HttpClient) { }

  getAllPlayers() {
    const url = `${this.apiUrl}/showAllPlayers`;
    return this.http.get<Player[]>(url);
  }

  getPlayerById(id: number): Observable<Player> {
    const url = `${this.apiUrl}/getPlayerById?id=${id}`;
    return this.http.get<Player>(url);
  }

  updateProfilePicture(id: number, profilePicture: string) {
    const url = `${this.apiUrl}/${id}/updateProfilePicture`;
    return this.http.put(url, profilePicture);
  }

  addPlayer(player:Player):Observable<Player>{
    const url = `${this.apiUrl}/addd`;
    return this.http.post<Player>(url,player);
  }

  getSepCoins(username: string | undefined) {
    const url = `${this.apiUrl}/getSepCoins?username=${username}`;
    return this.http.get<number>(url);
  }

  getLeaderboard(username: string | undefined) {
    const url = `${this.apiUrl}/getLeaderboard?username=${username}`;
    return this.http.get<number>(url);
  }

  setLeaderboard(username: string, points: number): Observable<void> {
    const url = `${this.apiUrl}/setLeaderboard`;
    const body = { username, points };
    return this.http.patch<void>(url, body);
  }

  updateSEP(username:string,price:number){
    const url = `${this.apiUrl}/${price}/updateSEP`;
    return this.http.put(url, username);
  }
  getLeaderBoard1(){
    const url = `${this.apiUrl}/leaderboard`;
    return this.http.get<Player>(url);
  }

  searchUsers(username: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/search?username=${username}`);
  }

  getUserByUsername(username: string | undefined): Observable<Player> {
    const url = `${this.apiUrl}/getUserByUsername?username=${username}`;
    return this.http.get<Player>(url);
  }

}
