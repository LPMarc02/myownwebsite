import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class LootboxenService {

  private apiUrl = 'http://localhost:8080/api/lootboxen';
  private apiUrlCardUser= 'http://localhost:8080/api/CardUser';

  constructor(private http: HttpClient) { }

  addBox(username:string, box:string):Observable<any>{
    const url = `${this.apiUrl}/addBox`;
    const lootBox={
      username:username,
      box:box
    }
    return this.http.post(url,lootBox);
  }
  getLootBoxen(username:string){
    const url = `${this.apiUrl}/getLootBoxen?username=${username}`;
    return this.http.get(url);
  }
  lootBoxDelete(number:number){
    const url = `${this.apiUrl}/deleteBox?number=${number}`;
    return this.http.delete(url);
  }
  addCardsToUser(username:string,cardId:number){
    const url = `${this.apiUrlCardUser}/addCardsToUser`;
    const card={
      username:username,
      cardId:cardId
    }
    return this.http.post(url,card);
  }
  getCardsFromUser(username:string){
    const url = `${this.apiUrlCardUser}/getCardsFromUser?username=${username}`;
    return this.http.get(url);
  }

}
