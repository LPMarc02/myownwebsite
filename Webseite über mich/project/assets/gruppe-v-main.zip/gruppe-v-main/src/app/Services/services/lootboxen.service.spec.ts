import { TestBed } from '@angular/core/testing';

import { LootboxenService } from './lootboxen.service';

describe('LootboxenService', () => {
  let service: LootboxenService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LootboxenService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
