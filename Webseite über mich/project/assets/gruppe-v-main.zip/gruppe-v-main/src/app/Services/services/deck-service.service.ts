import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {json} from "node:stream/consumers";

@Injectable({
  providedIn: 'root',
})
export class DeckServiceService {

  constructor(private http: HttpClient) { }

  getDecks(deckuser: string | undefined){
    return this.http.get(`http://localhost:8080/api/v1/decks?deckuser=${deckuser}`);
  }

  deleteDeck(deckId: number | undefined) {
    return this.http.delete(`http://localhost:8080/api/v1/decks/${deckId}`);
  }

  addDeck(deckData: any) {
    return this.http.post('http://localhost:8080/api/v1/decks', deckData);
  }

  changeDeck(deckId: number, newName: string) {
    return this.http.patch(`http://localhost:8080/api/v1/decks/${deckId}`, newName);
  }
}
