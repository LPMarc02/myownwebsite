import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable} from 'rxjs';
import {User} from "../../Models/User.model";

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080/api/users';

  user: string | undefined;

  constructor(private http: HttpClient) { }

  getAllUsers() {
    const url = `${this.apiUrl}/showAllUsers`; // Passen Sie den Endpunkt entsprechend Ihrer Backend-Implementierung an
    return this.http.get<User[]>(url);
  }

  getUserByUsername(username: string | undefined): Observable<User> {
    const url = `${this.apiUrl}/getUserByUsername?username=${username}`;
    return this.http.get<User>(url);
  }

  checklogin(username: string, password: string) {
    const url = `${this.apiUrl}/checklogin`;
    return this.http.get<boolean>(url, {
      params: { username, password }
    });
  }

  generateRandomNumber():number{
    return Math.floor(Math.random()*9999);
  }

  sendEmailToUser(email: string, randomNumber: number, text:string, subject:string): Observable<any> {
    const url = `${this.apiUrl}/sendMail/`;
    const body = {
      email: email,
      randomNumber: randomNumber,
      text:text,
      subject:subject
    };
    return this.http.post<any>(url, body);
  }

  getusermail(username: string ): Observable<string> {
    const url = `${this.apiUrl}/getMail?username=${username}`;
    return this.http.get<string>(url, { responseType: 'text' as 'json' }); // Explicitly cast 'text' as 'json'
  }

  updateProfilePicture(id: number, profilePicture: string) {
    const url = `${this.apiUrl}/${id}/updateProfilePicture`;
    return this.http.put(url, profilePicture);
  }

  emptySession(){
    sessionStorage.clear();
  }

  setPlayerData(username: string){
    this.emptySession();
    sessionStorage.setItem('user', JSON.stringify(username));
    this.setUserOnline(username, "online").subscribe();
  }

  getPlayerData(): any {
    if(typeof window !== 'undefined') {
      const username = sessionStorage.getItem('user');
      return username ? JSON.parse(username) : null;
    }
  }

  getPermission(username: string | undefined){
    const url = `${this.apiUrl}/getPermission?username=${username}`;
    return this.http.get<boolean>(url);
  }

  changePassword(password: string, email:string){
    const url = `${this.apiUrl}/changePassword`;
    const body = {
      password: password,
      email: email
    }
    return this.http.put(url, body);
  }

  getUsersByUsername(username: string): Observable<User[]> {
    const url = `${this.apiUrl}/search?username=${username}`;
    return this.http.get<User[]>(url);
  }

  setUserOnline(username:string, status:string){
    const url = `${this.apiUrl}/statusSetOnline`;
    const body={
      username:username,
      status:status
    }
    return this.http.put(url,body);
  }

  updateFriendListPrivacy(userId: number | undefined, friendListPrivate: boolean): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/${userId}/privacy`, friendListPrivate);
  }

  getUserById(id: number ): Observable<User> {
    const url = `${this.apiUrl}/getUserById?id=${id}`;
    return this.http.get<User>(url);
  }
}
