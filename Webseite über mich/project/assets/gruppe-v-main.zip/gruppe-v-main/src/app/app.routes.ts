import { Routes } from '@angular/router';
import { ProfileComponent } from './profile/profile.component';
import { AdminControllerComponent } from "./admin-controller/admin-controller.component";
import {LoreComponent} from "./lore/lore.component";
import {MainmenuComponent} from "./mainmenu/mainmenu.component";
import {DeckEditorComponent} from "./deck-editor/deck-editor.component";
import {LootboxenComponent } from "./lootboxen/lootboxen.component"
import {InventoryComponent } from "./inventory/inventory.component"
import {LeaderboardComponent} from "./leaderboard/leaderboard.component";
import {CardGameComponent} from "./card-game/card-game.component";
import {DeckChoiceComponent} from "./deck-choice/deck-choice.component";
import {LobbyComponent} from "./lobby/lobby.component";
import {ClanComponent} from "./clan/clan.component";
import {TurnierComponent} from "./turnier/turnier.component";


export const routes: Routes = [
  { path: 'Profile/:username', component: ProfileComponent, title: 'Profilansicht'},
  { path: 'openlogin', component: LoreComponent, title: 'Melde dich an!' },
  { path: 'AdminController', component: AdminControllerComponent, title: 'Kartenübersicht' },
  { path: '', component: MainmenuComponent, title: 'CardClash'},
  { path: 'deck-editor', component: DeckEditorComponent, title: 'Editiere deine Decks!' },
  { path: 'lootboxen', component: LootboxenComponent, title: 'Kaufe Lootboxen!' },
  { path: 'inventory', component: InventoryComponent, title: 'Öffne Lootboxen!' },
  { path: 'app-card-game/:sessionId', component: CardGameComponent, title: 'Duell-Arena' },
  { path: 'leaderboard', component: LeaderboardComponent, title: 'Leaderboard' },
  { path: 'deck-choice', component: DeckChoiceComponent, title: 'Wähle ein Deck aus!' },
  { path: 'app-lobby', component: LobbyComponent},
  { path: 'clan', component: ClanComponent, title: 'Clanübersicht' },
  { path: 'turnier', component: TurnierComponent, title: 'aktives Turnier' },

];
