import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LootboxenComponent } from './lootboxen.component';

describe('LootboxenComponent', () => {
  let component: LootboxenComponent;
  let fixture: ComponentFixture<LootboxenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [LootboxenComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(LootboxenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
