import {Component} from '@angular/core';
import {NgClass, NgForOf, NgOptimizedImage} from "@angular/common";
import {LootboxenService} from "../Services/services/lootboxen.service";
import {UserService} from "../Services/services/user.service";
import {PlayerService} from "../Services/services/player.service";

@Component({
  selector: 'app-lootboxen',
  standalone: true,
  imports: [
    NgClass,
    NgOptimizedImage,
    NgForOf
  ],
  templateUrl: './lootboxen.component.html',
  styleUrl: './lootboxen.component.scss'
})
export class LootboxenComponent{
  popUpActive=false;
  box:string="";
  username:string|undefined;
  price:number|undefined;
  sepCoins:number|undefined;
  permission:boolean=true;

  constructor(private lootBoxenService:LootboxenService, private userService:UserService, private playerService:PlayerService) {
    this.getData();
  }

  getData(){
    this.username=this.userService.getPlayerData()
    if(this.username){
      this.userService.getPermission(this.username).subscribe({
        next: (permission: boolean) => {
          this.permission=permission;
          if(this.username&&!this.permission){
            this.playerService.getSepCoins(this.username).subscribe(coins => this.sepCoins = coins);
          }
        },
      });
    }

  }

  popUpNone(){
    this.popUpActive=false;
  }

  setPopUpActive(box:string, price:number){
    this.popUpNone();
    this.popUpActive=true;
    this.box=box;
    this.price=price;
  }

  addBox(){
    if(this.checkPrice()){
      if(this.username){
        this.lootBoxenService.addBox(this.username, this.box).subscribe();
      }
    }
    else{
      alert("Du hast nicht genug SEP Coins");
    }


  }
  checkPrice():boolean{
    if(this.price&&this.sepCoins){
      if(this.sepCoins>=this.price){
        if(this.username){
          this.playerService.updateSEP(this.username, this.price).subscribe();
        }
        window.location.reload();
        return true;
      }
    }
    return false;
  }


}
