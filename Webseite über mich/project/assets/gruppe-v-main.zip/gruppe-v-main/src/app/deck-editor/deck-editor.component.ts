import { Component } from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";
import {DeckServiceService} from "../Services/services/deck-service.service";
import {CardServiceService} from "../Services/services/card.service.service";
import {DeckCardsService} from "../Services/services/deck-cards.service";
import {UserService} from "../Services/services/user.service";
import {CardUser} from "../Models/CardUser.model";
import {LootboxenService} from "../Services/services/lootboxen.service";

interface Deck {
  id: number;
  name: string;
  cards: Card[];
  count: number;
  deckuser: string | undefined;
}
interface Card {
  id: number;
  name: string;
  rarity: string;
  attackPoints: number;
  defensePoints: number;
  description: string;
  imagePath: string;
}
@Component({
  selector: 'app-deck-editor',
  standalone: true,
  imports: [
    NgIf,
    NgForOf
  ],
  templateUrl: './deck-editor.component.html',
  styleUrl: './deck-editor.component.scss'
})
export class DeckEditorComponent {

  availableDecks: Deck[] = [];
  availableCards: Card[] = [];
  userCards: CardUser[] = [];
  availableCardsCopy:Card[]=[]

  selectedDeck: Deck | null = null;
  selectedCard: Card | null = null;



  constructor(private deckService: DeckServiceService, private cardService: CardServiceService, private deckCardsService: DeckCardsService, private userService: UserService, private lootBoxenService: LootboxenService) {
  }
  username: string=this.userService.getPlayerData();

  myDeckData: any;
  myCardData: any;
  myUserData: any;

  ngOnInit(): void {
    const input = document.getElementById('myInput') as HTMLInputElement;
    input.addEventListener('keyup', this.filterCards.bind(this));
    this.deckService.getDecks(this.username).subscribe((data) => {
      this.myDeckData = data;
      for (let deck of this.myDeckData){
        this.availableDecks.push(deck);
        this.deckCounter++;
      }
    })
    this.lootBoxenService.getCardsFromUser(this.username).subscribe((data) => {
      this.myUserData = data;
      for (let cardFromUser of this.myUserData){
        this.userCards.push(cardFromUser);
      }
      this.availableCardsPush();

    })

  }

  availableCardsPush(){
    this.availableCards=[];
    for(let card of this.userCards){
      if(card.cardId){
        this.cardService.getCard(card.cardId).subscribe((data) => {
          this.myCardData=data;
          this.availableCards.push(this.myCardData);
          this.availableCardsCopy=this.availableCards;
        })
      }
    }

  }

  selectDeck(deck: Deck) {
    this.availableCards=[]
    for(let cards of this.availableCardsCopy){
      this.availableCards.push(cards);
    }

    this.selectedDeck = deck;
    this.deckCardsService.getQuantity(this.selectedDeck.id).subscribe({
      next: (response:any) => {
        if(response != null && this.selectedDeck){
          this.selectedDeck.count = response;
        }
      },
      error: (error) => {
        console.error('Error:', error);
        // Handle error appropriately
      }
    });
    console.log("Deck id:" + this.selectedDeck.id);
    this.deckCardsService.getCardIds(this.selectedDeck.id).subscribe({
      next: (response:any) => {
        if (this.selectedDeck) {
          if (!this.selectedDeck.cards) {
            this.selectedDeck.cards = [];
          } else {
            this.selectedDeck.cards = [];
          }
        }
        for (let card of response){
          console.log("Card: " + card);
          console.log("Available Card id: " + this.availableCards[0].id);
          if (card != null && this.selectedDeck && this.availableCards.length > 0) {
            // Check if the card id matches with any available card id
            const matchingCard = this.availableCards.find(availableCard => availableCard.id === card);
            if (matchingCard) {
              // Push the matching card into the selected deck's cards array
              this.selectedDeck.cards.push(matchingCard);
            }
          }
        }
        if(this.selectedDeck&&this.selectedDeck.cards){
          for(let i = 0; i < this.selectedDeck.cards.length; i++){
            let j:number=0;
            while(j!=this.availableCards.length){
              if(this.availableCards[j].id==this.selectedDeck.cards[i].id&&this.selectedDeck.cards){
                this.availableCards.splice(this.availableCards.indexOf(this.availableCards[j]),1)

                break;
              }
              j++;
            }
          }
        }
      },
      error: (error) => {
        console.error('Error:', error);
        // Handle error appropriately
      }
    });
  }

  deselectDeck() {
    this.selectedDeck = null;
  }

  onMouseEnter(card: Card) {
    this.selectCard(card)
  }

  selectCard(card: Card) {
    this.selectedCard = card;
    const element = document.getElementById("h3");
    if (element && this.selectedCard) {
      element.textContent = this.selectedCard.name;
    }

  }


  deselectCard() {
    this.selectedCard = null;
  }

  deckCounter = 0;
  cardCounter = 0;

  addDeck() {
    if (this.deckCounter == 3) {
      alert("You cannot have more than 3 decks!");
      return;
    }

    let deckName = prompt("Enter deck name:", "New Deck");
    if (deckName === null) {
      return; // User cancelled
    } else if (deckName.trim() === "") {
      deckName = "New Deck";
    }

    const deckData = {
      name: deckName,
      cards: [],
      count: 0,
      deckuser: this.username
    };

    if (this.username && typeof this.username === 'string') {
      this.deckService.addDeck(deckData).subscribe({
        next: (response: any) => {
          console.log('Deck added successfully. Deck ID:', response);
          // Update the card counter and available decks array
          this.deckCounter++;
          this.availableDecks.push({
            id: response.id,
            name: response.name,
            cards: [],
            count: response.count,
            deckuser: this.username
          });
        },
        error: (error) => {
          console.error('Error adding deck:', error);
          // Handle error appropriately
        }
      });

    }
  }

  deleteDeck(deckId: number | undefined) {
    this.deckService.deleteDeck(deckId).subscribe({
      next: () => {
        this.deckCounter--;
        this.availableDecks.splice(this.availableDecks.findIndex(deck => deck.id === deckId), 1);
        this.deselectDeck();
        // Handle any further actions after deletion
      },
      error: (error) => {
        console.error('Error deleting deck with id: ' + deckId + ':', error);
        // Handle error appropriately
      }
    });
  }

  changeDeck() {
    const newName = prompt("Enter new deck name:", "New Deck");
    if (newName !== null && typeof newName === "string" && this.selectedDeck) {
      this.deckService.changeDeck(this.selectedDeck.id, newName).subscribe({
        next: (response: any) => {
          console.log('Deck name updated successfully', response);
          if (this.selectedDeck !== null && this.selectedDeck !== undefined) {
            this.selectedDeck.name = newName;
          }
        },
        error: (error) => {
          console.error('Error adding deck:', error);
        }
      });
    }
  }

  addCardToDeck(card: Card) {
    if (this.selectedDeck) {
      if (this.selectedDeck.count >= 30) {
        alert("You cannot have more than 30 Cards in your deck!");
        return; // Exit the function if the count is already 30 or more
      }

      const counter = ++this.selectedDeck.count; // Pre-increment here
      this.selectedDeck?.cards?.push(card);
      const card1:Card|undefined=this.availableCards.find(availableCard => availableCard.id === card.id);
      if (card1) {
        this.availableCards.splice(this.availableCards.indexOf(card1), 1);
      }

      this.deckCardsService.addCardToDeck(this.selectedDeck.id,card.id).subscribe({
        next: (response: any) => {
          console.log('Deck name updated successfully', response);
        },
        error: (error: any) => {
          console.error('Error adding deck:', error);
        }
      });


      if (typeof counter === "number" && !isNaN(counter)) {
        this.selectedDeck.count = counter;
      }
    }
  }

  removeCardFromDeck(card: Card) {
    // send card id to be removed with deck id.
    // go through database with deck and card id
    // delete entry if quantity is 1, do quantity -1 if quantity is greater than 1.
    if (this.selectedDeck && card) {
      this.deckCardsService.deleteCard(this.selectedDeck.id, card.id).subscribe({
        next: (response: any) => {
          console.log('Card deleted successfully', response);
        },
        error: (error: any) => {
          console.error('Error deleting card:', error);
        }
      });
      this.selectedDeck?.cards?.splice(this.selectedDeck?.cards.indexOf(card), 1);
      this.availableCards.push(card);
      this.selectedDeck.count--;
    }
  }


  filterCards() {
    // Declare variables
    let input = document.getElementById('myInput') as HTMLInputElement;
    let filter = input?.value.toUpperCase();
    let ul = document.querySelector("#myUL");
    let li = ul?.getElementsByTagName('li');

    if (li) {
      for (let i = 0; i < li.length; i++) {
        let txtValue = li[i].textContent || li[i].innerText; // Get text content directly from li
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          li[i].style.display = "";
        } else {
          li[i].style.display = "none";
        }
      }
    }
  }
}
