import { Component } from '@angular/core';
import { UserService } from '../Services/services/user.service';
import { CommonModule } from '@angular/common'; // Import CommonModule
import { FormsModule } from '@angular/forms';
import {DuellRequestService} from "../Services/services/duell-request.service";
import {PlayerService} from "../Services/services/player.service";
import {Player} from "../Models/Player.model";

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  standalone: true,
  styleUrls: ['./leaderboard.component.scss'],
  imports: [CommonModule, FormsModule] // Füge CommonModule zu den Imports hinzu
})
export class LeaderboardComponent {
  player: Player[] = [];
  myData:any;
  searchTerm: string = '';
  constructor(private userService: UserService, private duellRequestService: DuellRequestService, private playerService:PlayerService){
    this.loadLeaderboard();
    console.log(this.player);
  }

  loadLeaderboard() {
    this.player=[];
    this.playerService.getLeaderBoard1().subscribe((data) => {
      this.myData=data;
      for (let user of this.myData){
        this.player.push(user);
      }
      for(let player of this.player){
        for(let player2 of this.player){
          if(player.leaderboard>=player2.leaderboard){
            break;
          }
        }
      }
      this.player.sort((a, b) => b.leaderboard-a.leaderboard);
    });

  }

  searchUser() {

    if (this.searchTerm.trim()) {
      this.playerService.searchUsers(this.searchTerm).subscribe((data: any[]) => {
        this.player = data;
      });
    } else {

      // Update leaderboard or user status based on real-time messages
      // Wenn kein Suchbegriff vorhanden ist, lade das Leaderboard erneut
      this.loadLeaderboard();
    }
  }

  duellRequest(username: string){
    this.duellRequestService.sendRequest(username);
  }
}
