import { Component, HostBinding, computed, effect, signal } from '@angular/core';
import { ChatService } from './chat.service';
import { FormsModule } from '@angular/forms';
import { UserService } from '../Services/services/user.service';
import { log } from 'console';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { ChatInstance, ChatMessage } from '../Models/Chat.model';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.scss',
})
export class ChatComponent {
  @HostBinding('style.width')
  hostWidth = '30px';

  public _allUserNames: string[] = [];

  public _selectedUserNames: string[] = [];

  public chatInstances;

  public selectedChatInstance;

  public messageIdInEditMode: number = -1;

  public selectChatInstanceIndex = signal(0);

  _myMessage: string = '';

  constructor(
    private chatService: ChatService,
    private userService: UserService
  ) {
    userService.getAllUsers().subscribe((user) => {
      this._allUserNames = user.map((u) => u.username);
      console.log(this._allUserNames);
    });

    this.chatInstances = computed(() => {
      return chatService.getStore()().chats;
    });

    this.selectedChatInstance = computed(() => {
      return this.chatInstances()?.[this.selectChatInstanceIndex()] ?? null;
    });

    effect(() => {
      const seenByOthers = this.selectedChatInstance()
        .chatMessages.filter((message) => {
          return message.owner.username !== chatService.getUsername();
        })
        .filter((message) => {
          return !message.seenByOthers;
        })
        .map((message) => {
          return message.id;
        });

      if (seenByOthers.length > 0) {
        this.chatService.markSeemByOther(seenByOthers);
      }
    });
  }

  expandChat() {
    this.hostWidth = '400px';
  }

  miniChat() {
    console.log("sasasas");

    this.hostWidth = '30px';
  }

  editMessage(_t10: ChatMessage) {
    throw new Error('Method not implemented.');
  }

  deleteMessage(message: ChatMessage) {
    this.chatService.deleteMessage(message.id);
  }

  getUsername() {
    return this.chatService.getUsername();
  }

  sendMessage() {
    this.chatService.sendMessage(
      this._myMessage,
      this.selectedChatInstance().id
    );
  }

  createChat() {
    console.log(this._selectedUserNames);
    this.chatService.createNewChat(false, this._selectedUserNames);
  }

  enterThisChat(index: number) {
    this.selectChatInstanceIndex.set(index);
  }
}
