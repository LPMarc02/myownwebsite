import { Injectable, signal } from '@angular/core';
import { timeStamp } from 'console';
import { UserService } from '../Services/services/user.service';
import { userInfo } from 'os';
import { ignoreElements } from 'rxjs';
import {
  ChatInstance,
  ChatInstanceCreation,
  ChatMessage,
  ChatMessageCreation,
  ChatStore,
  SimpleWebSocketMessage,
  isSimpleWebSocketMessage,
} from '../Models/Chat.model';

@Injectable({
  providedIn: 'root',
})
export class ChatService {
  private messageTypes = {
    INIT_CHATS: 'INIT_CHATS',
    CREATE_CHAT: 'CREATE_CHAT',
    MESSAGE: 'MESSAGE',
    MESSAGES_SEEN: 'MESSAGES_SEEN',
    DELETE_MESSAGE: 'DELETE_MESSAGE',
  };

  private webSocket!: WebSocket;

  private chatData = signal<ChatStore>({
    chats: [],
  });

  constructor(private userSerivce: UserService) {
    if (typeof window !== 'undefined') {
      // browser code

      this.webSocket = new window.WebSocket('ws://localhost:8080/api/chat');
      // console.log(this.webSocket);

      this.webSocket.onerror = (e) => {
        // console.log(e.message);
      };

      this.webSocket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (isSimpleWebSocketMessage(data)) {
          if (data.messageType === this.messageTypes.INIT_CHATS) {
            const chatIntances = data.payload as ChatInstance[];
            console.log(chatIntances);

            this.chatData.update((store) => ({
              ...store,
              chats: chatIntances,
            }));
          }
        } else {
          throw new Error('Unsupported Message');
        }
      };

      this.webSocket.onopen = () => {
        this.initChat();
      };
    }
  }

  initChat() {
    const message: SimpleWebSocketMessage = {
      username: this.getUsername(),
      messageType: this.messageTypes.INIT_CHATS,
      payload: {},
    };

    this.webSocket.send(JSON.stringify(message));
  }

  getStore() {
    return this.chatData.asReadonly();
  }

  createNewChat(isPrivate: boolean, usernames: string[]) {
    const payload: ChatInstanceCreation = {
      creator: this.getUsername(),
      isPrivate: isPrivate,
      entitledUsers: usernames,
    };

    const message: SimpleWebSocketMessage = {
      username: this.getUsername(),
      messageType: this.messageTypes.CREATE_CHAT,
      payload: payload,
    };

    this.webSocket.send(JSON.stringify(message));
  }

  getUsername() {
    return this.userSerivce.getPlayerData() as string;
  }

  markSeemByOther(seenByOthers: number[]) {
    const message: SimpleWebSocketMessage = {
      username: this.getUsername(),
      messageType: this.messageTypes.MESSAGES_SEEN,
      payload: seenByOthers,
    };

    this.webSocket.send(JSON.stringify(message));
  }

  deleteMessage(id: number) {
        const message: SimpleWebSocketMessage = {
          username: this.getUsername(),
          messageType: this.messageTypes.DELETE_MESSAGE,
          payload: [id],
        };

        this.webSocket.send(JSON.stringify(message));
  }

  sendMessage(msg: string, chatInsId: number) {
    if (this.webSocket.OPEN) {
      const payload: ChatMessageCreation = {
        creator: this.getUsername(),
        chatInstanceId: chatInsId,
        message: msg,
      };

      const message: SimpleWebSocketMessage = {
        username: this.getUsername(),
        messageType: this.messageTypes.MESSAGE,
        payload: payload,
      };

      this.webSocket.send(JSON.stringify(message));
    }
  }
}
