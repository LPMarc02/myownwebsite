import {Card} from "./Card.model";

export interface Deck {
  id: number;
  name: string;
  cards: Card[];
  count: number;
}
