export interface CardUser {
  id?: number;
  name: string;
  cardId: number;
}
