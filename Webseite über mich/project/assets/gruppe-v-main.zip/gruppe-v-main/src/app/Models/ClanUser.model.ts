export interface ClanUser {
  id?: number;
  username: string;
  clanname: string;
  bet?: string;
  requestAccepted?: number;
}
