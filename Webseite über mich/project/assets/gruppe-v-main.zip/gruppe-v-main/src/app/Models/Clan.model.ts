export interface Clan{
  id?: number;
  clanname: string;
  request: string;
}
