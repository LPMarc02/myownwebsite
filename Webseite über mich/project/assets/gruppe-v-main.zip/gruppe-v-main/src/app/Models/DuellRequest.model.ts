export interface DuellRequest {
  id?: string;
  sender: string;
  receiver: string;
  status?: string;
  gameMode?:number;
}
