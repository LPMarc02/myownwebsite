export interface Tournament{
  id?:number;
  clanName:string;
  username1:string;
  username2:string;
  winner?:string;
}
