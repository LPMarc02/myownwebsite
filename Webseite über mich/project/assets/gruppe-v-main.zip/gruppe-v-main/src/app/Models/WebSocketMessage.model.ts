import {Card} from "./Card.model";
import {Deck} from "./Deck.model";
import {DuellRequest} from "./DuellRequest.model";

export interface WebSocketMessage {
  type: string;
  data: any;
  id?: string;
}

