import {Deck} from "./Deck.model";

export type navigationStateModel = {
  sessionId: string;
  playerRole: string;
  deckChoice: Deck;
  gameMode: number;
};
