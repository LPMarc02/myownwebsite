export interface Friendship {
     id?:number;
   friendName:string;
   userId : number ;// Benutzer-ID
   friendId: number;
}
