export interface Admin {
  id?: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  birthDate: string;
  password: string;
  profilePicture: string;
  friendListPrivate: boolean;


}
