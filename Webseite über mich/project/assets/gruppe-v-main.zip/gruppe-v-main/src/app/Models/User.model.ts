export interface User {
  id?: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  birthDate: string;
  password: string;
  profilePicture: string;
  friendListPrivate: boolean;
}


// private Long id;
//   private String username;
//   private String firstName;
//   private String lastName;
//   private String email;
//   private String birthDate;
//   private Long password;
