export interface LootBoxen {
  id?: number;
  username:string;
  box:string;
}
