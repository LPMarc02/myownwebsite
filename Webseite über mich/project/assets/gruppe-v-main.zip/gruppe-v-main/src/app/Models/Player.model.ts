export interface Player {
  id?: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
  birthDate: string;
  password: string;
  sepCoins: number;
  profilePicture: string;
  leaderboard: number;
  permission: string;
  status:string;
}
