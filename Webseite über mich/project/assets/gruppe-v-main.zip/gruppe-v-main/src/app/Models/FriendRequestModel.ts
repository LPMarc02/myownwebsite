export interface FriendRequest {

  id?: number; // Optional, da die ID normalerweise vom Server generiert wird
  username:string;
  senderId: number | undefined;
  receiverId: number |undefined;
  status: string; // Status der Freundesanfrage (z. B. PENDING, ACCEPTED, REJECTED)
}
