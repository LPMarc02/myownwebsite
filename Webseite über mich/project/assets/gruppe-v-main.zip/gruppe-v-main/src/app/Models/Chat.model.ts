import { User } from "./User.model";

export interface SimpleWebSocketMessage {
  username: string,
  messageType: string,
  payload: {[key: string]: any}
}

export interface ChatStore {
  chats: ChatInstance[]
}


export function isSimpleWebSocketMessage(value: any): value is SimpleWebSocketMessage {

  if ('messageType' in value) {
  return true;
  }
  return false;

}

export interface ChatInstanceCreation {
  isPrivate: boolean;
  creator: string;
  entitledUsers: string[];
};


export interface ChatMessageCreation {
  creator: string;
  message: string;
  chatInstanceId: number;
};


export interface ChatInstance {
  id: number;
  isPrivate: boolean;
  creator: User;
  entitledUsers: User[];
  chatMessages: ChatMessage[];
};

export interface ChatMessage {
  id: number;
  message: string;
  seenByOthers: boolean;
  owner: User;
  timestamp: string; // ISO string format for Instant
  chatInstance: ChatInstance;
};
