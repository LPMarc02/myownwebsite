export interface Card {
  id?: number;
  name: string;
  rarity: string;
  attackPoints: number;
  defensePoints: number;
  description: string;
  imagePath: string;
}
