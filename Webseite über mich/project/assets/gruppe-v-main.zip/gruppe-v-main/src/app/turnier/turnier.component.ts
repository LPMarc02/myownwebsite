import {Component, OnInit} from '@angular/core';
import {FormsModule} from "@angular/forms";
import {NgForOf, NgIf} from "@angular/common";
import {UserService} from "../Services/services/user.service";
import {ClanUser} from "../Models/ClanUser.model";
import {ClanService} from "../Services/services/clan.service";
import {Clan} from "../Models/Clan.model";
import {Tournament} from "../Models/Tournament.model";
import {TournamentService} from "../Services/services/tournament.service";
import {PlayerService} from "../Services/services/player.service";
import {Player} from "../Models/Player.model";
import {DuellRequestService} from "../Services/services/duell-request.service";
import {LootboxenService} from "../Services/services/lootboxen.service";

@Component({
  selector: 'app-turnier',
  standalone: true,
  imports: [
    FormsModule,
    NgForOf,
    NgIf
  ],
  templateUrl: './turnier.component.html',
  styleUrl: './turnier.component.scss'
})
export class TurnierComponent implements OnInit{
  //Marc Prüfer
  player: Player[] = [];
  searchTerm: string = '';
  startTournament: boolean=false;
  round: Tournament[]=[];
  playerInTournament: ClanUser[]=[];
  anzWinner: number=0;
  winner: string="";
  finished: boolean= false;

  //Nils Wenzel
  allClanUser?: ClanUser[];
  signedUser?: string;
  signedClanUser?: ClanUser;
  signedSepCoins?: number;
  userClan?: Clan;

  constructor(private userService: UserService, private clanService: ClanService, private tournamentService:TournamentService, private playerService: PlayerService, private requestService: DuellRequestService, private lootBoxenService:LootboxenService) {
    this.signedUser = this.userService.getPlayerData();
  }

  ngOnInit() {
    //search user clan
    this.clanService.getClanByUsername(this.signedUser)
      .subscribe(clan => {
        this.userClan = clan;
        if(clan.request=="started"){
          this.startTournament=true;
        }

        if(this.userClan){
          this.clanService.getClansByClanname(this.userClan.clanname)
            .subscribe(clanUsers => {
              this.allClanUser = clanUsers;
              for(let clanUser of this.allClanUser){
                this.playerService.getUserByUsername(clanUser.username)
                  .subscribe(player => {
                    this.player.push(player);
                  })
              }
              for(let clanUser of this.allClanUser!){
                if(clanUser.requestAccepted==1){
                  this.playerInTournament.push(clanUser);
                }
              }
              this.tournamentService.getMatch(this.userClan?.clanname!)
                .subscribe(tournament => {
                  console.log(this.playerInTournament);
                  this.round=tournament;
                  this.generateRound();
                  this.checkTournament();
                })
            })
        }
      });

    //search clan user
    this.searchClanUser();

    //get sep-coins
    this.getSepCoins();
  }


//Marc Prüfer
  generateRound(){
    this.shuffleArray();
    for(let game of this.round){
      if(game.winner){
        this.anzWinner+=1;
      }
    }
    if((this.round.length==0||this.anzWinner==this.round.length)&&(this.userClan!.request=="started")){
      console.log(this.playerInTournament);
      for(let i=0;i<=this.playerInTournament.length;i+=2){
        if(this.playerInTournament[i+1]){
          const username1:string=this.playerInTournament[i].username;
          const username2:string=this.playerInTournament[i+1].username;
          const clanName:string=this.userClan!.clanname;
          const game:Tournament= new class implements Tournament {
            clanName: string = clanName;
            username1: string = username1;
            username2: string =username2;
          }
          this.round.push(game);
          this.tournamentService.setMatch(this.userClan!.clanname, this.playerInTournament[i].username, this.playerInTournament[i+1].username).subscribe();
        }
      }
    }
  }

  shuffleArray(){
    this.playerInTournament.sort(() => Math.random() - 0.5);
    console.log(this.playerInTournament);
  }

  checkTournament(){
    //Es muss mindestens ein Finale stattgefunden haben, damit ein Spieler gewinnt
    if(this.playerInTournament.length==1&&this.round.length>=1){
      this.winner=this.playerInTournament[0].username;
      this.finished=true;
    }
  }

  clearTournament(){
    this.tournamentService.getMatch(this.userClan?.clanname!)
      .subscribe(tournament => {
        if(tournament.length>0){
          this.playerService.updateSEP(this.winner, -700).subscribe();
          this.lootBoxenService.addBox(this.winner, "pokal").subscribe();
          this.clanService.setRequestNull(this.winner)
            .subscribe(() => {
              this.clanService.setRequest('finished',this.userClan!)
                .subscribe(() => {
                  this.tournamentService.deleteAll(this.userClan?.clanname!)
                    .subscribe(() => {
                      this.resolveBet();
                      window.location.reload();
                    })
                })
            })
        }
        else{
          window.location.reload();
        }
      })
  }

  duellRequest(username1: string, username2: string){
    if(username1==this.signedUser){
      this.requestService.sendRequest2(username2);
    }
    if(username2==this.signedUser){
      this.requestService.sendRequest2(username1);
    }
  }

//Nils Wenzel
  //Konstruktormethoden
  searchClanUser(){
    this.clanService.getUserClanByUsername(this.signedUser)
      .subscribe(clanUser => {
        this.signedClanUser = clanUser;
      })
  }

  getSepCoins(){
    this.playerService.getSepCoins(this.signedUser)
      .subscribe(sepCoins => this.signedSepCoins = sepCoins)
  }

  //Sonstige Methoden
  bet(username: string){
    if (this.signedSepCoins && this.signedSepCoins >= 50){
      if (this.signedUser){
        this.clanService.setBet(this.signedUser, username).subscribe();
        this.playerService.updateSEP(this.signedUser, 50)
          .subscribe(()=>window.location.reload());
      }
    }else{
      alert("Du hast nicht genügend SEP-Coins um zu wetten! Eine Wette kostet 50SEP-Soins.")
    }
  }

  resolveBet(){
    this.clanService.resolveBet(this.winner).subscribe();
  }
}
