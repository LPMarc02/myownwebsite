import { Component, OnInit } from '@angular/core';
import {NgForOf, NgIf} from "@angular/common";
import {FooterComponent} from "../footer/footer.component";
import {Card} from "../Models/Card.model";
import {CardServiceService} from "../Services/services/card.service.service";
import {UserService} from "../Services/services/user.service";

@Component({
  selector: 'app-admin-controller',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
    FooterComponent
  ],
  templateUrl: './admin-controller.component.html',
  styleUrl: './admin-controller.component.scss'
})
export class AdminControllerComponent implements OnInit{
  constructor(private cardService: CardServiceService, private userService: UserService) {}
  listCards: Card[] = [];
  selectedCards: Card[] = [];
  newCards: Card[] = [];
  countCards: number = 0;
  permission: boolean = false;
  text: string = '*Inhaltsnachweis: Bilder mit KI erstellt.';
  myCardData: any;
  file: any;
  username: string | undefined;

  ngOnInit(){
    this.getData();
  }

  getData(){
    this.cardService.getCards().subscribe((data:any) => {
      this.myCardData = data;
      for (let card of this.myCardData){
        this.listCards.push(card);
      }
    })
    this.username = this.userService.getPlayerData()
    this.userService.getPermission(this.username).subscribe(
      permission => this.permission = permission
    )
  }

  triggerFileUpload(): void{
    const fileInput = document.getElementById('csvFileInput') as HTMLInputElement;
    this.newCards = [];
    fileInput.click();
  }

  onFileSelect(event: Event): void{
    // @ts-ignore
    const file = (event.target as HTMLInputElement).files[0];
    if(file){
      const reader = new FileReader();
      reader.onload = (e) => {
        const csvContent = e.target?.result as string;
        const lines = csvContent.split('\n');
        for (const line of lines) {
          const [name, rarity, attackPoints, defensePoints, description, imagePath] = line.split(';');
          const card: Card = {
            name,
            rarity,
            attackPoints: +attackPoints,
            defensePoints: +defensePoints,
            description,
            imagePath
          };
          this.newCards.push(card);
        }
        console.log('Neue Karten:', this.newCards);
        this.uploadCards();
      };
      reader.readAsText(file);
    }
  }

  uploadCards() {
    console.log('Upload Cards');
    for (let card of this.newCards){
      this.cardService.addCard(card).subscribe(() => this.reloadPage());
    }
    // alert('Karten wurden hochgeladen!')
  }

  deleteCards() {
    for (let card of this.selectedCards){
      this.cardService.deleteCard(card.id).subscribe(() => this.reloadPage());
    }
    this.selectedCards = [];
  }

  selectCard(card:Card) {
    this.selectedCards.push(card);
    this.countCards++;
  }

  deselectCard(card: Card) {
    this.selectedCards.splice(this.selectedCards.indexOf(card), 1);
    this.countCards--;
  }

  isInSelected(card: Card): boolean{
    return this.selectedCards.some(selectedCard => selectedCard.name === card.name);
  }

  //Methode aus der Backend-Lösung von Moodle
  private reloadPage() {
    window.location.reload();
  }

}
