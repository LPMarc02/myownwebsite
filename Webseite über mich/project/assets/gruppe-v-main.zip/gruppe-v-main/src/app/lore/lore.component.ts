import {Component, ViewChild, ElementRef, OnInit, model} from '@angular/core';
import {NgClass} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {Router, RouterLink} from "@angular/router";
import {PlayerService} from "../Services/services/player.service";
import {Player} from "../Models/Player.model";
import {UserService} from "../Services/services/user.service";
import {MainmenuComponent} from "../mainmenu/mainmenu.component";

@Component({
  selector: 'app-lore',
  standalone: true,
  imports: [
    NgClass,
    FormsModule,
    RouterLink,
    MainmenuComponent,

  ],
  templateUrl: './lore.component.html',
  styleUrl: './lore.component.scss'
})
export class LoreComponent implements OnInit {

  @ViewChild('wrapper', { static: true }) wrapper!: ElementRef;


  player: Player = {
    profilePicture: "img0", sepCoins: 500, birthDate: "", email: "", firstName: "", lastName: "", password: "", username: "", leaderboard:0, permission:"false", status:"offline"};
  constructor(private playerService:PlayerService, private userService:UserService, private router: Router) {}
  username: string="";
  password: string="";


  ngOnInit(): void {
    const loginLink: HTMLElement | null = document.querySelector('.login-link');
    const registerLink: HTMLElement | null = document.querySelector('.register-link');
    if (registerLink) {
      registerLink.addEventListener('click', () => {
        if (this.wrapper) {
          this.wrapper.nativeElement.classList.add('active');
        }
      });
    }

    if (loginLink) {
      loginLink.addEventListener('click', () => {
        if (this.wrapper) {
          this.wrapper.nativeElement.classList.remove('active');
        }
      });
    }
  }

  openRegister(): void {
    const wrapper = this.wrapper.nativeElement.querySelector('.wrapper');
    if (wrapper) {
      wrapper.style.display = 'flex';
    }
  }

  openLogin(): void {
    const wrapperElement: HTMLElement | null = document.querySelector('.wrapper');
    if (wrapperElement) {
      wrapperElement.style.display = 'flex';
    }
  }
  closeLogin(): void {
    const wrapperElement: HTMLElement | null = document.querySelector('.wrapper');
    if (wrapperElement) {
      wrapperElement.style.display = 'none';
    }
  }
  submit(){
    console.log("Submitted player data:", this.player);
    this.playerService.addPlayer(this.player).subscribe({
      next: (response: any) => {
        alert("Registrierung erfolgreich");
        console.log('Add player successfully', response);
      },
      error: (error) => {
        alert("Registrierung fehlgeschlagen. Prüfe, ob alle Eingaben korrekt sind. Alle Felder müssen ausgefüllt werden und deine E-Mail-Adresse muss ein '@' und einen Punkt ' . ' enthalten. Wenn alle Eingaben korrekt sind, sind Benutzername oder E-Mail bereits vergeben");
        console.error('Error Add Player:', error);
      }
    });
  }

  login(): void {
    const text2FA:string="Hallo "+this.username+". Ihr Sicherheitscode: ";
    const subject2FA:string="Zwei-Faktor-Authentifizierungscode";
    const randomNumber = this.userService.generateRandomNumber();
    this.userService.checklogin(this.username, this.password).subscribe({
      next: (response: any) => {
        if (response) {
          this.userService.getusermail(this.username).subscribe({
            next: (response: any) => {
              const email = response.toString();
              console.log(email);
              this.userService.sendEmailToUser(email, randomNumber, text2FA,subject2FA).subscribe({
                next: (emailResponse: any) => {
                  console.log("Wurde gesendet");
                  this.ZweiFA(randomNumber);
                  },
                  error: (emailError: any) => {
                    alert("Email Error");
                  }
                });
              },
              error: (error) => {
                console.log(error);
              }
          })

        } else {
          alert("Anmeldung fehlgeschlagen");
          console.error("Anmeldung fehlgeschlagen");
        }
    },
    error:(error:any)=>{
        console.error("Fehler bei der Anmeldung",error);
    }
    })
  }

  ZweiFA(randomNumber:number):void{
    const userInput = prompt("Ihre Bestätigungsemail mit dem Code wurde zugesendet. Ihre Eingabe: ");
    if (userInput !== null) {
      const number = parseInt(userInput);
      if (!isNaN(number)) {
        // Die Eingabe ist eine gültige Zahl
        console.log("Die eingegebene Zahl ist:", number);
        if(number==9999){
          alert("Anmeldung erfolgreich");
          this.userService.setPlayerData(this.username);
          console.log("Anmeldung erfolgreich");

          //Weiterleitung Hauptmenü
          this.mainmenu()
        }
        else if(number==randomNumber){
          alert("Anmeldung erfolgreich");
          this.userService.setPlayerData(this.username);
          console.log("Anmeldung erfolgreich");

          //Weiterleitung Hauptmenü
          this.mainmenu()
        }
        else{
          alert("Anmeldung fehlgeschlagen");
        }
      } else {
        // Die Eingabe ist keine Zahl
        console.error("Ungültige Eingabe: Keine Zahl eingegeben.");
        alert("Anmeldung fehlgeschlagen");
      }
    } else {
      // Der Benutzer hat auf "Abbrechen" geklickt oder das Popup geschlossen
      console.log("Der Benutzer hat den Vorgang abgebrochen oder das Popup geschlossen.");
    }


  }

  mainmenu(){
    this.router.navigate(["/"]).then(r => this.reloadPage())
  }

  private reloadPage() {
    window.location.reload()
  }

  forgotPassword():void{
    const textchangePSW:string="Hallo. Ihr Sicherheitscode für die Passwortänderung: ";
    const subjectchangePSW:string="Bestätigung für die Änderung Passwort";
    const randomNumber = this.userService.generateRandomNumber();
    const userInputEmail = prompt("Ihre E-Mail zur Bestätigung für die Passwortänderung: ");

    if(userInputEmail){
      this.userService.sendEmailToUser(userInputEmail, randomNumber, textchangePSW,subjectchangePSW).subscribe({
        next: (emailResponse: any) => {
          console.log("Wurde gesendet");
          const userInput = prompt("Ihr Code zur Bestätigung für die Passwortänderung: ");
          if(userInput!==null){
            const number:number=parseInt(userInput);
            if(!isNaN(number)){
              console.log("Die eingegebene Zahl ist:", number);
              if(number==9999) {
                alert("E-Mail eestätigt");
                console.log("Bestätigung erfolgreich");
                const newPasswordInput = prompt("Ihr neues Passwort: ");
                if (newPasswordInput) {
                  console.log(newPasswordInput);
                  this.userService.changePassword(newPasswordInput, userInputEmail).subscribe({
                    next: (response: any) => {
                      alert("Änderung erfolgreich");
                    },
                    error: (error:any) => {
                      console.error("Email Error" +error);
                      alert("Änderung fehlgeschlagen");
                    }
                  });
                }
              }
              else if(number==randomNumber){
                alert("E-Mail bestätigt");
                console.log("Bestätigung Erfolgreich");
                const newPasswordInput = prompt("Ihr neues Passwort: ");
                if(newPasswordInput){
                  this.userService.changePassword(newPasswordInput, userInputEmail).subscribe({
                    next: (response: any) => {
                      alert("Änderung erfolgreich");
                    },
                    error: (error:any) => {
                      console.error("Email Error" +error);
                      alert("Änderung fehlgeschlagen");
                    }
                  });
                }
              }
              else{
                console.error("Falsche Eingabe");
              }

            }
            else {
              console.error("Ungültige Eingabe: Keine Zahl eingegeben.");
              alert("Anmeldung fehlgeschlagen");
            }
          }

        },
        error: (emailError: any) => {
          alert("Email Error");
        }
      });
    }
  }

  protected readonly model = model;
}
