import {Component, OnInit} from '@angular/core';
import {Router, RouterLink} from "@angular/router";
import {UserService} from "../Services/services/user.service";
import {User} from "../Models/User.model";
import {LeaderboardComponent} from "../leaderboard/leaderboard.component";

@Component({
  selector: 'app-mainmenu',
  standalone: true,
  imports: [
    RouterLink,
    LeaderboardComponent
  ],
  templateUrl: './mainmenu.component.html',
  styleUrl: './mainmenu.component.scss'
})
export class MainmenuComponent implements OnInit{

  sessionId: string | undefined = undefined;

  spielen(){
    alert('Du bist im Spiel drin...');
  }

  deckBauen(){
    alert('Du bist im Deckbau...');
  }

  itemShop(){
    alert( 'Du bist im Itemshop...');
  }

  constructor(private userService: UserService, private router: Router) {}

  selectedUser: User ={
    birthDate: "", email: "", firstName: "unknown", lastName: "user", password: "", profilePicture: "img0", username: "unknown_user",friendListPrivate:false
  };
  username: string | undefined = 'Error';

  ngOnInit(){
    this.getData();
  }

  getData(){
    this.username = this.userService.getPlayerData()
    if (this.username != undefined) {
      this.userService.getUserByUsername(this.username)
        .subscribe(user => this.selectedUser = user)
    }
  }

  playComputer(): void {
    this.router.navigate(['/deck-choice'], {state : {
      playerRole: "Player 1",
      gameMode: 2
    }});
  }

}
