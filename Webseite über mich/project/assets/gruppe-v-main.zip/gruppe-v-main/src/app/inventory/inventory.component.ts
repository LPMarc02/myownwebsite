import {Component} from '@angular/core';
import {LootboxenService} from "../Services/services/lootboxen.service";
import {Card} from "../Models/Card.model";
import {LootBoxen} from "../Models/Lootboxen.model";
import {NgForOf} from "@angular/common";
import {UserService} from "../Services/services/user.service";
import {CardServiceService} from "../Services/services/card.service.service";

@Component({
  selector: 'app-inventory',
  standalone: true,
  imports: [
    NgForOf
  ],
  templateUrl: './inventory.component.html',
  styleUrl: './inventory.component.scss'
})
export class InventoryComponent{
  constructor(private lootBoxenService:LootboxenService, private userService:UserService, private cardService:CardServiceService) {
    this.getData();
  }

  listLootBoxen:LootBoxen[]=[];
  myLootBoxenData: any;
  username:string|undefined;
  popUpActive=false;
  box:string="";
  openChestActive:boolean=false;
  listCards: Card[] = [];
  listCardsSelten: Card[] = [];
  listCardsLegendear: Card[] = [];
  listCardsNormal: Card[] = [];
  listCardsLoot: Card[] = []
  myCardData:any;
  lootBox:LootBoxen|undefined;

  getData(){
    this.username=this.userService.getPlayerData();
    if(this.username){
      this.lootBoxenService.getLootBoxen(this.username).subscribe((data:any) => {
        this.myLootBoxenData = data;
        for (let lootBox of this.myLootBoxenData){
          this.listLootBoxen.push(lootBox);
        }
        this.cardService.getCards().subscribe((data:any) => {
          this.myCardData = data;
          for (let card of this.myCardData){
            this.listCards.push(card);
          }
          this.sortCards();
        })
      })
    }
  }
  toggleBox(boxNumber: string | undefined) {
    switch (boxNumber) {
      case "bronzeBox":
        this.openBronzeChest();
        break;
      case "silverBox":
        this.openSilverChest();
        break;
      case "goldBox":
        this.openGoldChest();
        break;
    }
  }

  popUpNone(){
    this.popUpActive=false;
  }

  setPopUpActive(box:string, lootBox:LootBoxen){
    this.popUpNone();
    this.popUpActive=true;
    this.box=box;
    this.lootBox=lootBox;
  }

  sortCards(){
    for(let card of this.listCards){
      if(card.rarity=="Normal"){
        this.listCardsNormal.push(card);
      }
      if(card.rarity=="Selten"){
        this.listCardsSelten.push(card);
      }
      if(card.rarity=="Legendär"){
        this.listCardsLegendear.push(card);
      }
    }
  }
  openBronzeChest(){
    for(let i=0;i<5;i++){
      const number:number= Math.floor(Math.random()*99);

      if(number<=4){
        const number:number= Math.floor(Math.random()*this.listCardsLegendear.length);
        this.listCardsLoot.push(this.listCardsLegendear[number]);
      }
      if(number>=5&&number<=19){
        const number:number= Math.floor(Math.random()*this.listCardsSelten.length);
        this.listCardsLoot.push(this.listCardsSelten[number]);
      }
      if(number>=20){
        const number:number= Math.floor(Math.random()*this.listCardsNormal.length);
        this.listCardsLoot.push(this.listCardsNormal[number]);
      }

    }
    for (let cards of this.listCardsLoot){
      if(this.username&&cards.id){
        this.lootBoxenService.addCardsToUser(this.username,cards.id).subscribe();
      }
    }
  }
  openSilverChest(){
    for(let i=0;i<5;i++){
      const number:number= Math.floor(Math.random()*99);
      if(number<=9){
        const number:number= Math.floor(Math.random()*this.listCardsLegendear.length);
        this.listCardsLoot.push(this.listCardsLegendear[number]);
      }
      if(number>=10&&number<=34){
        const number:number= Math.floor(Math.random()*this.listCardsSelten.length);
        this.listCardsLoot.push(this.listCardsSelten[number]);
      }
      if(number>=35){
        const number:number= Math.floor(Math.random()*this.listCardsNormal.length);
        this.listCardsLoot.push(this.listCardsNormal[number]);
      }

    }
    for (let cards of this.listCardsLoot){
      if(this.username&&cards.id){
        this.lootBoxenService.addCardsToUser(this.username,cards.id).subscribe();
      }
    }

  }
  openGoldChest(){
    for(let i=0;i<5;i++){
      const number:number= Math.floor(Math.random()*99);
      if(number<=14){
        const number:number= Math.floor(Math.random()*this.listCardsLegendear.length);
        this.listCardsLoot.push(this.listCardsLegendear[number]);
      }
      if(number>=15&&number<=39){
        const number:number= Math.floor(Math.random()*this.listCardsSelten.length);
        this.listCardsLoot.push(this.listCardsSelten[number]);
      }
      if(number>=40){
        const number:number= Math.floor(Math.random()*this.listCardsNormal.length);
        this.listCardsLoot.push(this.listCardsNormal[number]);
      }
    }
    for (let cards of this.listCardsLoot){
      if(this.username&&cards.id){
        this.lootBoxenService.addCardsToUser(this.username,cards.id).subscribe();
      }
    }

  }
  setOpenChestActive(){
    if(this.lootBox?.id){
      this.lootBoxenService.lootBoxDelete(this.lootBox.id).subscribe({
        next: (response: any) => {
          if(this.lootBox){
            this.listLootBoxen.splice(this.listLootBoxen.indexOf(this.lootBox),1);
            this.popUpActive=!this.popUpActive;
            this.toggleBox(this.box);
            this.openChestActive=true;
          }
        },
        error: (error:any) => {
          alert("Öffnen fehlgeschlagen");
        }
      });
    }
  }
  openChestNone(){
    this.openChestActive=false;
    this.listCardsLoot=[];
  }
}
