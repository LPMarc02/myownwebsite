import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DuellRequestComponent } from './duell-request.component';

describe('DuellRequestComponent', () => {
  let component: DuellRequestComponent;
  let fixture: ComponentFixture<DuellRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DuellRequestComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DuellRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

