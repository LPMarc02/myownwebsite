import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DuellRequestService } from "../Services/services/duell-request.service";
import { NgIf } from "@angular/common";
import { Router, RouterLink } from "@angular/router";
import { DuellRequest } from "../Models/DuellRequest.model";
import { UserService } from "../Services/services/user.service";
import { WebSocketMessage } from "../Models/WebSocketMessage.model";
import { Observer, Subject } from "rxjs";
import { WebsocketService } from "../Services/services/websocket.service";
import {TournamentService} from "../Services/services/tournament.service";
import {GameService} from "../Services/services/game.service";
import {Game} from "../Models/Game.model";

@Component({
  selector: 'app-duell-request',
  standalone: true,
  imports: [
    NgIf,
    RouterLink
  ],
  templateUrl: './duell-request.component.html',
  styleUrls: ['./duell-request.component.scss']
})
export class DuellRequestComponent implements OnInit {
  @ViewChild('recMes') recMes!: ElementRef;
  @ViewChild('senMes') senMes!: ElementRef;
  @ViewChild('actDue') actDue!: ElementRef;
  private socket$: Subject<WebSocketMessage> | null = null;
  sessionId: string | null = null;
  playerRole: string | null = null;

  constructor(private requestService: DuellRequestService, private userService: UserService, private ws: WebsocketService, private router: Router, private tournamentService: TournamentService, private gs: GameService) {
    this.username = this.userService.getPlayerData();
  }
  username: string | undefined;
  duellRequest: DuellRequest | undefined;
  requested: boolean = false;
  test2:number = 0;

  ngOnInit() {
    this.socket$ = this.ws.connect('ws://localhost:8081');

    const observer: Observer<WebSocketMessage> = {
      next: (message: WebSocketMessage) => {
        this.onReceived(message);
      },
      error: (error) => console.error('WebSocket error:', error),
      complete: () => console.warn('WebSocket connection closed'),
    }
    if (this.socket$) this.socket$.subscribe(observer);

    this.requestService.event$.subscribe(() => {
      if (!this.requested) {
        this.duellRequest = this.requestService.getRequest();
        this.sendDuellRequest('duell-request', this.duellRequest);
      }
    })
  }

  sendMessage(type: string, msg: any): void {
    if (this.socket$) {
      const message: WebSocketMessage = { type: type, data: msg };
      this.socket$.next(message);
    }
  }

  sendDuellRequest(type: string, msg?: DuellRequest): void {
    if (this.socket$ && msg) {
      const message: WebSocketMessage = { type: type, data: msg };
      this.socket$.next(message);
    }
  }
  sent:boolean = false;
  onReceived(message: WebSocketMessage): void {
    switch (message.type) {
      case 'duell-timer': {
        this.seconds = parseInt(message.data.toString())
        break;
      }
      case 'duell-request': {
        let duellRequest = message.data as DuellRequest;
        if (duellRequest.sender === this.username) {
          this.senMes.nativeElement.style.display = "flex";
          this.startCountdown();
          this.duellRequest = duellRequest;
          this.requested = true;
        }
        if (duellRequest.receiver === this.username) {
          this.recMes.nativeElement.style.display = "flex";
          this.duellRequest = duellRequest;
          this.requested = true;
        }
        break;
      }
      case 'times-up': {
        clearInterval(this.intervalId);
        const duellRequest = message.data as DuellRequest;
        if (duellRequest.sender === this.username) {
          this.senMes.nativeElement.style.display = "none";
          this.requested = false;
          this.duellRequest = undefined;
        }else if (duellRequest.receiver === this.username) {
          this.recMes.nativeElement.style.display = "none";
          this.requested = false;
          this.duellRequest = undefined;
        }
        break;
      }
      case 'assignPlayer': {
        this.playerRole = message.data as string;
        break;
      }
      case 'accept': {
        const duellRequest = message.data as DuellRequest;
        if (duellRequest.sender === this.username) {
          this.actDue.nativeElement.style.display = "flex";
          this.senMes.nativeElement.style.display = "none";
          this.requested = false;
          clearInterval(this.intervalId);
        }else if (duellRequest.receiver === this.username) {
          this.actDue.nativeElement.style.display = "flex";
          this.recMes.nativeElement.style.display = "none";
          this.requested = false;
          clearInterval(this.intervalId);
        }
        break;
      }
      case 'navigateToDeckChoice': {
        const data = message.data as unknown as { sessionId: string; duellRequest: any};
        if (data.duellRequest.sender === this.username && this.username) {
          this.actDue.nativeElement.style.display = "none"
          this.userService.setUserOnline(this.username, 'ingame').subscribe();

          // Navigate to the deck choice screen
          this.sessionId = data.sessionId;
          if (!this.sent) {
            this.sent = true;
            this.sendGameMode(data.duellRequest.GameMode);
            this.playerRole = "Player 1"
            const updatedGame: Game = {
              sessionId: this.sessionId!,
              username: this.username,
              playerRole: this.playerRole,
              deckId: -1,
              gameMode: 0
            };
            console.log(updatedGame);
            this.gs.addGameSession(updatedGame).subscribe((gameState) => {
              console.log(gameState);
            })
            this.router.navigate(['/deck-choice']);
          }

        }else if (data.duellRequest.receiver === this.username && this.username) {
          this.actDue.nativeElement.style.display = "none"
          this.userService.setUserOnline(this.username, 'ingame').subscribe();

          // Navigate to the deck choice screen
          this.sessionId = data.sessionId;
          if (!this.sent){
            this.sent = true;
            this.playerRole = "Player 2"
            const updatedGame: Game = {
              sessionId: this.sessionId!,
              username: this.username,
              playerRole: this.playerRole,
              deckId: -1,
              gameMode: 0
            };
            this.gs.addGameSession(updatedGame).subscribe((gameState) => {
              console.log(gameState);
            })
            this.router.navigate(['/deck-choice']);
          }
          this.sendGameMode(data.duellRequest.GameMode);
        }
        break;
      }
    }
  }

  seconds = 30;
  private intervalId: any;

  startCountdown() {
    this.seconds = 30;
    this.intervalId = setInterval(() => {
      this.seconds--;
      this.sendMessage('duell-timer', this.seconds);
      if (this.seconds <= 0) {
        clearInterval(this.intervalId);
        this.deny();
      }
    }, 1000);
  }

  accept() {
    this.sendMessage('accept', this.duellRequest);
  }

  deny() {
    this.sendMessage('times-up', this.duellRequest);
  }

  activeDuell() {
    this.acceptDuel();
  }

  acceptDuel(): void {
    // Send the accept message to the server
    this.sendMessage('acceptDuel', this.duellRequest);
  }

  sendGameMode(GameMode:number){
    this.tournamentService.setGameMode(this.duellRequest?.gameMode);
  }
}
