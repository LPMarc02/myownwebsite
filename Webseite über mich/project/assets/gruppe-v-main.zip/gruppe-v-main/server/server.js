const WebSocket = require('ws');
const url = require('url');
const { v4: uuidv4 } = require('uuid');

const wss = new WebSocket.Server({ port: 8081 });

const sessions = {}; // Keep track of game sessions

wss.on('connection', (ws, req) => {
  const parameters = url.parse(req.url, true);
  const sessionId = parameters.query.sessionId;

  if (!sessions[sessionId]) {
    sessions[sessionId] = {
      players: [],
      ws: new Set(),
      deckChoices: {}, // Store deck choices for the session
      generatedSessionId: null // Store generated session ID
    };
  }

  const session = sessions[sessionId];

  session.players.push({ws,});
  session.ws.add(ws);

  ws.on('message', (message) => {
    const parsedMessage = JSON.parse(message);
    if (parsedMessage.type === 'acceptDuel') {

      if (!session.generatedSessionId) {
        session.generatedSessionId = uuidv4();      }

      session.ws.forEach(client => {
        client.send(JSON.stringify({
          type: 'navigateToDeckChoice',
          data: {
            sessionId: session.generatedSessionId,
            duellRequest: parsedMessage.data,
          }
        }));
      });
    } else {
      session.ws.forEach(client => {
        if (client !== ws && client.readyState === WebSocket.OPEN) {
          client.send(JSON.stringify(parsedMessage));
        }
      });
    }

    ws.on('close', () => {
      session.players = session.players.filter(player => player.ws !== ws);
      session.ws.delete(ws);

      if (session.players.length === 0) {
        delete sessions[sessionId];
      }
    });
  });
});

console.log('WebSocket server is running on ws://localhost:8081');
