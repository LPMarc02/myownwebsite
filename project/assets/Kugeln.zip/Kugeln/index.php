<?php
  require("connection.php");
  if(isset($_POST["submit"])){
    var_dump($_POST);
    $username=$_POST["username"];
    $email=$_POST["email"];
    $password = PASSWORD_HASH($_POST["password"], PASSWORD_DEFAULT);
    $stmt= $con->prepare("SELECT * FROM users WHERE username=:username OR email=:email");
    $stmt->bindParam(":username",$username);
    $stmt->bindParam(":email",$email);
    $stmt->execute();

    $useralreadyexists =  $stmt->fetchAll();
    if(!$useralreadyexists){
      //registrieren
      registerUser($username,$email,$password);
    }
    else{
      die("User already exists");
    }


    

  }

function registerUser($username,$email,$password){
    global $con;
    $stmt=$con->prepare("INSERT INTO users(username, email, password) VALUES(:username,:email,:password)");
    $stmt->bindParam(":username",$username);
    $stmt->bindParam(":email",$email);
    $stmt->bindParam(":password",$password);
    
    if($stmt->execute()){
      header("location: login.php");
     }
     else {
     die(var_dump($stmt->errorInfo()));
    }
  }
  
?>



<!DOCTYPE html>

<html lang="de">
    <head>
        <title>Registrieren</title>
        <link rel="stylesheet" href="style.css">
      
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>

    <body style="background-color: darkslateblue;">
        <div id="top">
            
            
            <div id="logo">Register</div>
            <div id="line"></div>
            </div>

            <div id="navigation">
                
                
                <p></p>
                <div class="css-dreieck"></div>
                <div class="css-dreieck2" ></div>
                
                
                
            </div>
            
        </div>
        <div id="main">
            <form action="index.php" method="POST">
    
             
                <div class="container">
                  <label for="username"><b>Username</b></label>
                  <input type="text" id="Username" placeholder="Enter Username" name="username" autocomplete='off' >

                  <label for="email"><b>EMail</b></label>
                  <input type="text" id="EMail" placeholder="Enter EMail" name="email" autocomplete='off' >
              
                  <label for="password"><b>Password</b></label>
                  <input type="password" id="Password" placeholder="Enter Password" name="password"autocomplete='off' >
              
                  <button type="submit" name="submit">Registrieren</button>
                  <label>
                    <input type="checkbox" checked="checked" name="remember"> Remember me
                  </label>

                    <h3>Oder hier einloggen: <a href="login.php">Login</a></h3>
                </div>
              
                <div class="container" style="background-color:#f1f1f1">
                  

                </div>
              </form>
                
                <p></p>
                <div class="css-dreieck" ></div>
                <div class="css-dreieck2" ></div>

        
        </div>

        <div id="navigation">
            <div id="line"></div>
            
            <a href="">Impressum</a>
            <a href="">Kontakt</a>

        </div>

        <div id="footer"></div>
        
      
    
    
    
    
    </body>
  
    
</html>

    