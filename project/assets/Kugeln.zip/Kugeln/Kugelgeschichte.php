<!DOCTYPE html>

<html>
    <head>
        <title>Kugelgeschichte</title>
        <link rel="stylesheet" href="style.css">
        
        <meta name="viewport" content="widht=device-width, initial-scale=1">
    </head>

    <BODY bgcolor="gray">
        <div id="top">

            <div id="logo">Kugelgeschichte</div>
            <div id="box" align="left">
                <a href="file:///C:/Users/marca/OneDrive/Dokumente/TI%20Kugeln/Kugeln/Kugeln.html">Zurück</a>
            </div>
            <div id="line"></div>
            
            
        </div>
        <div id="main">
          
        <div id="line"></div>
            
        

        <div id="footer"></div>
    
    
    
    
    
    </BODY>
    
</html>
