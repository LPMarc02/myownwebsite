//Bestellbutton ausblenden
$("#btn1").hide();

var counter = 0;

$("#links").click(function(){
  counter = counter - 1;
  if (counter < 0) counter = 0;
  console.log(counter);
  $("#mitte a").text(counter)
  $("Test").text(counter);
});

$("#rechts").click(function(){
  counter = counter + 1;
  $("#mitte a").text(counter);
});

var counter2 = 0;

$("#links2").click(function(){
  counter2 = counter2 - 1;
  console.log(counter2);
  $("#mitte2 a").text(counter2);
});

$("#rechts2").click(function(){
  counter2 = counter2 + 1;
  $("#mitte2 a").text(counter2);
});

var counter3 = 0;

$("#links3").click(function(){
  counter3 = counter3 - 1;
  console.log(counter3);
  $("#mitte3 a").text(counter3);
});

$("#rechts3").click(function(){
  counter3 = counter3 + 1;
  $("#mitte3 a").text(counter3);
});
