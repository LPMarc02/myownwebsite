<!DOCTYPE html>

<html>
    <head>
        <title>Bonbon GmbH</title>
        <link rel="stylesheet" href="style.css">
        
      
        <meta name="viewport" content="widht=device-width, initial-scale=1">
    </head>

    <BODY bgcolor="darkslateblue">
        <div id="top">
            <div class="Benutzer" align="right">
                <?php
                session_start();
                echo $_SESSION["username"];

                ?>
                
        
                </div>
            
            <div id="logo">Bonbon</div>
            
            <div id="line"></div>
            <div id="logo-name"><h2>Bonbon GmbH<h2>
            </div>

            <div id="navigation">
                <a href="Kaufen.php">Kaufen</a>
                <a href="Kugelgeschichte.php">Kugel Geschichte</a>
              
                
                <p></p>
                <div class="css-dreieck"></div>
                <div class="css-dreieck2" ></div>
                
                
                
            </div>
            <div id="Kugel">
                <img src="Kugeln.jpg" alt="Bild Kugel">
        </div>
        <div id="main">
            <section id="aboutme">
                <h2>Alles rund um Kugeln</h2>
                <p></p>
                <div class="css-dreieck" ></div>
                <div class="css-dreieck2" ></div>
            </section>
            <section id="aboutus"></section>
        
        </div>

        <div id="navigation">
            <div id="line"></div>
            
            <a href="">Impressum</a>
            <a href="">Kontakt</a>

        </div>

        <div id="footer"></div>
        
      
    
    
    
    
    </BODY>
  
    
</html>
<script type="text/javascript" src="script.js"></script>
    