<!DOCTYPE html>

<html lang="">
    <head>
        <title>Kaufen</title>
        <link rel="stylesheet" href="style.css">
        
        
        <meta name="viewport" content="width=device-width, initial-scale=1">
    </head>

    <body bgcolor="darkslateblue">
        <div id="top">

            <div id="logo">Kaufen</div>
            <div id="box" align="left">
                <a href="Kugeln.php">Zurück</a>
            </div>
            
            
            
        </div>
        <div id="main">
            <div id="Kaufen">
                <section>
                    <div id="line"></div>
                    <div id="Block" ><h2>Blaue Kugeln</h2></div>
                    <div id="text1">Blaue Bonbon mit Spitzen Qualität.</a></div>
                    <p></p>
                    
                    <div class="box" id="links"><a>-</a></div>
                    <div class="box" id="mitte"><a>0</a></div>
                    <div class="box" id="rechts"><a>+</a></div>
                    <div aside align="left" id="Bild">
                    
                    
                    <div class="css-dreieck"></div>
                    <div class="css-dreieck2" ></div>


                    <div id="line"></div>
                    <div id="Block" ><h2>Grüne Kugeln</h2></div>
                    <div id="text1">Grüne Bonbon mit Spitzen Qualität.</a></div>

                    
                    <div class="box" id="links2"><a>-</a></div>
                    <div class="box" id="mitte2"><a>0</a></div>
                    <div class="box" id="rechts2"><a>+</a></div>   
                    <div aside align="left" id="Bild">



                    
                    <div class="css-dreieck"></div>
                    <div class="css-dreieck2" ></div>

                    <div id="line"></div>
                    <div id="Block" ><h2>Rote Kugeln</h2></div>
                    <div id="text1">Rote Bonbon mit Spitzen Qualität.</a></div>
                    <div class="box" id="links3"><a>-</a></div>
                    <div class="box" id="mitte3"><a>0</a></div>
                    <div class="box" id="rechts3"><a>+</a></div>
                    <div aside align="left" id="Bild">
                    

                    
                    <div class="css-dreieck"></div>
                    <div class="css-dreieck2" ></div>
                    <div id="line"></div>
                    <p><button type="text" id="btn1">Bestellen</button></p>
                </section>
                
            </div>
            
            
            <div id="line"></div>
           
                
                    
        
                   
      
            
        

        <div id="footer"></div>
    
    
    
    
    
    </body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="box.js"></script>
<script>

function showButton(){
    if(counter > 0 || counter2 > 0 || counter3 > 0) $("#btn1").show();
    else $("#btn1").hide();
}
//Funktion jede Sekunde ausführen
setInterval(showButton, 1000);

//Wenn Bestellbutton geklickt wird, wird die updateCounter Funktion aufgerufen
$('#btn1').on('click', function (e){
    alert("Tets");
    $.ajax({
        type: "POST",
        url: "Benutzer.php",
        data: {counter: counter, counter2: counter2, counter3: counter3},
        success: function (data){
            alert(data);
            //Weiterleiten auf den Warenkorb
            window.location.href = "Einkaufswagen.php";
        },
        error: function (data) {
            alert(data);
        }

    })
});
//Sendet counter Variablen an das PHP Script, danach gehts zum Einkaufswagen
function updateCounter(e) {
    e.preventDefault();
    $.ajax({
        type: "POST",
        url: "Benutzer.php",
        dataType: "json",
        data: {counter: counter, counter2: counter2, counter3: counter3}

    }).done(function (data) {
        alert(data);
        //Weiterleiten auf den Warenkorb
        window.location.href = "Einkaufswagen.php";

    });
}
</script>




</html>
