<?php
//hier die session starten
session_start();

?>
<?php
  require("connection.php");
  if(isset($_POST["submit"])){
    var_dump($_POST);
    $username=$_POST["username"];
    $email=$_POST["email"];
    $address=$_POST["address"];
    $city=$_POST["city"];
    $state=$_POST["state"];
    $cardname=$_POST["cardname"];
    $cardnumber=$_POST["cardnumber"];

    bestellkugel($username,$email,$address,$city,$state,$cardname,$cardnumber);
    

    

  }

function bestellkugel($username,$email,$address,$city,$state,$cardname,$cardnumber){
    global $con;
    $stmt= $con->prepare("INSERT INTO bestellungen(username, email, address,city, state ,cardname, cardnumber, Blau, Rot, Grün) VALUES(:username,:email,:address,:city,:state,:cardname,:cardnumber, :blau, :rot, :gruen)");
    $stmt->bindParam(":username",$username);
    $stmt->bindParam(":email",$email);
    $stmt->bindParam(":address",$address);
    $stmt->bindParam(":city",$city);
    $stmt->bindParam(":state",$state);
    $stmt->bindParam(":cardname",$cardname);
    $stmt->bindParam(":cardnumber",$cardnumber);
    $stmt->bindParam(":blau",$_SESSION['counter']);
    $stmt->bindParam(":rot",$_SESSION['counter3']);
    $stmt->bindParam(":gruen",$_SESSION['counter2']);

    if($stmt->execute()){
      //Session löschen (warenkorb leer machen)
      unset($_SESSION);
      header("location: login.php");
     }
     else {
     die(var_dump($stmt->errorInfo()));
    }
  }
  
?>
<!DOCTYPE html>

<html>
    <head>
        <title>Ihr Einkauf</title>
        <link rel="stylesheet" href="style.css">
      
        <meta name="viewport" content="width=1024" />
    </head>

    <body bgcolor="darkslateblue">
        <div id="top">
            
            
            <div id="logo">Ihr Einkauf</div>
            <div id="line"></div>
            </div>

            <div id="navigation">
                
                
                <p></p>
                <div class="css-dreieck"></div>
                <div class="css-dreieck2" ></div>
                
                
                
            </div>
            
        </div>
        <div id="main">
            <div class="row">
                <div class="col-75">
                  <div class="container">
                    <form action="" method="POST">
              
                      <div class="row">
                        <div class="col-50">
                          <h3>Kontaktdaten</h3>
                          <label for="fname"><i class="fa fa-user"></i> Name</label>
                          <input type="text" id="fname" name="username" placeholder="John M. Doe">

                          <label for="email"><i class="fa fa-envelope"></i> Email</label>
                          <input type="text" id="email" name="email" placeholder="john@example.com">

                          <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
                          <input type="text" id="adr" name="address" placeholder="542 W. 15th Street">

                          <label for="city"><i class="fa fa-institution"></i> City</label>
                          <input type="text" id="city" name="city" placeholder="New York">
              
                          <div class="row">
                            <div class="col-50">
                              <label for="state">State</label>
                              <input type="text" id="state" name="state" placeholder="NY">
                            </div>
                          </div>
                        </div>
              
                        <div class="col-50">
                          <h3>Bezahlung</h3>
                          <div class="icon-container">
                            <i class="fa fa-cc-visa" style="color:navy;"></i>
                            <i class="fa fa-cc-amex" style="color:blue;"></i>
                            <i class="fa fa-cc-mastercard" style="color:red;"></i>
                            <i class="fa fa-cc-discover" style="color:orange;"></i>
                          </div>
                          <label for="cname">Bank</label>
                          <input type="text" id="cname" name="cardname" placeholder="John More Doe">
                          <label for="ccnum">IBAN</label>
                          <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
                          
                          
              
                      </div>
                      <label>
                        <input type="checkbox" checked="checked" name="sameadr"> Daten Bestätigen
                      </label>
                      <input type="submit" name="submit" value="Bestellen" class="btn" id="BN">
                    </form>
                  </div>
                </div>
              
                <div class="col-25">
                  <div class="container">
                    <h4>Einkaufswagen
                      <span class="price" style="color:black">
                        <i class="fa fa-shopping-cart"></i>
                        <b>Anzahl insgesamt: <?= $_SESSION['counter'] + $_SESSION['counter2'] + $_SESSION['counter3']  ?></b>
                      </span>
                    </h4>
                      <br>
                    <p>
                        <a>Blaue Kugeln (1.50€)</a>
                        <span class="price">
                            <?= $_SESSION['counter'] ?? 0; ?>

                        </span>
                    </p>
                      <br>
                      <p>
                          <a>Grüne Kugeln (1.50€)</a>
                          <span class="price">

                            <?= $_SESSION['counter2'] ?? 0; ?>

                        </span>
                      </p>
                      <br>
                      <p>
                          <a>Rote Kugeln (1.50€)</a>
                          <span class="price">

                            <?= $_SESSION['counter3'] ?? 0; ?>

                        </span>
                      </p>
                      <br>
                    <hr>
                    <p>Total <span class="price" style="color:black"><b><?= ($_SESSION['counter'] + $_SESSION['counter2'] + $_SESSION['counter3'])*1.5 ?>€</b></span></p>
                  </div>
                </div>
              </div>
                
                <p></p>
                <div class="css-dreieck" ></div>
                <div class="css-dreieck2" ></div>

        
        </div>

        <div id="navigation">
            <div id="line"></div>
            
            <a href="">Impressum</a>
            <a href="">Kontakt</a>

        </div>

        <div id="footer"></div>
        
      
    
    
    
    
    </body>
  
    
</html>

    