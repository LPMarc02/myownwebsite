<?php

    $dsn='mysql:dbname=userdb;host=localhost';
    $username = 'root';
    $password ='';

    $con = new PDO($dsn,$username,$password);
