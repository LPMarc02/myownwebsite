<?php
session_start();
var_dump($_POST);
$_SESSION['counter'] =  $_POST['counter'];
$_SESSION['counter2'] =  $_POST['counter2'];
$_SESSION['counter3'] =  $_POST['counter3'];

