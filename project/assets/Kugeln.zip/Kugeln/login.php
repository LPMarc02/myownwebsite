<?php
  require("connection.php");

  if(isset($_POST["submit"])){

    $username = $_POST["username"];
    $password = $_POST["password"];

    $stmt = $con->prepare("SELECT * FROM users WHERE username=:username");
    $stmt->bindParam(":username", $username);
    $stmt->execute();
    $userExists =  $stmt->fetchAll();
    var_dump($userExists);

    $passwordHashed = $userExists[0]["password"];
    $checkPassword = password_verify($password, $passwordHashed);

    if($checkPassword === false){
      echo "Login fehlgeschlagen, Passwort stimmt nicht überein";
    }
    if($checkPassword === true){

      session_start();
      $_SESSION["username"] = $userExists[0]["username"];

      header("Location: kugeln.php");
    }
  }
 ?>



<!DOCTYPE html>

<html>
    <head>
        <title>LogIn</title>
        <link rel="stylesheet" href="style.css">
      
        <meta name="viewport" content="widht=device-width, initial-scale=1">
    </head>

    <BODY bgcolor="darkslateblue">
        <div id="top">
            
            
            <div id="logo">LOG IN BONBON GmbH</div>
            <div id="line"></div>
            </div>

            <div id="navigation">
                
                
                <p></p>
                <div class="css-dreieck"></div>
                <div class="css-dreieck2" ></div>
                
                
                
            </div>
            
        </div>
        <div id="main">
          <script type="text/javascript" src="benutzer.js"></script>
            <form action="login.php" method="POST">
    
             
                <div class="container">
                  <label for="username"><b>Username</b></label>
                  <input type="text" id="Username" placeholder="Enter Username" name="username" autocomplete='off' >
              
                  <label for="password"><b>Password</b></label>
                  <input type="password" id="Password" placeholder="Enter Password" name="password"autocomplete='off' >
              
                  <button type="submit" name="submit">Login</button>
                  <label>
                    <input type="checkbox" checked="checked" name="remember"> Remember me
                  </label>
                </div>
              
                <div class="container" style="background-color:#f1f1f1">
                  

                </div>
              </form>
                
                <p></p>
                <div class="css-dreieck" ></div>
                <div class="css-dreieck2" ></div>

        
        </div>

        <div id="navigation">
            <div id="line"></div>
            
            <a href="">Impressum</a>
            <a href="">Kontakt</a>

        </div>

        <div id="footer"></div>
        
      
    
    
    
    
    </BODY>
  
    
</html>
